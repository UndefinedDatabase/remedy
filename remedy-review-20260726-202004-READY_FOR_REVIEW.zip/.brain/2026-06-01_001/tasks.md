## Task 01: Restore Safe `source_apply` Compatibility

Impact: High  
Effort: Medium  

Context:
Commit `fa88cd7` made `apply_structured_patch(..., *, job)` mandatory in `packages/orchestration/source_apply.py`, but older in-repo callers and tests still use the previous two-argument contract.

Problem:
The current branch has a verified regression: `pytest -q tests/test_steps_91_100.py -k 'TestSourceApply and apply_simple_file_op'` fails with `TypeError: apply_structured_patch() missing 1 required keyword-only argument: 'job'`.

Goal:
Preserve the new permission boundary without leaving the repository in a mixed state where legacy call sites crash.

Relevant areas:
- `packages/orchestration/source_apply.py`
- `tests/test_steps_91_100.py`
- `packages/orchestration/autorun.py`

Proposed changes:
- Decide on one explicit compatibility strategy: either add a backward-compatible wrapper path for non-repo writes or migrate every remaining caller/test in-repo to the new required `job` contract.
- Add regression tests that cover both the protected repo-write path and the chosen compatibility/migration path.

Acceptance criteria:
- The legacy failing test path is either fixed or intentionally replaced with updated tests covering the new contract.
- The permission gate for `repo_generated_write` remains enforced for real repo mutations.

Priority rationale:
This is a branch-breaking regression already reproduced in the current tree, so it blocks confidence in the rest of the patch-apply work.

## Task 02: Make Patch Apply Transactional

Impact: High  
Effort: Medium  

Context:
`apply_structured_patch()` snapshots files before mutation, but it applies file ops and unified diffs sequentially and does not roll back earlier writes when a later operation fails.

Problem:
A partially failing patch can leave the target repo mutated even when `ApplyResult.success` is `False`, which breaks the safety story for approved writes.

Goal:
Ensure patch application is all-or-nothing for multi-file operations.

Relevant areas:
- `packages/orchestration/source_apply.py`
- `tests/test_steps_261_268.py`

Proposed changes:
- Change `apply_structured_patch()` to revert already-applied snapshots immediately on the first failure in a multi-op patch.
- Add tests that prove a later failure restores files changed earlier in the same patch.

Acceptance criteria:
- A mixed patch where one operation fails leaves the repo exactly as it was before apply.
- `ApplyResult` still reports the root-cause error without masking the rollback outcome.

Priority rationale:
The current implementation can mutate user code on a failing apply, which is a higher-severity safety issue than any display bug.

## Task 03: Validate Unified Diff Hunks Against Real File Content

Impact: High  
Effort: Medium  

Context:
`_apply_hunks()` in `packages/orchestration/source_apply.py` removes and inserts lines by hunk coordinates but does not verify that context lines and removed lines actually match the current file contents.

Problem:
Unified diffs can be applied to the wrong file state without being rejected, silently producing incorrect code while still reporting success.

Goal:
Make unified diff application fail closed when hunk context does not match.

Relevant areas:
- `packages/orchestration/source_apply.py`
- `tests/test_patch_apply.py`
- `tests/test_steps_91_100.py`

Proposed changes:
- Rework `_apply_hunks()` to check context and removal lines exactly before mutating the output buffer.
- Add mismatch tests for stale line numbers, changed context, and duplicate hunk regions.

Acceptance criteria:
- Stale or mismatched hunks are rejected with a deterministic error.
- Clean hunks still apply successfully and preserve existing revert behavior.

Priority rationale:
Incorrect diff application corrupts code silently, which is a core contract failure for any approved patch pipeline.

## Task 04: Harden Taskfile Risk Detection Before Test Execution

Impact: High  
Effort: Medium  

Context:
Commit `a5b3697` hardened `command_discovery.py`, but `_detect_taskfile()` only discovers task names and never inspects the underlying task body for risky commands, unlike Makefile, Justfile, and package.json handling.

Problem:
A `Taskfile.yml` target named `test` can contain destructive or networked commands and still be returned as a low-risk executable candidate.

Goal:
Bring Taskfile detection up to the same safety standard as the other command detectors.

Relevant areas:
- `packages/orchestration/command_discovery.py`
- `packages/orchestration/test_runner.py`
- `tests/test_command_discovery.py`

Proposed changes:
- Parse Taskfile command bodies well enough to pass them through `_assess_risk()` before candidate selection.
- Add tests showing that risky Taskfile-backed `test` commands are marked high-risk and excluded from execution.

Acceptance criteria:
- Risky Taskfile tasks are no longer selected by `select_best_test_candidate()`.
- Safe Taskfile test commands still remain discoverable and executable.

Priority rationale:
This is a real safety gap in the newly hardened command-discovery path and directly affects subprocess execution.

## Task 05: Fix Dashboard `next_action` Command Contract End-to-End

Impact: High  
Effort: Low  

Context:
`packages/orchestration/ui_server.py` emits dashboard `next_action` objects with keys `kind`, `label`, `reason`, `requires_user`, and `related_node_id`, but no `command`. `apps/ui/src/api/remedyApi.ts` falls back to `na.command || na.label`, and `CommandBar.tsx` copies `nextAction.command` to the clipboard.

Problem:
When no guidance command exists, the UI copies human text like `Review project state` instead of a runnable CLI command.

Goal:
Make dashboard `next_action` payloads always include a trustworthy executable command string.

Relevant areas:
- `packages/orchestration/ui_server.py`
- `apps/ui/src/api/remedyApi.ts`
- `apps/ui/src/components/command/CommandBar.tsx`

Proposed changes:
- Add a `command` field to the server dashboard payload and keep fallback label/command distinct.
- Add backend and frontend tests for both guidance-backed and fallback next actions.

Acceptance criteria:
- The dashboard payload always includes both `label` and `command`.
- Copying the suggested command from the UI yields a runnable Remedy command, not prose.

Priority rationale:
This is a verified contract mismatch across backend and UI that produces a wrong user-facing action right now.

## Task 06: Stop Marking Every Task as Tested When Only One Test Run Exists

Impact: Medium  
Effort: Medium  

Context:
`_build_dashboard()` sets each task’s `test_status` to `pass` whenever any `test_run_completed` event has `exit_code == 0`, regardless of which task the run actually validates.

Problem:
The dashboard overstates task-level verification. A single successful test run makes every task look tested.

Goal:
Represent test status honestly at task level, or move unscoped results to a job-level indicator.

Relevant areas:
- `packages/orchestration/ui_server.py`
- `packages/orchestration/project_brain.py`
- `tests/test_steps_253_260.py`

Proposed changes:
- Only assign per-task `test_status` when the event metadata can be linked to that task, or otherwise emit `none`/`unscoped`.
- Add regression tests for multi-task jobs with one global passing test event.

Acceptance criteria:
- A single job-level test run no longer marks unrelated tasks as `pass`.
- The dashboard still surfaces that a job-level test run happened somewhere safe and visible.

Priority rationale:
This is a concrete truthfulness bug in the new dashboard contract, confirmed by a runtime probe on the current code.

## Task 07: Derive `graph_summary` From the Real Brain Graph

Impact: Medium  
Effort: Medium  

Context:
`_build_dashboard()` labels `graph_summary.source` as `project_brain`, but computes counts with a local heuristic: `task_count + artifact_count` for nodes and `max(0, node_count - 1)` for edges.

Problem:
The payload claims to summarize the project brain while ignoring real node types like approvals, test runs, blockers, and events.

Goal:
Make `graph_summary` numerically honest and sourced from the same graph the UI can inspect elsewhere.

Relevant areas:
- `packages/orchestration/ui_server.py`
- `packages/orchestration/project_brain.py`
- `packages/orchestration/ui_view_model.py`

Proposed changes:
- Build `graph_summary` from `build_project_brain()` or rename the field/source to an explicit heuristic if full graph computation is intentionally deferred.
- Add tests that compare `graph_summary` counts against the underlying graph export for representative jobs.

Acceptance criteria:
- `graph_summary` counts match the actual graph data source named in the payload.
- Jobs with approvals, tests, or blockers no longer report misleadingly low graph counts.

Priority rationale:
The commit theme is dashboard truthfulness; this field currently overclaims its provenance.

## Task 08: Report Live Actor and Action Honestly

Impact: Medium  
Effort: Low  

Context:
`_build_dashboard()` sets `live.current_actor` to `Builder` whenever the job is running and leaves `current_action` blank, independent of the latest event stream.

Problem:
The live panel can imply an active builder step even when the event ledger does not support that conclusion.

Goal:
Make the live section evidence-backed or explicitly unknown.

Relevant areas:
- `packages/orchestration/ui_server.py`
- `apps/ui/src/api/remedyApi.ts`
- `tests/test_steps_253_260.py`

Proposed changes:
- Derive `current_actor` and `current_action` from the latest relevant event or guidance state.
- Fall back to `unknown`/empty values when no grounded inference exists.

Acceptance criteria:
- Live actor/action fields reflect actual event-backed state instead of a hardcoded builder assumption.
- Empty or stale jobs no longer present an implied active actor.

Priority rationale:
This is another honesty gap in the newly introduced dashboard contract and is straightforward to fix once scoped.

## Task 09: Surface Partial API Degradation to the UI

Impact: Medium  
Effort: Low  

Context:
`loadRemedyDashboard()` collects failed secondary endpoints like `brain-view-model`, but when `/dashboard` succeeds it sets `apiHealth.degraded` to `failedEndpoints.includes("dashboard")`, which stays `false` for partial failures.

Problem:
The UI suppresses degraded-state signaling even when optional endpoint failures already occurred.

Goal:
Differentiate healthy, partially degraded, and fully degraded dashboard loads.

Relevant areas:
- `apps/ui/src/api/remedyApi.ts`
- `apps/ui/src/api/remedyApi.test.ts`
- `apps/ui/src/RemedyApp.tsx`

Proposed changes:
- Set `apiHealth.degraded` for any failed endpoint, or add an explicit `partiallyDegraded` signal if the UI needs to distinguish levels.
- Add tests for `dashboard` success plus `brain-view-model` failure.

Acceptance criteria:
- Partial endpoint failures are visible in the normalized dashboard state.
- The frontend test suite covers both full failure and partial degradation cases.

Priority rationale:
This is a concrete bug in the new dashboard-first client path and hides operational problems from the user.

## Task 10: Preserve Safe Test Output Truncation Metadata Across Surfaces

Impact: Medium  
Effort: Medium  

Context:
Commit `fa88cd7` added `output_truncated`, `original_output_bytes`, and `persisted_output_bytes` to `TestRunRecord`, but those fields are dropped when test results are written into CLI job metadata and run-log event metadata.

Problem:
The system now knows when output was truncated, but downstream observers cannot tell whether a stored test artifact is complete.

Goal:
Expose truncation truth through safe metadata without leaking raw output.

Relevant areas:
- `packages/orchestration/test_runner.py`
- `apps/cli/commands/test_cmds.py`
- `tests/test_test_runner.py`

Proposed changes:
- Decide which safe surfaces should carry truncation metadata and update their schemas intentionally.
- Extend tests so truncation metadata survives the chosen persistence path without reintroducing forbidden raw output fields.

Acceptance criteria:
- At least one safe downstream surface preserves whether test output was truncated and how many bytes were dropped.
- Existing redaction guarantees remain intact and explicitly tested.

Priority rationale:
The truncation work is only half-finished today: execution knows the truth, but operators inspecting later state do not.