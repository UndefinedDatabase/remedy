# Sources

- `ui_server.py` imports `packages.orchestration.readiness`, but only `autonomy_readiness.py` exists.
- `ui_server.py` auto-runs `npm install` and `npm run build` when `apps/ui/dist` is missing.
- `remedyApi.ts` uses `Promise.allSettled` and replaces failed endpoint payloads with `{}`.
- `test_cmds.py` permission error says `remedy job permit <id> allow repo_test_run`; catalog order is `<job_id> <permission> <action>`.
- `ui_view_model.py` suggests `remedy test list`, but catalog contains `test discover` and `test run`, not `test list`.
- `autonomy_loop.py` and `autonomy_readiness.py` define different autonomy level meanings.
- `source_apply.py` applies structured patches separately from `patch_apply.py` and does not check `Capability` before repo mutation.
- `test_runner.py` writes raw subprocess output bytes to workspace with no size cap.
- `command_discovery.py` uses simple `.split()` for constitution commands.
