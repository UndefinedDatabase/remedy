# Repo Map

- Python package with CLI entrypoint in `apps/cli/grouped.py` and command catalog in `apps/cli/command_catalog.py`.
- Orchestration modules live in `packages/orchestration/` and cover jobs, patches, run logs, UI view models, tests, autonomy, memory, project brain, and permissions.
- React UI lives in `apps/ui/`; local Python HTTP UI server lives in `packages/orchestration/ui_server.py`.
- Tests are broad and step-oriented under `tests/`.
- Reserved namespaces remain in `apps/api`, `apps/worker`, `packages/runtimes`, `packages/artifacts`, and `packages/verification`.
