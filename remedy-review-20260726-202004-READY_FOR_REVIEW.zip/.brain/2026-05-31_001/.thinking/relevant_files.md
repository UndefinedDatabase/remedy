# Relevant Files

- `packages/orchestration/ui_server.py`
- `packages/orchestration/ui_view_model.py`
- `apps/ui/src/api/remedyApi.ts`
- `apps/ui/src/RemedyApp.tsx`
- `apps/cli/command_catalog.py`
- `apps/cli/grouped.py`
- `apps/cli/commands/job.py`
- `apps/cli/commands/test_cmds.py`
- `packages/orchestration/autonomy_loop.py`
- `packages/orchestration/autonomy_readiness.py`
- `packages/orchestration/test_runner.py`
- `packages/orchestration/command_discovery.py`
- `packages/orchestration/source_apply.py`
- `packages/orchestration/patch_apply.py`
- `packages/orchestration/permissions.py`
- `packages/orchestration/run_log.py`
- `README.md`
- `docs/architecture.md`
