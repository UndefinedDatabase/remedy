# Critic

Removed generic ideas such as "add more docs", "improve tests", and "make UI better" unless tied to specific files and broken contracts. Prioritized issues where repository evidence shows a concrete mismatch, safety gap, or user-facing failure. Deferred large reserved namespaces like API/worker because they are intentionally documented as future work and less urgent than fixing active command/UI/autonomy behavior.
