## Task 01: Repair the UI readiness endpoint import

Impact: High  
Effort: Low  

Context:
The localhost UI server exposes `/api/jobs/<job_id>/readiness` from `packages/orchestration/ui_server.py`. The repository has `packages/orchestration/autonomy_readiness.py`, but no `packages/orchestration/readiness.py`.

Problem:
`_build_readiness_json()` imports `packages.orchestration.readiness`, catches the failure, and returns `{"version": 1, "error": "readiness unavailable"}`. The UI cannot display real readiness even though readiness assessment exists.

Goal:
Make the UI readiness API return the real autonomy readiness report using the existing implementation.

Relevant areas:
- `packages/orchestration/ui_server.py`
- `packages/orchestration/autonomy_readiness.py`
- `tests/test_autonomy_readiness.py`
- `tests/test_steps_172_201.py`

Proposed changes:
- Replace the missing `packages.orchestration.readiness` import with `assess_job_readiness` and `export_readiness_json` from `packages.orchestration.autonomy_readiness`.
- Preserve the safe fallback only for unexpected runtime failures, not normal imports.
- Add a focused test that calls the readiness builder/API path and asserts a real readiness payload with `highest_eligible_level` and `levels`.

Acceptance criteria:
- `/api/jobs/<job_id>/readiness` no longer returns `readiness unavailable` for a valid job.
- A test fails if `ui_server.py` imports a non-existent readiness module again.
- Existing autonomy readiness tests still pass.

Priority rationale:
This is an active UI endpoint with a concrete broken import. It blocks a shipped feature and is cheap to fix.

## Task 02: Remove implicit npm install/build from the read-only UI server path

Impact: High  
Effort: Medium  

Context:
`packages/orchestration/ui_server.py` describes the UI server as read-only, but `_auto_build_frontend()` runs `npm install --no-audit --no-fund` and `npm run build` when `apps/ui/dist` is missing. The command catalog marks `ui.start` as `read_only`.

Problem:
Starting a read-only local UI can mutate `apps/ui/node_modules`, package lock state, and `apps/ui/dist`, and can execute package scripts. This conflicts with the command classification and makes `remedy ui` surprising in locked-down or CI environments.

Goal:
Make UI startup honest and non-mutating by default.

Relevant areas:
- `packages/orchestration/ui_server.py`
- `apps/cli/command_catalog.py`
- `apps/ui/package.json`
- `tests/test_steps_208_226.py`

Proposed changes:
- Disable `_auto_build_frontend()` by default and fail with clear instructions when `apps/ui/dist/index.html` is missing.
- Add an explicit opt-in path such as `REMEDY_UI_AUTO_BUILD=1` or a dedicated dev command if auto-build behavior is still desired.
- Update help/error text to explain `cd apps/ui && npm install && npm run build`.
- Add tests that `ui.start` does not call npm unless the explicit opt-in is set.

Acceptance criteria:
- Running `remedy ui <job_id>` without a built dist fails loudly and does not run npm by default.
- The opt-in path, if added, is covered by a test.
- The read-only command catalog classification remains truthful.

Priority rationale:
This is a safety and trust-boundary issue in a user-facing command.

## Task 03: Surface degraded UI API state instead of silently fabricating dashboard data

Impact: High  
Effort: Medium  

Context:
`apps/ui/src/api/remedyApi.ts` loads four endpoints with `Promise.allSettled` and replaces rejected responses with empty objects. It then builds fallback graph, task, story, and live-state values.

Problem:
If backend endpoints fail, the React UI can still render plausible but synthetic state. That hides broken server contracts, including the current readiness-style import issue pattern, and can mislead operators.

Goal:
Expose API health explicitly and make fallback data visibly degraded.

Relevant areas:
- `apps/ui/src/api/remedyApi.ts`
- `apps/ui/src/RemedyApp.tsx`
- `apps/ui/src/api/types.ts`
- `packages/orchestration/ui_server.py`

Proposed changes:
- Add an `apiHealth` or `degraded` field to `RemedyDashboard` listing failed endpoint names and HTTP errors.
- Keep partial rendering, but show a visible degraded-state banner in `RemedyApp` or `RemedyShell`.
- Treat core endpoint failure for `brain-view-model` as a blocking UI error unless explicitly allowed.
- Add Vitest coverage for one endpoint failing and for all endpoints succeeding.

Acceptance criteria:
- A failed API request is visible in the UI state and not silently converted to normal content.
- Tests verify failed endpoint names are preserved.
- Existing successful dashboard rendering remains unchanged.

Priority rationale:
Silent fallback undermines the UI as an operational cockpit and makes real regressions hard to detect.

## Task 04: Fix incorrect CLI command suggestions for permissions and tests

Impact: High  
Effort: Low  

Context:
The command catalog defines `job permit` arguments as `<job_id> <permission> <action>`. `apps/cli/commands/test_cmds.py` prints `remedy job permit <job_id> allow repo_test_run`. `packages/orchestration/ui_view_model.py` suggests `remedy test list`, but the catalog contains `test discover` and `test run` only.

Problem:
User-facing remediation commands are wrong. Operators following the printed commands hit parser errors or unknown subcommands.

Goal:
Ensure every generated CLI command string maps to an actual catalog entry and argument order.

Relevant areas:
- `apps/cli/command_catalog.py`
- `apps/cli/commands/test_cmds.py`
- `packages/orchestration/ui_view_model.py`
- `tests/test_test_runner.py`
- `tests/test_command_catalog.py`

Proposed changes:
- Change the permission hint to `remedy job permit <job_id> repo_test_run allow`.
- Replace `remedy test list <job_id> --json` with a valid command, likely `remedy test discover <job_id> --json` or `remedy event timeline <job_id> --json` depending on intent.
- Add a catalog-backed test that extracts generated `remedy ...` command strings from these paths and validates group/subcommand existence.

Acceptance criteria:
- Permission-denied test output contains the correct `job permit` argument order.
- UI next-action for failed tests references an existing command.
- A regression test catches future non-existent generated commands.

Priority rationale:
Bad recovery instructions directly block users at moments when they already need help.

## Task 05: Align autonomy level semantics across readiness and loop execution

Impact: High  
Effort: Medium  

Context:
`packages/orchestration/autonomy_readiness.py` documents levels as 0 observe, 1 propose, 2 approved_apply, 3 test_execution, 4 bounded_loop, 5 revert_capable, 6 external_tools, 7 provider_autonomy. `packages/orchestration/autonomy_loop.py` uses different meanings: level 2 generated writes, level 3 approved apply, level 4 test execution, level 5 revert, level 6 limited loop.

Problem:
The readiness report can say one autonomy level is eligible while the loop interprets the same number differently. This is dangerous for future automation and confusing in CLI/UI guidance.

Goal:
Create one authoritative autonomy level table and use it consistently.

Relevant areas:
- `packages/orchestration/autonomy_readiness.py`
- `packages/orchestration/autonomy_loop.py`
- `apps/cli/commands/do_cmd.py`
- `apps/cli/command_catalog.py`
- `tests/test_autonomy_readiness.py`
- `tests/test_step_66_67_68_event_stop_autonomy.py`

Proposed changes:
- Move autonomy level definitions into a shared module or import the `LEVELS` table from one source.
- Update `_decide()` in `autonomy_loop.py` to match readiness level names and gates.
- Update help text for `--autonomy-level` if behavior changes.
- Add tests asserting readiness and loop labels/decisions agree for levels 0 through 7.

Acceptance criteria:
- Level numbers have the same meaning in readiness output, loop decisions, and CLI help.
- Tests fail if either module redefines divergent level names.
- Existing blocked/future levels remain conservative.

Priority rationale:
Autonomy gates are safety-critical; semantic drift can cause incorrect automation decisions.

## Task 06: Consolidate or quarantine the legacy structured source patch applier

Impact: High  
Effort: Medium  

Context:
`packages/orchestration/patch_apply.py` is the current approval-gated markdown patch intent applier and checks `Capability.repo_generated_write`. `packages/orchestration/source_apply.py` is a separate structured code patch applier that writes, modifies, and snapshots files without checking job permissions.

Problem:
There are two repo mutation paths with different safety contracts. The older source applier can apply broader file operations and unified diffs without the same permission model, approval queue, or command catalog clarity.

Goal:
Ensure all repository mutation flows pass through one explicit permission and approval boundary.

Relevant areas:
- `packages/orchestration/source_apply.py`
- `packages/orchestration/patch_apply.py`
- `packages/orchestration/permissions.py`
- `apps/cli/commands/patch.py`
- `tests/test_patch_apply.py`
- `tests/test_steps_127_134.py`

Proposed changes:
- Decide whether `source_apply.py` is active or legacy; document that decision in module docstring and architecture docs.
- If active, require a `Job`, verify approval state, and check the appropriate capability before any write.
- If legacy, remove CLI reachability and add tests proving no public command calls it.
- Remove unused imports and replace ad-hoc event writing with `RunLogWriter` if the module remains.

Acceptance criteria:
- No repo mutation helper can write without an explicit capability check.
- Tests cover blocked behavior when permission is denied.
- The public patch application path is unambiguous.

Priority rationale:
Multiple mutation paths with different gates are a high-risk architecture smell in a safety-focused project.

## Task 07: Add bounded raw-output storage to local test execution

Impact: Medium  
Effort: Medium  

Context:
`packages/orchestration/test_runner.py` intentionally excludes raw stdout/stderr from structured records, but writes the full combined subprocess output into `workspace_root/test_runs/<run_id>.txt`.

Problem:
A noisy or hanging test command can produce very large output before timeout. The record stores byte counts after writing, but there is no maximum output size or truncation marker.

Goal:
Bound workspace growth while preserving enough diagnostic output for humans.

Relevant areas:
- `packages/orchestration/test_runner.py`
- `apps/cli/commands/test_cmds.py`
- `packages/orchestration/run_log.py`
- `tests/test_test_runner.py`

Proposed changes:
- Introduce a maximum persisted output size, e.g. 1 MiB, in `test_runner.py`.
- Truncate captured output before writing and append a clear `[remedy output truncated]` marker.
- Add `output_truncated` and original byte count fields to `TestRunRecord` and safe run-log metadata.
- Add tests for large stdout/stderr and timeout output truncation.

Acceptance criteria:
- Test output files never exceed the configured cap plus marker overhead.
- Structured records reveal whether truncation happened without exposing raw output.
- Existing pass/fail/blocked behavior remains unchanged.

Priority rationale:
The test runner is one of the few command-execution paths; bounded resource usage is required before broader autonomy.

## Task 08: Harden Project Constitution command parsing with `shlex` and shell metacharacter rejection

Impact: Medium  
Effort: Medium  

Context:
`packages/orchestration/command_discovery.py` converts Project Constitution commands into argv using `stripped.split()`. Other discovery paths construct argv tuples directly.

Problem:
Simple splitting mishandles quotes and can misrepresent commands. It also does not explicitly reject shell metacharacters in constitution-provided commands, even though the test runner later executes argv without `shell=True`.

Goal:
Parse explicit constitution commands accurately and conservatively.

Relevant areas:
- `packages/orchestration/command_discovery.py`
- `packages/orchestration/project_constitution.py`
- `packages/orchestration/test_runner.py`
- `tests/test_command_discovery.py`

Proposed changes:
- Replace `.split()` with `shlex.split()` for constitution command strings.
- Reject or mark high-risk any command containing shell control operators such as `|`, `&&`, `;`, redirects, backticks, or `$()` before candidate execution.
- Add tests for quoted args, pipes, chained commands, and normal `python -m pytest -q` commands.

Acceptance criteria:
- Quoted constitution commands produce correct argv arrays.
- Shell-composed commands are not selected for execution.
- No command discovery path uses `shell=True`.

Priority rationale:
Constitution commands are treated as high-confidence signals, so their parsing must be precise and conservative.

## Task 09: Add a generated-command contract test for all UI, guidance, and error-path command strings

Impact: Medium  
Effort: Medium  

Context:
Command strings are emitted from several places: CLI error messages, `ui_view_model.py` next actions, guidance cards, cockpit/trust reports, and tests. At least two current strings are invalid: wrong `job permit` order and nonexistent `test list`.

Problem:
The command catalog is the source of truth, but generated command strings are not systematically validated against it.

Goal:
Prevent future drift between generated guidance and actual CLI commands.

Relevant areas:
- `apps/cli/command_catalog.py`
- `packages/orchestration/ui_view_model.py`
- `packages/orchestration/guidance.py`
- `packages/orchestration/cockpit.py`
- `packages/orchestration/trust_report.py`
- `tests/test_command_catalog.py`

Proposed changes:
- Create a helper in tests that parses generated strings beginning with `remedy ` and checks group/subcommand against `CATALOG`.
- Add fixtures for common job states: permission denied, failed test, pending approval, pending memory candidate, reviewer suggestion, and normal pending task.
- Validate generated commands from view-model and guidance functions.
- Keep argument validation shallow at first: command existence and obvious argument order for known commands.

Acceptance criteria:
- The test fails on `remedy test list` and wrong `job permit` ordering before fixes.
- All generated command strings in covered states map to catalog entries after fixes.
- Future new guidance surfaces can reuse the helper.

Priority rationale:
The project is command-driven; generated instructions must be executable.

## Task 10: Add repository hygiene checks for generated artifacts and dependency directories

Impact: Medium  
Effort: Low  

Context:
The working tree contains generated/cache-heavy paths such as `apps/ui/node_modules`, `apps/ui/dist`, Python `__pycache__`, `.pytest_cache`, `.data`, and `.brain`. `.gitignore` ignores most of these, but accidental inclusion would make reviews huge and risky.

Problem:
The project relies on ignore rules and human discipline. There is no smoke check that generated dependency/build/cache directories remain untracked.

Goal:
Add a fast hygiene guard that fails if generated artifacts are tracked or staged.

Relevant areas:
- `.gitignore`
- `scripts/remedy_smoke.sh`
- `tests/test_step_62_1_hygiene.py`
- `tests/test_remedy_smoke_script.py`

Proposed changes:
- Add a smoke-test section that runs `git ls-files` for forbidden path patterns such as `apps/ui/node_modules/`, `.data/`, `.brain/`, `__pycache__/`, `.pytest_cache/`, and `apps/ui/dist/` if dist is not intentionally versioned.
- Document any intentional exception in the test itself.
- Add a Python test for the smoke script text so future edits preserve the guard.

Acceptance criteria:
- The smoke script fails if a forbidden generated path is tracked.
- The test suite verifies the forbidden path list includes frontend dependencies, Python caches, Remedy local data, and brainstorm runs.
- Legitimate source files are unaffected.

Priority rationale:
The repository already has many generated local directories; a cheap guard prevents accidental large or sensitive diffs.
