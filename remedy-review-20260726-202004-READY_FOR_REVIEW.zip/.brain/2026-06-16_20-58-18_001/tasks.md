# Brainstorm Tasks — Getting Remedy to the Next Level

## Task 01: Implement Claude Agent SDK Builder Provider

Impact: High
Effort: Medium

Context:
Remedy has a complete builder/planner protocol system, adapter registry (main_builder_adapter.py, 963 lines), session lifecycle, trust verification, and routing policy. But the only active provider is OllamaBuilder (packages/providers/ollama_builder/provider.py). The claude_agent namespace is a reserved stub with zero implementation. The main_builder_adapter already defines adapter specs for "claude_code", "pi_dev", "opencode", and "generic_cli" but all are disabled by default with no backing code.

Problem:
Remedy's entire expensive-builder routing layer, trust verification pipeline, token economy, and builder evaluation framework are built but have no real external provider to exercise them. The Ollama builder is local-only with limited capability. The system cannot actually perform high-quality code generation for real-world tasks.

Goal:
Implement a concrete Claude Agent SDK provider that conforms to the existing BuilderOutput contract and integrates with the main_builder_adapter session lifecycle.

Relevant areas:
- packages/providers/claude_agent/__init__.py
- packages/orchestration/main_builder_adapter.py
- packages/orchestration/builder_models.py (TaskExecutionContext, BuilderOutput)
- packages/orchestration/external_builder_sandbox.py
- packages/orchestration/builder_routing.py
- packages/providers/ollama_builder/provider.py (reference implementation)

Proposed changes:
- Create packages/providers/claude_agent/provider.py with ClaudeAgentBuilder class
- Implement build(context: TaskExecutionContext) -> BuilderOutput using claude_agent_sdk
- Wire into main_builder_adapter registry as a real (not fixture) adapter
- Add REMEDY_CLAUDE_API_KEY / REMEDY_CLAUDE_MODEL env var resolution
- Add integration test gated behind @pytest.mark.real_claude marker
- Update pyproject.toml with optional `claude` dependency group

Acceptance criteria:
- ClaudeAgentBuilder produces valid BuilderOutput from TaskExecutionContext
- Session lifecycle (create -> started -> output -> intake) works end-to-end
- Builder routing can select Claude adapter when local is insufficient
- No secrets leaked in any public export or event metadata
- Existing Ollama tests still pass unchanged

Priority rationale:
This is the single highest-leverage unlock. The entire builder routing, trust verification, token economy, and repair loop infrastructure exists but has no powerful external builder to drive it. Adding Claude transforms Remedy from a local-only orchestrator to a real multi-provider system.

---

## Task 02: Resolve Async Contract vs. Sync Reality Mismatch

Impact: High
Effort: Medium

Context:
packages/contracts/interfaces.py defines all 5 core protocols with async methods: LLMWorker.execute(), LLMWorker.stream(), MemoryGateway.read/write/delete(), RuntimeProvider.run(), Verifier.verify(). However, grep across all 63,440 lines of packages/ shows ZERO async usage in orchestration. OllamaBuilder.build() is synchronous. local_gateway.py has async wrappers but orchestration never awaits them. The contracts are structurally impossible to satisfy in practice.

Problem:
Any new provider attempting to implement the Protocol interfaces must be async, but the orchestration layer that calls them is entirely synchronous. This creates a dead contract — the types promise async but the runtime is sync. Adding real async providers (Claude API, Docker) requires resolving this mismatch first.

Goal:
Decide sync-or-async and make contracts match reality. Either make orchestration async-capable or make contracts synchronous.

Relevant areas:
- packages/contracts/interfaces.py
- packages/orchestration/task_runner.py
- packages/orchestration/agent_loop.py
- packages/orchestration/autorun.py
- packages/providers/ollama_builder/provider.py
- packages/memory/local_gateway.py

Proposed changes:
- Option A (recommended): Make contracts synchronous Protocol. Add async variants as separate AsyncLLMWorker etc. for future use. This matches reality and unblocks providers immediately.
- Option B: Make orchestration async (asyncio.run at CLI boundary). Higher effort, higher payoff long-term.
- Whichever path: update all existing conforming implementations
- Add contract conformance test: assert isinstance(OllamaBuilder(), LLMWorker) must pass
- Document the decision in docs/architecture.md

Acceptance criteria:
- All Protocol interfaces are satisfiable by at least one real implementation
- isinstance() checks pass for existing providers against their contracts
- No runtime errors from sync/async mismatch
- Architecture docs updated with the decision and rationale

Priority rationale:
This blocks provider integration. Every new provider hits the same mismatch. Fixing it first makes Task 01 (Claude provider) and Task 09 (memory upgrade) cleaner.

---

## Task 03: Split Orchestration Into Sub-Packages

Impact: High
Effort: High

Context:
packages/orchestration/ contains 100+ Python files in a single flat directory totaling 61,843 lines. Modules range from 50 to 2,620 lines. Many share cross-cutting patterns (_scrub_public, _safe_path_label imported from provider_trust.py). The directory has no sub-packages — every module is a sibling.

Problem:
Navigating, understanding, and maintaining 100+ flat files is increasingly difficult. Related modules (repair_loop.py, repair_loop_v2.py, repair_context.py, repair_request_builder.py) are not grouped. The overnight family (overnight_executor.py, overnight_mission.py, overnight_readiness.py) is similarly scattered. New contributors cannot discover module relationships from directory structure alone.

Goal:
Organize orchestration/ into logical sub-packages while preserving all existing import paths via __init__.py re-exports.

Relevant areas:
- packages/orchestration/ (entire directory)
- All test files importing from packages.orchestration.*
- apps/cli/commands/ (all handler imports)

Proposed changes:
- Create sub-packages: repair/, overnight/, builder/, ui/, brain/, testing/, events/
- Move related modules into each sub-package
- Add __init__.py re-exports to preserve backward compatibility
- Run full test suite to verify zero import breakage
- Update docs/architecture.md package roles section

Acceptance criteria:
- All 6,013 existing tests pass without modification
- No circular imports introduced
- Each sub-package has a clear boundary documented in its __init__.py
- Import paths from apps/ and tests/ still work (via re-exports)

Priority rationale:
Orchestration is where all new work happens. Every future task is harder in a 100-file flat directory. Splitting now compounds in value across all future development.

---

## Task 04: Replace Broad Exception Catches with Specific Handlers

Impact: High
Effort: Medium

Context:
autorun.py has 7 `except Exception` catches. overnight_executor.py has 11. overnight_mission.py has 5. Total: 99 except clauses across 20 orchestration files. Many catch Exception and silently continue or log a generic error string. The safety-first philosophy of the codebase (no shell=True, no raw content leaks, mandatory snapshots) is undermined by exception swallowing in the execution paths.

Problem:
When an overnight execution or autorun cycle fails, the broad catch masks the real error. Debugging requires reading event logs to reconstruct what happened. Specific exceptions (FileNotFoundError, PermissionError, json.JSONDecodeError, pydantic.ValidationError) should have distinct handling — some are retryable, some are fatal, some indicate configuration errors.

Goal:
Replace bare `except Exception` with specific exception handlers in critical execution paths. Add structured error categorization to run events.

Relevant areas:
- packages/orchestration/autorun.py (7 catches)
- packages/orchestration/overnight_executor.py (11 catches)
- packages/orchestration/overnight_mission.py (5 catches)
- packages/orchestration/integrity_gate.py (3 catches)
- packages/orchestration/local_candidate_generator.py (13 catches)

Proposed changes:
- Audit each except Exception in the 5 modules above
- Replace with specific exception types where the failure mode is known
- For genuinely unknown errors, keep except Exception but add error categorization (category: "io_error" | "validation_error" | "permission_error" | "unknown")
- Emit error category in run-event metadata
- Add regression tests that verify specific exceptions propagate correctly

Acceptance criteria:
- Zero bare `except Exception` in autorun.py and overnight_executor.py
- Each catch site documents what exceptions it expects
- Run events include error_category field for failures
- No behavioral regression (existing error paths still stop/report correctly)

Priority rationale:
Silent failure is the #1 operational risk in overnight/autorun execution. Users cannot trust unattended runs if errors are swallowed. This directly improves operator confidence.

---

## Task 05: Build a Configuration System (remedy.toml)

Impact: High
Effort: Medium

Context:
All configuration is via environment variables. There are 57+ env vars across the codebase: REMEDY_DATA_DIR, REMEDY_OLLAMA_MODEL, REMEDY_OLLAMA_BUILDER_MODEL, REMEDY_OLLAMA_BUILDER_TEMPERATURE, REMEDY_OLLAMA_HOST, etc. Each provider role adds 3-5 more. There is no config file, no `remedy config` command, no defaults file, no way to discover what can be configured.

Problem:
Operators must know exact env var names, set them per-shell, and cannot persist project-level configuration. Adding a new provider (Claude) will add 5+ more env vars. The env-var-only approach doesn't scale past a handful of settings.

Goal:
Introduce a remedy.toml configuration file with a `remedy config` CLI command, while keeping env var overrides for backward compatibility.

Relevant areas:
- pyproject.toml (project metadata)
- packages/orchestration/data_paths.py (REMEDY_DATA_DIR resolution)
- packages/providers/ollama_builder/provider.py (_resolve_model, env var parsing)
- packages/providers/ollama_planner/provider.py (same pattern)
- apps/cli/commands/ (potential config command)
- apps/cli/command_catalog.py

Proposed changes:
- Create packages/orchestration/config.py with load_config(path=None) -> RemedyConfig
- Support remedy.toml in project root and ~/.config/remedy/config.toml (user-level)
- Precedence: env var > project remedy.toml > user config.toml > built-in defaults
- Add `remedy config show` and `remedy config set` CLI commands
- Migrate existing env var resolution to use config layer
- Add config discovery to `remedy config list` (show all available keys)

Acceptance criteria:
- `remedy config show` displays all current config with sources
- Setting a value in remedy.toml takes effect without env var
- Env var still overrides remedy.toml when set
- OllamaBuilder resolves model from config when env var is unset
- All existing env var behavior preserved (backward compatible)

Priority rationale:
Configuration is a daily operator pain point. Every new provider, every new feature adds more env vars. A config system is infrastructure that pays dividends across all future work.

---

## Task 06: Split ui_server.py Into Focused Modules

Impact: Medium
Effort: Medium

Context:
packages/orchestration/ui_server.py is 2,620 lines with 80 functions. It contains: HTTP request handler, URL routing, token auth, safe data builders for every API endpoint, HTML app shell generation, auto-build logic for the Vite frontend, and browser opener. It's a monolith in a system that prizes modularity.

Problem:
Any change to the UI server requires reading 2,620 lines of context. Adding a new endpoint means modifying the same file that handles auth, routing, and data building. The file violates the project's own principle of keeping modules focused and small.

Goal:
Split ui_server.py into focused modules: routing, auth, data builders, app shell, and server lifecycle.

Relevant areas:
- packages/orchestration/ui_server.py (2,620 lines)
- packages/orchestration/ui_view_model.py (1,127 lines)
- packages/orchestration/ui_app_shell.py
- packages/orchestration/ui_copy.py
- tests/ui_server/ (7 test files)

Proposed changes:
- Extract URL routing into ui_router.py
- Extract token auth into ui_auth.py
- Extract safe data builders into ui_data_builders.py
- Keep ui_server.py as the thin entry point (start_ui_server + HTTPServer setup)
- Update imports in test files
- Verify all 7 ui_server test files still pass

Acceptance criteria:
- ui_server.py is under 300 lines (entry point only)
- Each extracted module has a clear single responsibility
- All ui_server tests pass without modification (or with import-only changes)
- No new endpoints or behavioral changes

Priority rationale:
The UI server is the primary operator interface. Making it maintainable enables faster iteration on the cockpit — which is the user-facing product surface.

---

## Task 07: Add Server-Sent Events (SSE) to UI Server

Impact: Medium
Effort: Medium

Context:
RemedyApp.tsx polls the server every 5 seconds via setInterval. ui_server.py is read-only (GET only). The run-log timeline (packages/orchestration/timeline.py) appends events to JSONL files. The UI has no way to receive real-time updates — it must poll and re-fetch the entire dashboard payload.

Problem:
5-second polling creates unnecessary load, misses sub-second state changes, and prevents real-time feedback during builder execution, test runs, and repair loops. The overnight executor and autorun loop emit events that could stream to the UI instantly.

Goal:
Add an SSE endpoint to ui_server.py that streams new run-log events to connected UI clients.

Relevant areas:
- packages/orchestration/ui_server.py (HTTP handler)
- packages/orchestration/timeline.py (event append/load)
- apps/ui/src/api/remedyApi.ts (API client)
- apps/ui/src/RemedyApp.tsx (polling logic)

Proposed changes:
- Add GET /api/events/stream SSE endpoint to ui_server.py
- Tail the JSONL event file and push new events as SSE messages
- Add EventSource client in remedyApi.ts
- Update RemedyApp.tsx to use SSE for incremental updates, fall back to polling
- Token-gate the SSE endpoint same as existing API
- Add test for SSE connection and event delivery

Acceptance criteria:
- New run-log events appear in UI within 1 second (no polling delay)
- SSE endpoint respects token auth
- Graceful fallback to polling if SSE connection fails
- No raw content/secrets in SSE payloads (reuse existing redaction)
- Existing polling still works as fallback

Priority rationale:
Real-time feedback transforms the operator experience. Builder execution, test runs, and repair loops become observable live instead of stale-by-5-seconds.

---

## Task 08: Retire repair_loop v0 and Consolidate Into v2

Impact: Medium
Effort: Low

Context:
Two repair loop implementations coexist: repair_loop.py (1,466 lines, v0) and repair_loop_v2.py (1,168 lines, v2). v0 docstring says "No real provider. No automatic apply. No test execution." v2 adds token-aware repair, real provider routing, and structured repair context. Both are imported in different code paths — v0 from repair_cmd.py, v2 from repair_loop_v2_cmd.py.

Problem:
Maintaining 2,634 lines of repair loop code across two versions increases cognitive load and bug surface. v0's limitations (no provider, no apply, no test) are superseded by v2. Having two versions confuses the CLI (separate commands for v0 and v2).

Goal:
Retire repair_loop.py (v0), migrate any remaining callers to v2, and unify the CLI surface.

Relevant areas:
- packages/orchestration/repair_loop.py (v0, 1,466 lines)
- packages/orchestration/repair_loop_v2.py (v2, 1,168 lines)
- apps/cli/commands/repair_cmd.py (v0 CLI)
- apps/cli/commands/repair_loop_v2_cmd.py (v2 CLI)
- tests/orchestration/test_builder_repair_loop.py
- tests/orchestration/test_repair_loop_v2.py
- tests/orchestration/test_repair_loop_hardened.py

Proposed changes:
- Audit all import sites of repair_loop.py — identify any v0-only functionality
- Migrate remaining v0 callers to v2 equivalents
- Merge repair_cmd.py and repair_loop_v2_cmd.py into a single `remedy repair` command
- Delete repair_loop.py
- Rename repair_loop_v2.py to repair_loop.py (or keep as-is with v0 removed)
- Update tests to reflect the unified surface

Acceptance criteria:
- repair_loop.py (v0) is deleted
- All repair functionality available through a single `remedy repair` command
- All repair-related tests pass
- No orphaned imports referencing deleted module

Priority rationale:
Low effort, immediate code reduction (1,466 lines). Removes confusion about which repair loop to use. Clears space for future repair improvements on a single codebase.

---

## Task 09: Upgrade Memory Layer to Semantic Search

Impact: Medium
Effort: High

Context:
packages/memory/local_gateway.py uses JSONL storage with keyword/recency matching for recall. No embeddings, no vector search, no relevance scoring beyond string containment. The MemPalace provider stub exists but has no implementation. Memory entries are stored as flat JSONL with metadata tags.

Problem:
Keyword matching fails for semantic queries ("what did we learn about test flakiness" won't match an entry about "intermittent CI failures"). As the memory store grows, recall quality degrades — more entries means more false positives from keyword overlap. The memory layer is the weakest link in the repair loop (repair_context.py reads prior memories to inform fixes).

Goal:
Add embedding-based semantic search to the memory gateway, using a local embedding model (e.g., sentence-transformers via Ollama embeddings API or a lightweight local model).

Relevant areas:
- packages/memory/local_gateway.py (430 lines)
- packages/memory/models.py
- packages/contracts/interfaces.py (MemoryGateway protocol)
- packages/orchestration/repair_context.py (memory consumer)
- packages/orchestration/memory_learn.py (memory producer)
- packages/orchestration/memory_candidates.py

Proposed changes:
- Add packages/memory/embedding_gateway.py with vector search
- Use Ollama embeddings API (already a dependency) or sentence-transformers
- Store embeddings alongside JSONL entries in a lightweight format (numpy array or JSON list)
- Add hybrid search: keyword filter + embedding similarity ranking
- Keep local_gateway as fallback when no embedding model is available
- Add integration test with @pytest.mark.real_ollama for embedding generation

Acceptance criteria:
- Semantic query "test failures" retrieves entry about "intermittent CI failures"
- Keyword search still works as before (backward compatible)
- Embedding generation uses existing Ollama infrastructure (no new external dependency required)
- Memory redaction blocklist still enforced on all writes
- Recall quality measurably improves on a test corpus of 20+ diverse entries

Priority rationale:
Memory quality directly affects repair loop effectiveness. Better recall means better repair context, which means fewer repair cycles and less token waste. This compounds with every repair loop invocation.

---

## Task 10: Update README to Reflect Current System State

Impact: Low
Effort: Low

Context:
README.md is 590 lines, structured as a step-by-step changelog from Step 1 through Step 10. The "What Is NOT Implemented Yet" section at line 562 lists: "Agent loops, Provider implementations (Claude, MemPalace), Docker or sandboxed runtime, LLM-backed verification, Configuration system." Many of these ARE now implemented — agent_loop.py, autorun.py, repair loops, overnight executor, builder routing, token economy, and more exist.

Problem:
The README gives new users and contributors a fundamentally wrong picture of the project. It implies Remedy is a Step 10 prototype when it's actually a 2,000+ step system with 63K lines of orchestration code, 6,013 tests, a UI, and sophisticated overnight execution.

Goal:
Rewrite README.md to reflect the actual current state of Remedy as a production-grade orchestration kernel.

Relevant areas:
- README.md (590 lines, outdated)
- docs/architecture.md (accurate, good reference)
- pyproject.toml (version, dependencies)
- apps/cli/command_catalog.py (current command surface)

Proposed changes:
- Replace step-by-step changelog with a current-state overview
- Document the actual architecture: orchestration, providers, memory, UI, CLI
- List real capabilities: autorun, overnight executor, repair loops, builder routing, token economy
- Keep "Quick Start" section with current CLI commands
- Move historical step changelog to docs/changelog.md or remove entirely
- Update "What Is NOT Implemented" to reflect actual gaps (Docker, Claude provider, semantic memory)

Acceptance criteria:
- README accurately describes current Remedy capabilities
- No references to features as "not implemented" when they exist
- Quick Start section works with current CLI
- Under 200 lines (concise, not a changelog)

Priority rationale:
Low effort, high signal improvement. First thing anyone sees. Current README actively misleads about project maturity. Quick win that improves perception and onboarding.
