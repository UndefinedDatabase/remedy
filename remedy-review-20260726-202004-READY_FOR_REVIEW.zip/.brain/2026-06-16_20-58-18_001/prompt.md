Review the codebase and tell me how to get remedy to the next level
