# Sources

## Files Read
- packages/core/models.py (full)
- packages/contracts/interfaces.py (full)
- packages/orchestration/__init__.py
- packages/orchestration/agent_loop.py (first 80 lines)
- packages/orchestration/autonomy_loop.py (first 80 lines)
- packages/orchestration/overnight_executor.py (first 80 lines)
- packages/orchestration/repair_loop.py (first 80 lines)
- packages/orchestration/repair_loop_v2.py (partial)
- packages/orchestration/ui_server.py (first 80 lines)
- packages/orchestration/token_economy.py (first 80 lines)
- packages/orchestration/main_builder_adapter.py (first 80 lines)
- packages/orchestration/builder_routing.py (first 80 lines)
- packages/orchestration/project_brain.py (first 80 lines)
- packages/orchestration/do_continue.py (first 80 lines)
- packages/orchestration/progress_ledger.py (first 80 lines)
- packages/orchestration/autorun.py (first 60 lines)
- packages/orchestration/test_execution_service.py (first 60 lines)
- packages/orchestration/repository_snapshot.py (first 60 lines)
- packages/orchestration/review_bundle.py (first 60 lines)
- packages/orchestration/source_apply.py (first 60 lines)
- packages/memory/local_gateway.py (first 80 lines)
- packages/providers/ollama_builder/provider.py (full)
- packages/providers/claude_agent/__init__.py (full)
- packages/providers/docker_runtime/__init__.py (full)
- packages/providers/mempalace/__init__.py (full)
- apps/cli/grouped.py (first 100 lines)
- apps/ui/src/RemedyApp.tsx (full)
- docs/architecture.md (first 100 lines)
- README.md (full)
- AGENTS.md (full)
- pyproject.toml (full)

## Searches Performed
- grep for async usage in orchestration (0 hits)
- grep for except Exception (99 across 20 files)
- grep for bare except: (1 hit, in a comment)
- grep for TODO/FIXME (5 hits — clean codebase)
- grep for shell=True (0 in production code, only in test assertions)
- function count per orchestration module (top 15)
- total line counts per package
- test file count (211) and test function count (6,013)
- provider file listing
- UI file listing
