# Critic Review

## Rejected Ideas (generic/ungrounded)
- "Add more tests" — already 6,013 tests, test coverage is strong
- "Add logging" — not evidence-backed, system uses event timeline instead
- "Improve documentation" — docs/ has 60+ files, well-maintained
- "Add CI/CD" — no evidence this is blocking anything
- "Refactor everything" — too vague, not actionable

## Kept (evidence-backed, high-impact)
1. Fix async mismatch — contracts unusable as-is, blocks real provider integration
2. Split orchestration into sub-packages — 100+ flat files is a maintenance hazard
3. Implement Claude Agent SDK provider — only stub exists, biggest capability unlock
4. Replace broad exception catches with specific handlers — silent failures in critical paths
5. Build configuration system — 57+ env vars with no discovery, no defaults file
6. Split ui_server.py monolith — 2620 lines, 80 functions, single file
7. Add SSE/WebSocket to UI — polling every 5s, no interactivity
8. Retire repair_loop v0 — dead code alongside v2, confusing
9. Upgrade memory to semantic search — keyword matching limits recall quality
10. Update README to reflect actual state — README stuck at Step 10, now at 2025+

## Ordering Rationale
- Async fix and provider integration unlock actual multi-provider execution
- Orchestration split reduces maintenance cost for everything else
- Config system improves operator experience immediately
- UI improvements make the cockpit usable for real workflows
