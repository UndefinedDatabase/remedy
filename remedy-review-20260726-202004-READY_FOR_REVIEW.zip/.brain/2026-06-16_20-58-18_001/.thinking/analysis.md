# Analysis

## Signal 1: Async Contract / Sync Reality Mismatch
contracts/interfaces.py defines all protocols as `async def` (LLMWorker.execute, MemoryGateway.read, etc.)
but ZERO orchestration code uses async. Even the OllamaBuilder.build() is synchronous.
The local_gateway has `async def` wrappers but the orchestration never awaits them.
This creates a dead protocol layer — conforming to the Protocol is impossible without async.

## Signal 2: Orchestration Module Explosion
61,843 lines across 100+ files in one flat directory. No sub-packages.
Many modules duplicate patterns: _scrub_public, _safe_path_label imported from provider_trust.
ui_server.py alone is 2,620 lines with 80 functions — a monolith within the modular architecture.
progress_ledger.py is 2,088 lines. These are maintenance liabilities.

## Signal 3: Single Active Provider
Only Ollama is implemented. Claude Agent, Docker Runtime, MemPalace all stubs.
The main_builder_adapter.py (963 lines) builds elaborate adapter registry/session lifecycle
for builders that don't exist yet. Heavy infrastructure for future providers.

## Signal 4: Broad Exception Swallowing
autorun.py: 7x `except Exception`
overnight_executor.py: 11x `except Exception`
overnight_mission.py: 5x `except Exception`
These mask real errors. The safety-first design philosophy clashes with silent failure.

## Signal 5: No Configuration System
Everything is env vars. No config file, no TOML/YAML, no defaults file.
57+ env vars across the codebase (REMEDY_OLLAMA_*, REMEDY_DATA_DIR, etc.)
Users must set many env vars for non-default behavior. No `remedy config` command.

## Signal 6: CLI Arg Dispatch is a Manual If/Elif Chain
grouped.py lines 58-160: every new --flag requires a new elif branch.
This doesn't scale and is error-prone.

## Signal 7: UI is Polling-Only, Read-Only
RemedyApp.tsx polls every 5 seconds. No SSE, no WebSocket.
ui_server.py is read-only (no POST/PUT/DELETE).
No way to approve patches, trigger builds, or interact from the UI.

## Signal 8: Repair Loop v0 + v2 Coexist
repair_loop.py (1,466 lines, v0) and repair_loop_v2.py (1,168 lines) both exist.
v0 is "no real provider, no automatic apply, no test execution."
v2 adds token-aware repair. But v0 is still imported and used.

## Signal 9: Memory Layer is Keyword-Only
local_gateway.py uses keyword/recency matching (no embeddings).
No semantic search. No relevance scoring beyond keyword overlap.
Memory recall quality is fundamentally limited.

## Signal 10: README is Outdated
README.md still says "What Is NOT Implemented Yet" listing agent loops,
provider implementations, Docker — many of which ARE now implemented.
~590 lines, written for Step 10 era, now at Step 2025+.
