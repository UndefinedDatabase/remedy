# Relevant Files

## Core Domain
- packages/core/models.py — 7 models, Pydantic
- packages/contracts/interfaces.py — 5 Protocol interfaces (all async, none used)

## Orchestration Hot Spots
- packages/orchestration/autorun.py — main `remedy do` loop, 7 broad `except Exception` catches
- packages/orchestration/ui_server.py — 2620 lines, monolithic HTTP handler
- packages/orchestration/overnight_executor.py — 1118 lines, 11 except Exception catches
- packages/orchestration/repair_loop.py — 1466 lines, v0 still present alongside v2
- packages/orchestration/repair_loop_v2.py — 1168 lines

## Provider Layer
- packages/providers/ollama_builder/provider.py — 312 lines, only real provider
- packages/providers/claude_agent/__init__.py — stub
- packages/providers/docker_runtime/__init__.py — stub
- packages/providers/mempalace/__init__.py — stub

## CLI
- apps/cli/grouped.py — 407 lines, hardcoded arg dispatch (if/elif chain)
- apps/cli/commands/ — 48 handler files

## UI
- apps/ui/src/RemedyApp.tsx — 38 lines, polling every 5s
- apps/ui/src/api/remedyApi.ts — 530 lines

## Memory
- packages/memory/local_gateway.py — 430 lines, JSONL, keyword matching
