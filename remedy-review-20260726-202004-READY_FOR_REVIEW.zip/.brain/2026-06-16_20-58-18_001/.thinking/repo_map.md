# Repo Map

## Stats
- 63,440 lines Python in packages/
- 211 test files, 6,013 test functions
- 100+ orchestration modules
- 48 CLI command files
- 1 active provider (Ollama), 3 reserved stubs (Claude, Docker, MemPalace)

## Key Packages
- packages/core/models.py (139 lines) — Job, Task, Artifact, RunState, Budget
- packages/contracts/interfaces.py (114 lines) — LLMWorker, MemoryGateway, RuntimeProvider, Verifier (all async Protocol)
- packages/orchestration/ (61,843 lines) — entire orchestration layer, 100+ modules
- packages/memory/ — local JSONL gateway, keyword recall
- packages/providers/ollama_builder/ — only active provider
- apps/cli/ — grouped CLI, 48 command files
- apps/ui/ — React/Vite SPA, MUI, polling-based

## Largest Orchestration Modules
- ui_server.py: 2,620 lines / 80 functions
- review_bundle.py: 2,138 lines
- progress_ledger.py: 2,088 lines
- brain_detail.py: 1,737 lines
- repository_snapshot.py: 1,650 lines
- repair_loop.py: 1,466 lines

## Architecture Pattern
- Synchronous-only execution (contracts define async but nothing uses it)
- Dataclass-heavy models (not Pydantic in orchestration)
- File-based persistence (JSONL, JSON)
- No database
- No config file system (env vars only)
- No dependency injection framework
- Lazy imports to avoid circular deps
