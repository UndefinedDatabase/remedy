## Task 01: Ship a Real External Worker Harness Adapter

Impact: High | Medium | Low  
Effort: High | Medium | Low  

Context:
Remedy already models worker providers in `packages/orchestration/worker_adapters.py`, but `claude_code`, `pi_dev`, `copilot`, and `openai_api` are marked `future`. `packages/orchestration/task_execution.py` only executes `fixture` and `none`; `ollama` is allowed but returns provider unavailable through `get_executor()`.

Problem:
The project has a strong orchestration kernel but cannot yet delegate real repository work to the external coding harnesses it advertises.

Goal:
Add one production-grade external worker adapter path, starting with a `claude_code` or generic local-harness executor that can be invoked safely through the existing task execution port.

Relevant areas:
- `packages/orchestration/task_execution.py`
- `packages/orchestration/worker_adapters.py`
- `packages/orchestration/builder_bridge.py`
- `apps/cli/commands/do_cmd.py`
- `tests/orchestration/test_worker_execution.py`

Proposed changes:
- Add a `HarnessTaskExecutor` implementing the existing `TaskExecutor` protocol with explicit command, cwd, timeout, environment allowlist, and redacted output handling.
- Extend `TaskExecutionRequest` with safe harness fields without exposing secrets or raw prompt dumps.
- Register the new provider in `_EXECUTORS` and update `ALLOWED_PROVIDERS` / CLI provider validation.
- Emit safe run-log events for harness start, completion, timeout, and blocked execution.
- Add tests for unavailable binary, timeout, success, redaction, and no shell injection.

Acceptance criteria:
- `remedy do ... --builder-provider claude_code` or equivalent returns a structured blocked/success result instead of `provider_unavailable`.
- Harness execution never uses `shell=True` and only runs inside the attached repo or a safe workspace.
- Run-log metadata contains provider, status, duration, and safe summary, but no raw stdout/stderr or secrets.
- Existing fixture and none providers continue to pass their tests.

Priority rationale:
This turns Remedy from a mostly local orchestration prototype into a real multi-agent coding platform while preserving the provider boundary that the architecture already defines.

## Task 02: Make `remedy do` a Complete Approval-Gated Autonomous Development Run

Impact: High | Medium | Low  
Effort: High | Medium | Low  

Context:
`apps/cli/commands/do_cmd.py` exposes a high-level `remedy do` command. `packages/orchestration/autorun.py` already creates jobs, attaches repos, injects context, invokes builders, creates patch intents, applies patches, and optionally tests, but the flow is fragmented and often stops at `builder_skipped_no_worker` or approval boundaries.

Problem:
The flagship command does not yet feel like a finished product flow from goal to verified change.

Goal:
Implement a cohesive bounded loop for `remedy do` that progresses through plan, context, build, approval, apply, test, proof, and stop reason reporting using existing gates.

Relevant areas:
- `packages/orchestration/autorun.py`
- `packages/orchestration/autonomy_loop.py`
- `packages/orchestration/builder_bridge.py`
- `packages/orchestration/stop_reasons.py`
- `apps/cli/commands/do_cmd.py`
- `tests/orchestration/test_autonomy.py`

Proposed changes:
- Refactor `run_autorun()` into explicit phase functions with one structured `AutorunResult` contract.
- Reuse `run_autonomy_loop()` decisions for level checks instead of duplicating autonomy semantics.
- Persist every phase transition to the event ledger with safe metadata.
- Add a `--continue <job_id>` path that resumes from persisted state instead of creating a new job.
- Add JSON output fields for current phase, next safe command, approval IDs, test summary, and proof IDs.

Acceptance criteria:
- A fixture-backed `remedy do --fixture-builder true --autonomy-level 4 --json` produces a job, patch intent, apply result, test result, proof event, and final next action.
- A run blocked by approval returns the exact intent ID and a copyable approval command.
- `--continue` resumes the same job without duplicating already completed phases.
- Tests cover success, approval block, test failure, and resume idempotency.

Priority rationale:
A single trusted command is the product wedge: it converts the many existing primitives into a memorable user experience.

## Task 03: Build an Interactive Proof Chain and Replay System

Impact: High | Medium | Low  
Effort: Medium | Medium | Low  

Context:
Remedy already has safe event normalization in `packages/orchestration/event_ledger.py`, run logs, patch apply records, proof events, and `event_replay.py` tests. The UI and CLI expose events, but users cannot yet replay a change from goal to proof as a coherent story.

Problem:
Trust signals are scattered across events, artifacts, patch records, test results, and memory entries.

Goal:
Create a first-class proof chain that reconstructs why a change happened, who approved it, what files changed, what tests verified it, and what remains risky.

Relevant areas:
- `packages/orchestration/event_ledger.py`
- `packages/orchestration/event_replay.py`
- `packages/orchestration/change_set.py`
- `packages/orchestration/file_provenance.py`
- `apps/cli/commands/change.py`
- `tests/orchestration/test_event_replay.py`

Proposed changes:
- Add a `build_proof_chain(job, events, intent_id=None)` function returning a redacted ordered graph of goal → task → artifact → intent → approval → apply → test → proof.
- Add CLI output under the existing change or event command group with text and JSON forms.
- Include deterministic IDs and hashes so chains are stable across repeated queries.
- Surface missing proof gaps as explicit warnings, not silent omissions.
- Add tests for complete chain, missing approval, failed test, and redaction of raw content fields.

Acceptance criteria:
- `remedy change proof <job_id>` displays one compact proof chain per applied intent.
- JSON output contains no raw artifact content, diffs, stdout/stderr, or approval reasons.
- Proof chains identify unverified applied changes with a machine-readable `proof_status`.
- Event replay tests prove deterministic output for the same event list.

Priority rationale:
Proof chains are a killer trust feature: they make autonomous work reviewable and auditable instead of mysterious.

## Task 04: Add a Context Inspector That Shows Exactly What the Worker Will See

Impact: High | Medium | Low  
Effort: Medium | Medium | Low  

Context:
The architecture defines `TaskExecutionContext`; `source_context.py`, `context_pack.py`, `context_coverage.py`, and token policy modules already exist. The UI server forbids raw source/diff leakage and exposes safe summaries.

Problem:
Before running a worker, users cannot clearly inspect the scoped context, token budget, omitted files, and policy reasons that shape the model call.

Goal:
Add a safe preflight Context Inspector for CLI and UI that previews worker context without leaking raw source.

Relevant areas:
- `packages/orchestration/context_pack.py`
- `packages/orchestration/context_coverage.py`
- `packages/orchestration/token_policy.py`
- `packages/orchestration/source_context.py`
- `packages/orchestration/ui_server.py`
- `apps/ui/src/components/pipeline/ContextCard.tsx`

Proposed changes:
- Create a `build_context_inspection(job, task_id, events)` service returning included files as safe paths, coverage score, token estimate, exclusion reasons, and policy gates.
- Add `remedy context inspect <job_id> [task_id] --json`.
- Extend the UI dashboard payload with a compact `context_inspection` section.
- Update `ContextCard` to show included/excluded counts, budget status, and copyable next action.
- Add tests ensuring no file contents, prompt dumps, diffs, or secrets appear in output.

Acceptance criteria:
- CLI and UI show the same context coverage and token budget for a job.
- Excluded files have concrete reasons such as denied path, token budget, unsupported file type, or not relevant.
- Redaction tests fail if raw source content appears in the API response.
- Existing dashboard contract tests continue to pass.

Priority rationale:
Context visibility is the difference between blind agent execution and operator-grade control.

## Task 05: Implement Approval-Gated Project Memory With Evidence Cards

Impact: High | Medium | Low  
Effort: Medium | Medium | Low  

Context:
`packages/orchestration/memory_learn.py` can extract facts from test runs, apply proofs, command discovery, readiness, context coverage, and target repo metadata. `docs/project-brain.md` says memory suggestions require approval and patterns need evidence.

Problem:
Memory exists, but it is not yet a polished, reviewable learning loop users can trust across projects.

Goal:
Turn memory learning into an explicit queue of evidence cards that can be approved, rejected, searched, and reused in future planning/context selection.

Relevant areas:
- `packages/orchestration/memory_learn.py`
- `packages/memory/local_gateway.py`
- `packages/orchestration/project_brain.py`
- `apps/cli/commands/memory.py`
- `docs/project-brain.md`
- `tests/orchestration/test_memory_*`

Proposed changes:
- Add a memory proposal state model with evidence refs, source job, scope, confidence, and review status.
- Make `learn_from_job(..., approved=False)` create pending proposals by default, not silently approved project facts.
- Add CLI commands to list, show, approve, reject, and search memory proposals.
- Feed approved project memory into context selection and Project Brain summaries.
- Add tests for idempotency, approval transitions, evidence refs, project/job scoping, and safe summaries.

Acceptance criteria:
- Re-running memory learn on the same job updates existing proposals instead of creating duplicates.
- Approved memory appears in Project Brain and pending memory remains clearly marked as pending.
- Rejected memory is not used by context selection.
- No memory entry stores raw stdout, file content, diffs, or secrets.

Priority rationale:
Durable, evidence-backed learning can make Remedy compound in value across every run without weakening safety.

## Task 06: Create a Verifier Marketplace and Auto-Selected Quality Gates

Impact: High | Medium | Low  
Effort: Medium | Medium | Low  

Context:
`packages/orchestration/verifier_profiles.py` already has deterministic profiles (`generic`, `repo_doc`, `analysis_doc`, `implementation_plan`). `project_constitution.py` extracts test/build/lint commands and conventions. The patch pipeline already supports test execution and proof events.

Problem:
Verification is useful but shallow; top projects need task-specific, repo-specific, and language-aware gates.

Goal:
Introduce a verifier registry that selects deterministic checks based on task type, changed file type, project constitution, and available commands.

Relevant areas:
- `packages/orchestration/verifier_profiles.py`
- `packages/orchestration/verifier.py`
- `packages/orchestration/project_constitution.py`
- `packages/orchestration/test_runner.py`
- `apps/cli/commands/policy.py`
- `tests/test_verifier_profiles.py`

Proposed changes:
- Extend `VerifierProfile` with `applies_to_paths`, `required_commands`, `risk_rules`, and `proof_requirements`.
- Add profiles for Python code, TypeScript UI, docs, config files, tests, and dependency manifests.
- Select profiles from task type plus changed paths in patch intents/apply results.
- Add `remedy policy verifiers <job_id> --json` to explain which gates will run and why.
- Emit verifier selection events with safe metadata.

Acceptance criteria:
- A Python code patch requires Python-oriented checks when `pyproject.toml` or `tests/` are detected.
- A UI patch under `apps/ui/src` selects TypeScript/UI gates without hardcoding raw source content.
- CLI explains selected and skipped verifiers with concrete reasons.
- Tests cover unknown task fallback, docs profile, Python profile, UI profile, and manifest high-risk handling.

Priority rationale:
Automatic, explainable quality gates make Remedy feel professional and reduce the risk of autonomous changes.

## Task 07: Turn the Dashboard Into a Live Operator Cockpit

Impact: High | Medium | Low  
Effort: High | Medium | Low  

Context:
`docs/ui-target.md` defines a premium read-only dashboard with brain graph, phase timeline, right operator panel, and no fake data. `packages/orchestration/ui_server.py` already serves safe dashboard payloads; `apps/ui/src` contains graph, timeline, command bar, metrics, and panels.

Problem:
The UI is read-only and visually ambitious, but it does not yet provide a complete operator workflow for approvals, context inspection, proof chains, and next safe actions.

Goal:
Make the dashboard the primary command center for monitoring and safely driving Remedy runs while preserving the no-mutation API rule.

Relevant areas:
- `packages/orchestration/ui_server.py`
- `packages/orchestration/ui_view_model.py`
- `apps/ui/src/components/shell/RemedyShell.tsx`
- `apps/ui/src/components/command/CommandBar.tsx`
- `apps/ui/src/components/panels/RightLivePanel.tsx`
- `apps/ui/src/components/timeline/PhaseTimeline.tsx`
- `tests/ui_contracts/*`

Proposed changes:
- Extend dashboard payload with `next_safe_actions`, pending approvals, context inspection summary, proof chain summary, and verifier status.
- Update `CommandBar` to show copy-only commands for approval, continue, inspect context, run tests, and view proof.
- Add a right-panel card for pending decisions with risk, target path, and exact CLI command.
- Add graph highlighting for the selected proof chain and attention nodes.
- Preserve read-only HTTP semantics: no POST/PUT/DELETE and no repo mutation buttons.

Acceptance criteria:
- UI shows pending approval commands without exposing approval reasons or raw diffs.
- Timeline uses only real event ledger events and remains absent when no events exist.
- Graph selection can highlight a proof chain from task to test/proof.
- UI contract tests confirm no fake data, no raw content leakage, no mutation endpoints, and layout guards still pass.

Priority rationale:
A beautiful safety-first cockpit is the most visible differentiator and makes complex autonomy understandable.

## Task 08: Add Project Templates and One-Command Onboarding

Impact: Medium | Medium | Low  
Effort: Medium | Medium | Low  

Context:
`project_constitution.py` extracts repo conventions from known files. `command_catalog.py` already has project, context, policy, readiness, test, and dashboard command groups. `README.md` documents many commands, but onboarding still requires users to know the flow.

Problem:
New users must manually discover commands and configure projects before seeing value.

Goal:
Add `remedy project init` / onboarding templates that detect repo type, create a project, attach constitution, discover commands, set safe defaults, and print a guided next step.

Relevant areas:
- `apps/cli/command_catalog.py`
- `apps/cli/commands/project.py`
- `packages/orchestration/project_registry.py`
- `packages/orchestration/project_constitution.py`
- `packages/orchestration/command_discovery.py`
- `docs/autocoder-usage.md`
- `tests/cli/test_project_summary_cli.py`

Proposed changes:
- Add a `project init <repo_path>` command that creates or reuses a project record.
- Detect Python, Node/TypeScript, mixed monorepo, docs-only, and unknown templates from manifests.
- Store safe defaults for test commands, protected paths, risky paths, and recommended autonomy level.
- Print a concise onboarding summary and a copyable `remedy do` command.
- Add docs and tests for each template.

Acceptance criteria:
- Running project init twice is idempotent and does not duplicate projects.
- Python and UI repo signals are detected from existing manifests without shell execution.
- Output includes exact next commands for context inspection and first dry run.
- Tests verify protected/risky paths and discovered commands are persisted safely.

Priority rationale:
Fast onboarding makes Remedy easier to adopt and channels users into the safe operating model already present in the codebase.

## Task 09: Build a Local Model Quality and Routing Dashboard

Impact: Medium | Medium | Low  
Effort: Medium | Medium | Low  

Context:
`docs/project-brain.md` tracks model quality confidence and points to `scripts/remedy_builder_eval.sh --ollama`. The repo has `builder_eval.py`, Ollama providers, worker recommendations, and token policy modules.

Problem:
Users cannot easily compare local models, understand failure patterns, or route planner/builder/reviewer roles to the best available model.

Goal:
Create a model evaluation registry and dashboard that records structured local eval results and recommends role-specific model routing.

Relevant areas:
- `packages/orchestration/builder_eval.py`
- `packages/providers/ollama_builder/provider.py`
- `packages/providers/ollama_planner/provider.py`
- `packages/orchestration/worker_recommend.py`
- `packages/orchestration/project_brain_aggregate.py`
- `scripts/remedy_builder_eval.sh`
- `tests/orchestration/test_builder_eval.py`

Proposed changes:
- Persist eval samples with provider, model, role, task type, parse success, apply success, test success, latency, and stop reason.
- Add CLI commands to list model scores and recommend model per role.
- Feed real sample counts into Project Brain confidence instead of only low/medium/high summaries.
- Extend worker recommendation to use eval results when choosing local models.
- Add tests for sample aggregation, confidence thresholds, routing, and redaction.

Acceptance criteria:
- Running the eval script records structured samples in a deterministic local store.
- `remedy worker recommend --json` includes model choice evidence and confidence.
- Project Brain shows real sample counts and top failure mode per model.
- No eval output stores raw model completions, source content, or test stdout/stderr.

Priority rationale:
Model routing can make local-first autonomy dramatically better while staying aligned with Remedy's existing evidence and safety model.

## Task 10: Add Team-Safe Remote Review Bundles

Impact: Medium | Medium | Low  
Effort: Medium | Medium | Low  

Context:
The repository contains repeated `remedy-review-*.zip` artifacts and `scripts/make_review_zip.sh`, while the event ledger, proof chain, UI payload, and patch apply records already support redacted summaries.

Problem:
Review artifacts appear ad hoc; teams need a repeatable way to export a safe, complete review bundle without leaking raw secrets or oversized data.

Goal:
Implement a first-class `remedy review bundle` command that produces a deterministic redacted archive for humans, CI, or external reviewers.

Relevant areas:
- `scripts/make_review_zip.sh`
- `apps/cli/commands/review_cmd.py`
- `packages/orchestration/event_ledger.py`
- `packages/orchestration/change_set.py`
- `packages/orchestration/trust_report.py`
- `tests/test_trust_report.py`

Proposed changes:
- Add a Python bundle builder that replaces the shell script for core behavior.
- Include manifest, job summary, proof chains, event summary, trust report, verifier status, and safe changed-file names.
- Exclude raw artifacts, raw diffs, stdout/stderr, `.data` secrets, node_modules, caches, and repository files unless explicitly safe-listed.
- Add bundle integrity hashes and a schema version.
- Add CLI and tests for deterministic contents and redaction.

Acceptance criteria:
- `remedy review bundle <job_id>` creates one zip with a stable manifest and no duplicate file names.
- Bundle contents pass redaction checks for raw output, diffs, secrets, and tracebacks.
- Trust report and proof chain JSON are included when available.
- Existing shell script can delegate to the Python implementation or be documented as legacy.

Priority rationale:
A safe review bundle makes Remedy usable in real teams, audits, and CI pipelines without requiring access to the full local workspace.
