# Critic

Removed ideas that were too generic: "better docs", "improve performance", "add integrations", "make UI nicer".

Kept only tasks tied to repo evidence:
- Existing future worker specs justify real external harness adapters.
- Existing autorun/agent loop justify bounded autonomous runs.
- Existing event ledger and proof events justify replay/proof chain work.
- Existing UI target and view model justify cockpit features, not generic redesign.
- Existing memory/project brain justify approval-gated learned project memory.
- Existing verifier profiles justify a verifier marketplace.

Each final task has concrete files, implementation steps, and acceptance criteria.
