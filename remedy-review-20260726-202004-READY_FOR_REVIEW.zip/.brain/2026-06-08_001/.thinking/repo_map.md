# Repo map

- `packages/core`, `packages/contracts`: dependency-light models and provider protocols.
- `packages/orchestration`: main kernel: jobs, autorun, agent loop, patch pipeline, event ledger, UI payloads, memory learning, project brain.
- `packages/providers`: concrete Ollama planner/builder plus future placeholder providers.
- `apps/cli`: grouped CLI command catalog and handlers.
- `apps/ui`: React/MUI dashboard with graph, timeline, status panels.
- `docs`: architecture, UI target, Project Brain behavior, safety docs.
- `tests`: broad Python tests plus UI contract/server tests.
