# Relevant files

- `README.md`: Remedy is an artifact-driven orchestration kernel with provider injection.
- `docs/architecture.md`: strict core/provider separation, safety constraints, workspace/materialization, event safety.
- `docs/ui-target.md`: UI is intended as premium read-only cockpit with brain graph and phase timeline.
- `docs/project-brain.md`: Project Brain summarizes jobs, blockers, patterns, confidence, and memory suggestions.
- `apps/cli/command_catalog.py`: broad CLI surface already exists and is metadata-classified.
- `apps/cli/commands/do_cmd.py`, `packages/orchestration/autorun.py`: high-level guided autorun exists but provider execution is limited.
- `packages/orchestration/builder_bridge.py`, `structured_patch.py`, `source_apply.py`: structured patch pipeline exists with parse/apply/test/proof gates.
- `packages/orchestration/worker_adapters.py`, `task_execution.py`: worker specs list future providers but executable adapters are mostly fixture/none.
- `packages/orchestration/ui_server.py`, `ui_view_model.py`, `apps/ui/src/**`: read-only UI server and graph/timeline frontend exist.
- `packages/orchestration/event_ledger.py`, `event_replay.py`: normalized event surface exists.
- `packages/orchestration/memory_learn.py`, `packages/memory/local_gateway.py`: evidence-to-memory exists but is local/basic.
- `packages/orchestration/project_constitution.py`: deterministic repo policy extraction exists.
