# Sources

Read during audit:
- `README.md`
- `docs/architecture.md`
- `docs/project-brain.md`
- `docs/ui-target.md`
- `pyproject.toml`
- `apps/cli/command_catalog.py`
- `apps/cli/commands/do_cmd.py`
- `packages/orchestration/agent_loop.py`
- `packages/orchestration/autonomy_loop.py`
- `packages/orchestration/autorun.py`
- `packages/orchestration/builder_bridge.py`
- `packages/orchestration/event_ledger.py`
- `packages/orchestration/memory_learn.py`
- `packages/orchestration/patch_apply.py`
- `packages/orchestration/project_constitution.py`
- `packages/orchestration/reviewer.py`
- `packages/orchestration/source_apply.py`
- `packages/orchestration/structured_patch.py`
- `packages/orchestration/task_execution.py`
- `packages/orchestration/ui_server.py`
- `packages/orchestration/ui_view_model.py`
- `packages/orchestration/verifier_profiles.py`
- `packages/orchestration/worker_adapters.py`
- `apps/ui/src/RemedyApp.tsx`
- `apps/ui/src/**` tree listing
- `tests/**` tree listing
