# Analysis

The repo has strong primitives: safe artifact model, approvals, patch intents, event ledger, Project Brain, local UI, deterministic tests. The biggest product gaps are not generic polish; they are missing connective tissue that turns many primitives into a compelling autonomous development cockpit.

Top signals:
- Worker metadata advertises Claude Code/Pi/OpenAI as future, while task execution only supports fixture/none and Ollama is unavailable in `get_executor`.
- `remedy do` has a high-level flow but stops early unless fixture/Ollama bridge paths are used.
- UI is read-only and already designed around graph/timeline; it can become the differentiating operator experience.
- Event ledger and patch pipeline are safety-first, making replay, proof chains, and policy simulation credible.
- Memory learning exists but is local/small; Project Brain already wants patterns and memory suggestions.

Killer features should compound existing architecture rather than bypass safety: external harness adapters, verified autonomous loop, proof replay, context inspector, memory approvals, verifier marketplace, UI operations cockpit, project templates, eval dashboard, team-safe remote mode.
