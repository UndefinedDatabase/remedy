## Task 01: Add Browser-Side Approval And Apply Actions

Impact: High  
Effort: High  

Context:
The repository already supports approval and apply flows from the CLI, but the HTTP layer is still read-only. `packages/orchestration/ui_server.py` explicitly serves inspection-only endpoints, `apps/api/__init__.py` is a reserved REST/WebSocket stub, and the existing UI can only observe job state.

Problem:
Users cannot approve patch intents, reject them, or trigger safe apply flows from the browser, which forces every meaningful decision back through the CLI and blocks the UI from becoming a real operations cockpit.

Goal:
Implement a first mutation-capable API surface for patch approval and application, then wire the UI to invoke those actions safely.

Relevant areas:
- apps/api/__init__.py
- apps/cli/commands/patch.py
- packages/orchestration/approval_queue.py
- packages/orchestration/repo_applicator.py
- packages/orchestration/ui_server.py

Proposed changes:
- Add authenticated POST endpoints for approve, reject, and apply operations using the existing orchestration functions instead of duplicating business logic.
- Reuse the current permission and intent models so browser actions produce the same artifacts and proofs as CLI actions.
- Add UI affordances for pending patch intents and safe confirmation flows in the existing job dashboard.
- Add tests that verify mutation endpoints remain capability-gated and do not leak raw artifact content or approval reasons.

Acceptance criteria:
- A user can approve, reject, and apply a patch intent from the browser without dropping to the CLI.
- API and UI tests prove that unauthorized or malformed mutation requests are rejected safely.

Priority rationale:
This is the highest-leverage feature because it converts Remedy from a read-only visualizer into a real operator console while reusing logic that already exists.

## Task 02: Build A Background Worker For Unattended Job Execution

Impact: High  
Effort: High  

Context:
`apps/worker/__init__.py` is an explicit stub for asynchronous task execution, while current runs still depend on a human-triggered CLI invocation. The repository already has `agent_loop`, `autonomy_loop`, and readiness infrastructure that a worker could orchestrate.

Problem:
Remedy cannot yet run as a long-lived service that watches for pending jobs and advances them automatically, which limits it to manual, foreground execution.

Goal:
Implement a worker process that polls for runnable jobs, respects autonomy and approval gates, and advances work without an interactive terminal session.

Relevant areas:
- apps/worker/__init__.py
- packages/orchestration/agent_loop.py
- packages/orchestration/autonomy_loop.py
- packages/orchestration/autonomy_readiness.py
- packages/orchestration/storage.py

Proposed changes:
- Implement a worker entrypoint that scans stored jobs, selects eligible work, and runs the existing orchestration loop on a schedule.
- Reuse readiness and stop-reason logic so unattended execution is conservative by default.
- Add worker status events to the run log so the UI and CLI can show who advanced a job and why it stopped.
- Add tests for polling behavior, duplicate-run avoidance, and blocked-job handling.

Acceptance criteria:
- A background worker can pick up a pending or planned job and advance it without manual CLI intervention.
- Worker runs emit traceable events and stop cleanly on approval blockers or failed readiness checks.

Priority rationale:
This unlocks CI, daemonized execution, and autonomous pipelines, which is the biggest operational capability gap after browser actions.

## Task 03: Replace Polling With Live Event Streaming

Impact: High  
Effort: Medium  

Context:
The current React app polls every five seconds in `apps/ui/src/RemedyApp.tsx`, while `apps/api/__init__.py` already reserves a REST/WebSocket API role. The run-log and events-since machinery already provide a streaming-friendly event source.

Problem:
The UI feels delayed and wasteful because it repeatedly refetches state instead of reacting to live job events.

Goal:
Add a live transport layer, preferably WebSocket or SSE, so the UI updates immediately when jobs change.

Relevant areas:
- apps/api/__init__.py
- apps/ui/src/RemedyApp.tsx
- apps/ui/src/api/remedyApi.ts
- packages/orchestration/timeline.py
- packages/orchestration/ui_server.py

Proposed changes:
- Add a server-side live event endpoint that streams new run-log events and view-model invalidation signals.
- Update the UI data layer to subscribe to live events and fall back to polling only when streaming is unavailable.
- Trigger targeted refreshes for changed slices instead of full dashboard reloads.
- Add tests for connection recovery, cursor resume, and reduced duplicate fetches.

Acceptance criteria:
- The UI updates within one event cycle of a task, approval, or apply transition without waiting for the five-second polling timer.
- Streaming disconnects recover safely and do not duplicate already-consumed events.

Priority rationale:
Once worker execution exists, live transport becomes the difference between a static monitor and a true real-time cockpit.

## Task 04: Add Server-Side Graph Search And Filtering

Impact: High  
Effort: Medium  

Context:
The graph UI already exposes filter chips in `GraphFilterChips.tsx` and renders graph state in `BrainGraphStage.tsx`, but filtering is mostly client-side and the backend returns broad job graph payloads. The project brain already includes rich node metadata, edge types, and future-layer placeholders.

Problem:
As graphs grow, client-side filtering over the full graph becomes harder to use and prevents richer exploration features like type filters, status filters, or text search.

Goal:
Implement backend query support for graph filtering and search, then connect the UI to those server-side capabilities.

Relevant areas:
- apps/ui/src/components/graph/BrainGraphStage.tsx
- apps/ui/src/components/graph/GraphFilterChips.tsx
- packages/orchestration/project_brain.py
- packages/orchestration/ui_server.py
- packages/orchestration/ui_view_model.py

Proposed changes:
- Add filtered graph endpoints or query parameters for node type, status, risk level, and free-text search.
- Reuse existing graph metadata rather than inventing a second graph schema.
- Update the UI chips and controls to request filtered graph slices from the server.
- Add tests for stable graph filtering semantics and safe handling of unknown filter values.

Acceptance criteria:
- Users can narrow a large graph by status, type, or text without loading the entire graph into every client interaction.
- Filtered responses preserve valid node and edge relationships and remain compatible with the current UI view model.

Priority rationale:
This makes the existing brain visualization materially more useful on real projects rather than just prettier on small ones.

## Task 05: Feed Local Memory Into Planning And Task Execution

Impact: High  
Effort: Medium  

Context:
`packages/memory/local_gateway.py` already implements a working memory backend, but `packages/orchestration/llm_planner.py` still passes only the raw prompt into planning and task execution paths do not pull prior learned context into builder input.

Problem:
Remedy stores memory but does not yet use it to improve planning, retries, or builder context, so jobs cannot benefit from prior learning.

Goal:
Integrate the existing local memory gateway into planner and builder context assembly in a controlled, redacted way.

Relevant areas:
- packages/memory/local_gateway.py
- packages/orchestration/llm_planner.py
- packages/orchestration/task_runner.py
- packages/orchestration/builder_models.py
- tests/test_memory_gateway.py

Proposed changes:
- Read approved or recent memory entries during planning and task execution, then inject compact summaries into provider input.
- Extend task execution context models so builders can receive memory-derived guidance without touching mutable job state.
- Add clear ranking and truncation rules so memory augments context instead of overwhelming it.
- Add tests proving memory is consulted, redaction remains intact, and empty-memory cases are harmless.

Acceptance criteria:
- Planner and builder calls include relevant memory summaries when useful and omit them safely when none exist.
- Tests confirm that sensitive or raw blocked content still does not leak into provider inputs or run logs.

Priority rationale:
This is the fastest path to making Remedy feel cumulative and project-aware instead of stateless between runs.

## Task 06: Implement Live Semantic Memory With MemPalace

Impact: High  
Effort: High  

Context:
The codebase already reserves `packages/providers/mempalace/`, the architecture repeatedly references MemPalace replacing `memory_placeholder` nodes, and `tests/test_project_brain.py` asserts that memory placeholders remain present until a future implementation lands.

Problem:
The current memory layer is local and lexical, while the architecture points toward a richer semantic memory system that can span jobs and projects.

Goal:
Add a MemPalace-backed memory provider and replace placeholder memory nodes with live semantic memory entities.

Relevant areas:
- packages/providers/mempalace/__init__.py
- packages/contracts/interfaces.py
- packages/orchestration/project_brain.py
- packages/orchestration/ui_view_model.py
- docs/architecture.md

Proposed changes:
- Implement a concrete memory provider that conforms to the existing gateway abstraction.
- Add orchestration and graph mapping logic so real memory nodes can appear in project brain outputs.
- Preserve the current local backend as a fallback path for environments without MemPalace.
- Add tests covering provider wiring, graph replacement of placeholders, and safe degradation when semantic memory is unavailable.

Acceptance criteria:
- When enabled, Remedy can read and surface live semantic memory instead of only showing `memory_placeholder` nodes.
- Disabling the provider falls back cleanly to the current local memory behavior.

Priority rationale:
Semantic memory is a major differentiator for a system positioning itself as an auditable long-running orchestration kernel.

## Task 07: Add A Claude-Hosted Planner And Builder Provider

Impact: Medium  
Effort: Medium  

Context:
`packages/providers/claude_agent/__init__.py` is a reserved stub, the architecture describes a future Claude-hosted provider, and the planner and builder seams are already injected through provider callables rather than hard-coded imports.

Problem:
Remedy is currently tied to local Ollama implementations for real provider behavior, which limits deployment flexibility and model strategy.

Goal:
Implement a Claude-backed provider that can act as planner, builder, or both using the existing orchestration contracts.

Relevant areas:
- packages/providers/claude_agent/__init__.py
- packages/orchestration/llm_planner.py
- packages/orchestration/builder_models.py
- packages/contracts/interfaces.py
- docs/architecture.md

Proposed changes:
- Add Claude-backed planner and builder adapters that emit the existing validated output models.
- Expose provider selection in the app wiring or CLI without introducing provider-specific branching into orchestration.
- Reuse redaction and metadata conventions so Claude-backed runs remain audit-friendly.
- Add tests with mocked provider calls to verify schema compliance and failure handling.

Acceptance criteria:
- Remedy can plan and execute tasks through a Claude-backed provider without changing orchestration contracts.
- Metadata, artifacts, and verification behavior remain consistent with existing Ollama-backed flows.

Priority rationale:
Multi-provider execution broadens Remedy’s practical adoption and validates the architecture’s provider-neutral design.

## Task 08: Implement A Docker Runtime Sandbox

Impact: Medium  
Effort: High  

Context:
`packages/providers/docker_runtime/__init__.py` and the runtime contract in `packages/contracts/interfaces.py` explicitly reserve a Docker-backed execution path, while the current runtime is still local workspace materialization.

Problem:
Remedy cannot yet run builder or verifier work inside an isolated container, which limits safety for repo mutation, package installation, and reproducible execution.

Goal:
Implement a Docker runtime provider and connect it to orchestration as an optional execution backend.

Relevant areas:
- packages/providers/docker_runtime/__init__.py
- packages/contracts/interfaces.py
- packages/orchestration/workspace.py
- packages/orchestration/task_runner.py
- docs/architecture.md

Proposed changes:
- Implement a Docker runtime adapter that conforms to the runtime provider contract and captures stdout, stderr, and exit status safely.
- Add runtime selection wiring so hosts can choose local or Docker execution without changing task logic.
- Define path-mounting and timeout rules that preserve existing path safety guarantees.
- Add tests for container execution, timeout cleanup, and safe fallback when Docker is unavailable.

Acceptance criteria:
- Remedy can execute supported work through a Docker-backed runtime while preserving current artifact and verification flows.
- Runtime selection is injectable and does not introduce Docker-specific logic into orchestration core modules.

Priority rationale:
This is the cleanest route to safer autonomous execution and is a prerequisite for higher-trust mutation workflows.

## Task 09: Replace MCP Placeholder Nodes With A Real Quarantine Tool Layer

Impact: Medium  
Effort: High  

Context:
`project_brain.py` and the architecture reserve `mcp_placeholder` nodes and future MCP edges, and the docs explicitly call out MCP Quarantine as a future layer. The current graph and UI already visualize the absence of that feature.

Problem:
Remedy has no real tool quarantine or MCP integration layer yet, so external tool use cannot be represented or governed in the way the brain model anticipates.

Goal:
Implement an MCP Quarantine layer that models tool availability, trust boundaries, and invocation metadata as first-class graph objects.

Relevant areas:
- packages/orchestration/project_brain.py
- packages/orchestration/ui_view_model.py
- packages/orchestration/project_constitution.py
- docs/architecture.md
- tests/test_project_brain.py

Proposed changes:
- Define concrete MCP node and edge models that replace the placeholder representation when tool integration is enabled.
- Add quarantine metadata that captures tool identity, allowed capabilities, and trust status without leaking unsafe payloads.
- Update graph export and UI copy so live MCP nodes are distinct from current placeholder visuals.
- Add tests covering graph shape, safe metadata export, and fallback to placeholders when the feature is disabled.

Acceptance criteria:
- Enabled jobs expose real MCP or tool-layer nodes in the brain graph instead of only `mcp_placeholder` markers.
- Tool metadata remains safety-scoped and does not expose raw command content or secret-bearing payloads.

Priority rationale:
This turns an advertised future layer into a real control plane for external tooling, which is central to the project’s longer-term autonomy story.

## Task 10: Ship A Project-Level Brain Dashboard

Impact: Medium  
Effort: Medium  

Context:
`packages/orchestration/project_registry.py` already stores multi-job project metadata and explicitly says Project Brain UI is not implemented. The repository already has project commands, project context coverage, and single-job brain rendering.

Problem:
Users can inspect individual jobs, but they cannot yet see a real project-level aggregate view across repos, jobs, memory, and readiness signals.

Goal:
Implement a project-level brain and dashboard that aggregates linked jobs into a single navigable project view.

Relevant areas:
- packages/orchestration/project_registry.py
- packages/orchestration/project_brain_aggregate.py
- packages/orchestration/project_context_coverage.py
- apps/cli/commands/project.py
- packages/orchestration/ui_view_model.py

Proposed changes:
- Build an aggregate project brain payload that combines linked jobs, repo attachments, readiness, and context coverage into one navigable structure.
- Expose project-level JSON and UI endpoints that reuse existing graph contracts where possible.
- Add CLI and UI entrypoints for viewing aggregate project state and drilling into constituent jobs.
- Add tests for aggregation correctness, missing-job handling, and stable counts across linked repos and jobs.

Acceptance criteria:
- A user can open one project view and see aggregated jobs, repos, readiness, and graph relationships without manually inspecting each job.
- Aggregated project state remains deterministic and safely redacted in both CLI and UI outputs.

Priority rationale:
This is the natural next layer above the current single-job cockpit and makes Remedy useful for sustained multi-job project work.
