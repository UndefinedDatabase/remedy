# Sources

- `docs/architecture.md` for future layers and package roles.
- `packages/orchestration/ui_server.py` for current read-only HTTP surface.
- `apps/api/__init__.py` and `apps/worker/__init__.py` for reserved app stubs.
- `packages/contracts/interfaces.py` for `stream`, `MemoryGateway`, and `RuntimeProvider` seams.
- `packages/orchestration/project_brain.py` and `tests/test_project_brain.py` for memory and MCP placeholders.
- `packages/orchestration/project_registry.py` for deferred project brain/dashboard work.
