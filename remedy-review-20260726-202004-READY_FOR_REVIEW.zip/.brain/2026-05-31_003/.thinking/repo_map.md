# Repo Map

- Core contracts and orchestration live under `packages/`.
- User-facing surfaces are split across `apps/cli`, `apps/ui`, `apps/api` (stub), and `apps/worker` (stub).
- Future-facing seams already exist for Claude, Docker runtime, MemPalace, and MCP/brain expansion.
- Current UI is read-only and polling-based; current execution is CLI-triggered.
