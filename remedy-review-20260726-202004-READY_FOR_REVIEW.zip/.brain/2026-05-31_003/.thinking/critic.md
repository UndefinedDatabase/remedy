# Critic

- Excluded timeout/retry/logging-only work because it is hardening, not a killer feature.
- Avoided generic UI polish items unless they unlock real new workflows.
- Split memory into two tasks only because repo evidence supports both immediate local integration and later MemPalace replacement.
- Kept every task anchored to concrete files or tests.
