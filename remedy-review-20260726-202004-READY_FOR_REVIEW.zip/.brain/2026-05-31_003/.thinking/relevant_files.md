# Relevant Files

- `apps/api/__init__.py`
- `apps/worker/__init__.py`
- `apps/ui/src/RemedyApp.tsx`
- `apps/ui/src/components/graph/BrainGraphStage.tsx`
- `apps/ui/src/components/graph/GraphFilterChips.tsx`
- `packages/contracts/interfaces.py`
- `packages/memory/local_gateway.py`
- `packages/orchestration/llm_planner.py`
- `packages/orchestration/task_runner.py`
- `packages/orchestration/project_brain.py`
- `packages/orchestration/project_registry.py`
- `packages/orchestration/ui_server.py`
- `packages/providers/claude_agent/__init__.py`
- `packages/providers/docker_runtime/__init__.py`
- `packages/providers/mempalace/__init__.py`
- `docs/architecture.md`
- `tests/test_project_brain.py`
- `tests/test_autonomy_readiness.py`
