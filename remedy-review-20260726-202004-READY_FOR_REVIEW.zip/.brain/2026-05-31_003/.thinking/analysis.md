# Analysis

- Highest-value gaps are product capabilities already implied by code or docs but not yet usable.
- The strongest near-term items are browser mutations, unattended execution, richer live UI transport, and server-side graph exploration.
- Memory should be split into near-term local integration and longer-term semantic memory provider work.
- Docker, Claude, and MCP all have explicit extension seams and reserved namespaces, making them credible roadmap items.
