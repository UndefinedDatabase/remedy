# Repo Map (key modules for this brainstorm)

## Job Lifecycle
- packages/core/models.py — Job, Task, Artifact, RunState, Budget
- packages/orchestration/job_runner.py — plan_job() deterministic skeleton (3 fixed tasks)
- packages/orchestration/job_fulfillment.py — Full spine: Planning→Working→Reviewing→Repairing→Approval→Applying→Testing→Proving→Final Review→Completed (fixture_demo mode only)
- packages/orchestration/task_runner.py — run_next_task(), TaskExecutionContext assembly
- packages/orchestration/builder_models.py — TaskExecutionContext, BuilderOutput

## Worker/Builder
- packages/orchestration/builder_routing.py — Tier selection (deterministic_only → local_advisor → local_candidate → external_candidate → human_review)
- packages/orchestration/worker_registry.py — Worker specs, route policy bridge
- packages/orchestration/managed_builder_execution.py — Bounded subprocess for external builders
- packages/providers/ollama_planner/ — Local Ollama planner
- packages/providers/ollama_builder/ — Local Ollama builder

## Context
- packages/orchestration/context_pack.py — Budget-aware context sections (priority-ranked, token-estimated)
- packages/orchestration/context_optimizer.py — Explain/optimize context
- packages/orchestration/context_inspector.py — Context quality check
- packages/orchestration/context_coverage.py — Coverage analysis

## Token Economy
- packages/orchestration/token_policy.py — Zero/local/expensive step classification
- packages/orchestration/token_economy.py — Token bands, budget profiles, context pack recommendations

## Review & Repair
- packages/orchestration/reviewer.py — ReviewerRecommendation, fixture reviewer (inert)
- packages/orchestration/review_bundle.py — Safe zip bundle for reviewers (40+ sections)
- packages/orchestration/repair_loop_v2.py — Token-aware repair: failure→context→fix→review→retest
- packages/orchestration/verifier.py — 10 deterministic local checks, TaskContract

## Proof & Safety
- packages/orchestration/proof_chain.py — Goal→Job→Task→Artifact→PatchIntent→Approval→Apply→Test→Proof
- packages/orchestration/provider_trust.py — Trust scoring
- packages/orchestration/permissions.py — workspace_write, repo_generated_write, repo_overwrite, shell_exec

## Report & Visibility
- packages/orchestration/dashboard.py — Job/project dashboard
- packages/orchestration/trust_report.py — Trust scoring report
- packages/orchestration/progress_ledger.py — Progress tracking

## Workspace
- packages/orchestration/workspace.py — LocalWorkspaceRuntime, MaterializedFile
- packages/orchestration/patch_apply.py — Apply patches to target repo
- packages/orchestration/external_builder_sandbox.py — External builder sandboxing

## Contracts
- packages/contracts/interfaces.py — LLMWorker, MemoryGateway, RuntimeProvider, Verifier protocols
