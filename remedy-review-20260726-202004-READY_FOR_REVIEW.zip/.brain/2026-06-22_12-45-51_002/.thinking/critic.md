# Critic Review

## Removed ideas (too generic)
- "Add logging" — already exists throughout
- "Add more tests" — not specific enough
- "Improve error handling" — vague
- "Use dependency injection" — already done via Protocol interfaces

## Evidence check
- Every gap traced to specific file + line evidence
- No speculative "might need" items
- All tasks grounded in existing module boundaries
- Each task builds on existing patterns (dataclass models, safe exports, no-LLM-in-core)

## Risk of over-engineering
- Tasks scoped to minimum viable increments
- Each task produces a testable artifact
- No tasks that require rewriting existing working code
