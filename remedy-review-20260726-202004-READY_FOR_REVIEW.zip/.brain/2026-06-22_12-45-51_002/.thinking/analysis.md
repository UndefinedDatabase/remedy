# Gap Analysis: Current State vs AAA Goal

## Goal decomposition (from user prompt)

1. **Human goal → task plan** — PARTIAL. job_runner.py creates 3 fixed planning tasks. LLM planner exists but fixture-only. No "goal interpreter" that decomposes a natural-language goal into a concrete, bounded task DAG.

2. **Bounded worker prompts per task** — PARTIAL. TaskExecutionContext passes job_prompt, task_description, planning_summary, prior_task_summaries. But it passes the FULL job prompt, not a per-task-scoped prompt. No prompt template system that generates minimal, task-specific worker prompts.

3. **Smallest task-relevant context** — PARTIAL. context_pack.py builds priority-ranked sections with budget truncation. But context is job-level, not task-level. No per-task context selection that filters to only files/artifacts relevant to THAT task.

4. **Minimize expensive-model tokens** — GOOD FOUNDATION. token_policy.py classifies zero/local/expensive steps. token_economy.py estimates bands. builder_routing.py has tier selection. But: no actual per-task cost tracking, no adaptive rebalancing, no real token metering post-execution. "future_layers" in token_policy.py explicitly lists these as TODO.

5. **Route cheap tasks to local LLMs** — PARTIAL. Builder routing tiers exist. Ollama providers exist. But routing decision → actual provider dispatch is not wired end-to-end. Route selection emits a decision but doesn't trigger the corresponding provider.

6. **Collect worker outputs as untrusted** — GOOD. managed_builder_execution.py treats all output as untrusted. external_builder_sandbox.py exists. Output goes through Trust Gate.

7. **Reviewer prompts against each result** — WEAK. reviewer.py exists but is a fixture-only recommendation engine. No structured reviewer prompt that evaluates worker output against task contract/acceptance criteria. No per-task reviewer loop.

8. **Convert findings → repair tasks** — PARTIAL. repair_loop_v2.py turns failures into repair items. But only handles test failures and review findings from the live-review process, not structured per-task reviewer output.

9. **Worker/reviewer loop until pass** — PARTIAL. repair_loop_v2.py has the state machine (NEW→...→REPAIRED). JobFulfillmentContract has max_review_rounds/max_repair_rounds. But the loop is not wired to actually re-dispatch to workers and re-run reviewers automatically.

10. **Apply/test/proof in isolated workspace** — PARTIAL. workspace.py provides per-job isolation. patch_apply.py applies to target repo. But "isolated workspace" currently means a local directory, not a sandboxed clone/worktree where tests run before touching the real repo.

11. **Final job-level review against contract** — EXISTS. JobFulfillmentContract.check() verifies all gates. But it's a boolean check, not a structured review prompt that evaluates overall quality.

12. **Human-readable report** — WEAK. dashboard.py gives overview. review_bundle.py creates a zip. But no single consolidated "job fulfillment report" that shows: every task, selected context, worker route, token/cost reasoning, review, repair, test, proof, and decision in one readable document.

13. **Ranked recommended next tasks** — PARTIAL. reviewer.py produces recommendations. proof_chain.py derives next_safe_action. But no unified "next tasks" output with approve/reject/defer/backlog actions.

## Key gaps (prioritized)

1. **Per-task context selection** — context_pack is job-level, not task-scoped
2. **Worker prompt templates** — no system to generate bounded, task-specific prompts
3. **Real reviewer loop** — reviewer.py is fixture-only, no LLM-backed review
4. **End-to-end route dispatch** — routing decision doesn't trigger provider execution
5. **Isolated sandbox for apply/test** — workspace is just a directory, not a git worktree sandbox
6. **Consolidated fulfillment report** — no single human-readable report document
7. **Per-task cost tracking** — token estimates exist but no post-execution metering
8. **Goal decomposition planner** — plan_job creates fixed tasks, not goal-derived
9. **Worker/reviewer auto-loop** — state machine exists but loop not automated
10. **Next-task approve/reject/defer UX** — recommendations exist but no action workflow
