# Brainstorm Tasks — AAA Job Fulfillment Pipeline

## Task 01: Per-Task Context Selector

Impact: High
Effort: Medium

Context:
`context_pack.py` builds a single job-level `ContextPack` with 8 priority-ranked sections. `task_runner.py:_build_execution_context()` passes the full `job_prompt` and all `prior_task_summaries` to every worker via `TaskExecutionContext`. There is no mechanism to filter context to only what a specific task needs.

Problem:
Every worker receives the same job-wide context regardless of task type. A `docs_update` task gets the same context as a `complex_refactoring` task. This wastes tokens on irrelevant context and violates the "smallest task-relevant context" principle.

Goal:
Build a `TaskContextSelector` that, given a task and its type, selects only the context sections, files, and prior artifacts relevant to that specific task — producing a task-scoped `ContextPack` that fits within the task's token budget.

Relevant areas:
- `packages/orchestration/context_pack.py` — section builders, budget truncation
- `packages/orchestration/task_runner.py` — `_build_execution_context()`
- `packages/orchestration/builder_models.py` — `TaskExecutionContext`
- `packages/orchestration/token_economy.py` — `ContextPackKind`, budget profiles
- `packages/orchestration/task_registry.py` — task type specs

Proposed changes:
- Add `TaskContextSelector` dataclass in `context_pack.py` with `select(job, task, budget) -> ContextPack`
- Define per-task-type context profiles in `task_registry.py` (which sections each type needs)
- Filter `prior_task_summaries` to only include summaries from dependency tasks, not all completed tasks
- Wire `task_runner.py:_build_execution_context()` to use `TaskContextSelector` instead of full job context
- Add `context_profile` field to `TaskExecutionContext` showing what was included/excluded and why

Acceptance criteria:
- `TaskContextSelector.select()` returns a `ContextPack` scoped to task type with fewer sections than full job context
- `TaskExecutionContext` includes a `context_profile` dict showing included/excluded sections with reasons
- Token estimate for task-scoped context is measurably smaller than job-level context for narrow task types
- All existing tests pass unchanged
- New tests verify per-type section filtering

Priority rationale:
This is the highest-leverage change. Every subsequent task (worker prompts, cost tracking, routing) depends on having task-scoped context. Without it, token reduction and routing decisions operate on inflated context sizes.

---

## Task 02: Worker Prompt Template System

Impact: High
Effort: Medium

Context:
`TaskExecutionContext` passes raw fields (`job_prompt`, `task_description`, `planning_summary`) to builder providers. Each provider (e.g., `ollama_builder/provider.py`) constructs its own prompt from these fields. There is no shared prompt template system that generates bounded, role-specific worker prompts.

Problem:
Worker prompts are unstructured and provider-specific. The job prompt is passed in full rather than a task-scoped instruction. There are no guardrails ensuring worker prompts stay within token budgets or include only task-relevant instructions. Different providers may interpret the same context differently.

Goal:
Create a `WorkerPromptBuilder` that generates a complete, bounded worker prompt for each task — including task instruction, scoped context, output format spec, and constraints — independent of which provider executes it.

Relevant areas:
- `packages/orchestration/builder_models.py` — `TaskExecutionContext`
- `packages/orchestration/task_runner.py` — context assembly
- `packages/providers/ollama_builder/provider.py` — current prompt construction
- `packages/providers/ollama_planner/provider.py` — planner prompt construction
- `packages/orchestration/context_pack.py` — context sections

Proposed changes:
- Create `packages/orchestration/worker_prompt.py` with `WorkerPromptBuilder` class
- Define `WorkerPrompt` dataclass: `system_instruction`, `task_instruction`, `context_sections`, `output_format`, `constraints`, `estimated_tokens`
- Add prompt templates per task type (analyze_requirements, define_acceptance_checks, prepare_implementation_plan, docs_update, code_change, test_improvement)
- `build_worker_prompt(task, context_pack) -> WorkerPrompt` assembles from template + scoped context
- Provider adapters consume `WorkerPrompt` instead of raw `TaskExecutionContext` fields
- Token estimate on the assembled prompt before dispatch

Acceptance criteria:
- `WorkerPrompt` includes `estimated_tokens` that matches within 10% of actual prompt length / 4
- Each task type has a registered prompt template
- Prompt output is deterministic for the same input
- Existing provider tests pass with adapter changes
- New tests verify prompt assembly, token estimation, and template coverage

Priority rationale:
Worker prompts are the primary token cost driver. Bounded, templated prompts prevent token waste and ensure workers receive clear, actionable instructions. Required before routing can make informed cost decisions.

---

## Task 03: Structured Reviewer Loop (Per-Task)

Impact: High
Effort: High

Context:
`reviewer.py` contains a `run_reviewer()` function that calls a reviewer function and returns `ReviewerRecommendation` objects. The default reviewer is inert (returns nothing). The fixture reviewer returns 2 hardcoded recommendations. There is no structured review that evaluates worker output against the task's acceptance criteria.

Problem:
Worker outputs are not systematically reviewed against task contracts. The reviewer only suggests follow-up tasks — it doesn't pass/fail worker output. The `TaskContract` in `verifier.py` checks structural requirements (artifact exists, workspace file exists) but not semantic quality. There is no reviewer prompt that asks "did this worker output satisfy the task goal?"

Goal:
Build a `TaskReviewer` that takes worker output + task contract + acceptance criteria and produces a structured `ReviewVerdict` (pass/fail/repair_needed) with specific findings. Findings that fail convert to repair tasks fed back into the worker loop.

Relevant areas:
- `packages/orchestration/reviewer.py` — current reviewer (fixture-only)
- `packages/orchestration/verifier.py` — `TaskContract`, `VerificationResult`
- `packages/orchestration/repair_loop_v2.py` — `RepairLoopStatus`, repair context
- `packages/orchestration/job_fulfillment.py` — `REVIEWING` / `REPAIRING` states
- `packages/core/models.py` — `AcceptanceCheck`

Proposed changes:
- Create `packages/orchestration/task_reviewer.py` with `TaskReviewer` protocol and `ReviewVerdict` dataclass
- `ReviewVerdict` fields: `passed: bool`, `findings: list[ReviewFinding]`, `repair_tasks: list[dict]`, `token_cost_estimate: int`
- `ReviewFinding` fields: `severity` (critical/medium/low), `description`, `location`, `suggested_fix`
- Add `DeterministicTaskReviewer` that checks acceptance criteria from `Task.acceptance_checks` + content quality signals
- Add `LLMTaskReviewer` protocol stub that can be backed by local or frontier model
- Wire into `job_fulfillment.py` REVIEWING state: run reviewer → if findings → create repair tasks → transition to REPAIRING
- Convert findings with severity >= medium into repair tasks via `repair_loop_v2.py`

Acceptance criteria:
- `ReviewVerdict` is a Pydantic model with `passed`, `findings`, `repair_tasks`
- `DeterministicTaskReviewer` catches at least 5 concrete quality issues (empty sections, placeholder text, missing required fields, vague language, wrong file references)
- Findings with severity >= medium produce repair task descriptors compatible with `repair_loop_v2.py`
- `job_fulfillment.py` transitions through REVIEWING → REPAIRING when findings exist
- New tests verify reviewer → repair task conversion

Priority rationale:
The worker/reviewer loop is the core quality gate. Without structured review, worker outputs are accepted on structural checks alone. This is the difference between "code was produced" and "code is correct."

---

## Task 04: Route-to-Provider Dispatch Bridge

Impact: High
Effort: Medium

Context:
`builder_routing.py` emits a `BuilderRoutingDecision` with a `selected_tier` (deterministic_only, local_advisor, local_candidate_generator, external_candidate_generator). `worker_registry.py` maps tiers to worker IDs. But the routing decision is never actually used to dispatch to the corresponding provider. The decision is metadata-only.

Problem:
Routing decisions are produced but not consumed. A task routed to `local_candidate_generator` doesn't actually trigger the Ollama builder. A task routed to `external_candidate_generator` doesn't trigger the managed external builder. The entire routing layer is advisory, not executable.

Goal:
Build a `RouteDispatcher` that takes a `BuilderRoutingDecision` and dispatches to the corresponding provider, returning a `BuilderOutput`. This closes the gap between routing policy and actual execution.

Relevant areas:
- `packages/orchestration/builder_routing.py` — `BuilderRoutingDecision`, `BuilderRoutingTier`
- `packages/orchestration/worker_registry.py` — worker specs, selection
- `packages/orchestration/managed_builder_execution.py` — external builder subprocess
- `packages/providers/ollama_builder/provider.py` — local builder
- `packages/contracts/interfaces.py` — `LLMWorker` protocol
- `packages/orchestration/task_runner.py` — `run_next_task()` call_builder injection

Proposed changes:
- Create `packages/orchestration/route_dispatcher.py` with `RouteDispatcher` class
- `dispatch(decision, worker_prompt, context_pack) -> BuilderOutput` maps tier to provider
- For `deterministic_only`: use local deterministic logic (no LLM)
- For `local_candidate_generator`: dispatch to registered Ollama builder
- For `external_candidate_generator`: dispatch via managed_builder_execution with approval gate
- For `human_review_required`: return a `BuilderOutput` stub with `requires_human=True`
- Integrate with `task_runner.py`: replace injected `call_builder` with route-aware dispatch
- Record dispatch metadata (tier, provider_id, estimated_tokens) in artifact metadata

Acceptance criteria:
- `RouteDispatcher.dispatch()` routes to correct provider based on tier
- Dispatch to external tier requires approval (reuses `execution_approval_policy.py`)
- Dispatch metadata recorded in artifact for cost tracking
- Deterministic tier produces output without any LLM call
- Existing task_runner tests pass with route-aware dispatch

Priority rationale:
Without dispatch, routing is theater. This makes the cheap-vs-expensive routing actually functional, directly reducing cost for tasks that can use local models.

---

## Task 05: Isolated Git Worktree Sandbox for Apply/Test

Impact: High
Effort: Medium

Context:
`workspace.py` creates a per-job directory under `.data/workspaces/<job_id>/` for materializing files. `patch_apply.py` applies patches to the target repo directly. Tests run against the real repo. There is no intermediate sandbox where changes are applied and tested before touching the real repository.

Problem:
Apply and test operations touch the real repo. A failing patch or broken test leaves the repo in a dirty state. The goal requires "run apply/test/proof gates in an isolated workspace before touching the real repo."

Goal:
Add a `SandboxWorkspace` that creates a temporary git worktree of the target repo, applies patches there, runs tests there, and only promotes changes to the real repo after all gates pass.

Relevant areas:
- `packages/orchestration/workspace.py` — `LocalWorkspaceRuntime`
- `packages/orchestration/patch_apply.py` — patch application
- `packages/orchestration/test_execution_service.py` — test execution
- `packages/orchestration/job_fulfillment.py` — APPLYING / TESTING states
- `packages/orchestration/proof_chain.py` — proof verification

Proposed changes:
- Create `packages/orchestration/sandbox_workspace.py` with `SandboxWorkspace` class
- `create_sandbox(repo_path) -> SandboxWorkspace` creates a git worktree in a temp directory
- `apply_in_sandbox(sandbox, patch_intent) -> ApplyResult` applies patches in the worktree
- `test_in_sandbox(sandbox, test_command) -> TestResult` runs tests in the worktree
- `promote_sandbox(sandbox) -> PromoteResult` merges worktree changes into the real repo (only after all gates pass)
- `cleanup_sandbox(sandbox)` removes the worktree
- Wire into `job_fulfillment.py`: APPLYING and TESTING states use sandbox instead of direct repo ops
- Record sandbox proof (worktree path, commit SHA before/after) in proof chain

Acceptance criteria:
- `SandboxWorkspace.create_sandbox()` produces a valid git worktree
- Patches applied in sandbox do not appear in the real repo until `promote_sandbox()`
- Test failures in sandbox leave the real repo clean
- `cleanup_sandbox()` removes the worktree and its tracking branch
- Proof chain records sandbox commit SHAs
- Existing patch_apply tests still pass for direct mode

Priority rationale:
Isolation is a safety-critical requirement. Without it, failed jobs can corrupt the real repo. This is a prerequisite for autonomous overnight execution.

---

## Task 06: Job Fulfillment Report Generator

Impact: High
Effort: Medium

Context:
`dashboard.py` builds a job overview dict. `review_bundle.py` creates a zip with 40+ JSON sections. `summarize_job_fulfillment()` in `job_fulfillment.py` produces a short text summary. But there is no single, consolidated human-readable report that shows the complete fulfillment story.

Problem:
After a job completes, there is no single document a human can read to understand: what tasks were planned, what context each worker received, which route was chosen and why, what the worker produced, what the reviewer found, what was repaired, what tests ran, what proof was established, and what to do next. The information exists across 40+ JSON files in a zip.

Goal:
Build a `FulfillmentReportGenerator` that produces one human-readable Markdown report covering the entire job lifecycle — suitable for human review, audit, and decision-making.

Relevant areas:
- `packages/orchestration/job_fulfillment.py` — `JobFulfillmentRecord`, `summarize_job_fulfillment()`
- `packages/orchestration/review_bundle.py` — section builders
- `packages/orchestration/dashboard.py` — `build_job_dashboard()`
- `packages/orchestration/proof_chain.py` — `summarize_proof_chain()`
- `packages/orchestration/token_economy.py` — cost estimates
- `packages/orchestration/context_pack.py` — `summarize_context_pack()`

Proposed changes:
- Create `packages/orchestration/fulfillment_report.py` with `FulfillmentReportGenerator`
- `generate_report(job, fulfillment_record, events) -> FulfillmentReport`
- `FulfillmentReport` dataclass: `markdown: str`, `sections: list[ReportSection]`, `generated_at: str`
- Report sections (in order): Executive Summary, Task Plan, Per-Task Detail (context selected, worker route, token reasoning, worker output summary, reviewer findings, repair actions), Apply/Test Results, Proof Chain Summary, Final Review Verdict, Cost Summary, Recommended Next Tasks
- Per-task detail includes: `context_profile` (what was included/excluded), `route_decision` (tier + justification), `token_cost` (estimated vs actual), `review_verdict`, `repair_rounds`
- Safe output only (no raw diffs, no secrets, no absolute paths — reuse `_scrub_public`)
- CLI command `remedy report <job_id>` to generate and display

Acceptance criteria:
- Report contains all 9 sections listed above
- Per-task detail shows context selection, route decision, and cost reasoning
- Report is valid Markdown renderable in any viewer
- No raw content, secrets, or absolute paths in output
- New tests verify report generation from fixture fulfillment data

Priority rationale:
The report is the primary human interface for job results. Without it, humans cannot audit, trust, or act on job outcomes. Required for the "AAA" transparency goal.

---

## Task 07: Per-Task Token Cost Tracking

Impact: Medium
Effort: Medium

Context:
`token_economy.py` estimates token bands (low/medium/high/unknown) and context budgets before execution. `token_policy.py` classifies steps as zero/local/expensive. But there is no post-execution token metering — actual tokens consumed by a worker are never recorded. `_DEFAULT_FUTURE_LAYERS` in `token_policy.py` explicitly lists `per_task_cost_tracking` as a TODO.

Problem:
Token estimates are produced before execution but never validated against actual consumption. There is no feedback loop to improve estimates. Cost reasoning in the fulfillment report would show estimates only, not actuals. Budget enforcement is based on guesses.

Goal:
Add post-execution token metering that records actual tokens consumed per task, per provider call, and feeds back into budget tracking and the fulfillment report.

Relevant areas:
- `packages/orchestration/token_economy.py` — estimates, budget profiles
- `packages/orchestration/token_policy.py` — `_DEFAULT_FUTURE_LAYERS` TODO list
- `packages/orchestration/builder_models.py` — `BuilderOutput`
- `packages/orchestration/task_runner.py` — post-execution
- `packages/orchestration/job_fulfillment.py` — fulfillment record

Proposed changes:
- Add `TokenUsageRecord` dataclass to `token_economy.py`: `task_id`, `provider_id`, `prompt_tokens`, `completion_tokens`, `total_tokens`, `estimated_tokens`, `accuracy_ratio`, `route_tier`, `timestamp`
- Add `record_token_usage(record, data_dir)` and `load_token_usage(job_id, data_dir) -> list[TokenUsageRecord]`
- Extend `BuilderOutput` with optional `token_usage: dict` field (providers report their consumption)
- Wire `task_runner.py` to call `record_token_usage()` after builder execution
- Add `compute_job_cost_summary(job_id, data_dir) -> JobCostSummary` that aggregates per-task costs
- Remove `per_task_cost_tracking` from `_DEFAULT_FUTURE_LAYERS` (no longer future)

Acceptance criteria:
- `TokenUsageRecord` persisted per task execution
- `accuracy_ratio` computed as `actual / estimated` (shows estimate quality)
- `compute_job_cost_summary()` returns total tokens by tier (local vs expensive)
- Fulfillment report can include actual vs estimated costs
- Providers that don't report usage get `unknown` values (no fabrication)

Priority rationale:
Cost tracking makes the token economy real. Without actuals, budget enforcement and cost optimization are guesswork. Medium priority because the system functions without it, but AAA requires it.

---

## Task 08: Goal Decomposition Planner

Impact: Medium
Effort: High

Context:
`job_runner.py:plan_job()` creates exactly 3 fixed planning tasks (analyze_requirements, define_acceptance_checks, prepare_implementation_plan) regardless of the user's goal. `llm_planner.py` exists for LLM-based planning but uses a fixture. `feature_planner.py` does feature-based planning. But none of these decompose a natural-language goal into a concrete, bounded task DAG.

Problem:
Every job gets the same 3 planning tasks. A goal like "add dark mode to the settings page" should produce tasks like: analyze component structure, create theme context, update CSS, add toggle UI, write tests. Instead it gets: analyze_requirements, define_acceptance_checks, prepare_implementation_plan — generic and unactionable.

Goal:
Build a `GoalDecomposer` that takes a human goal and produces a concrete task plan with dependency ordering, where each task has clear inputs, outputs, acceptance criteria, and estimated complexity.

Relevant areas:
- `packages/orchestration/job_runner.py` — `plan_job()`, fixed task specs
- `packages/orchestration/llm_planner.py` — LLM planner interface
- `packages/orchestration/planner_models.py` — `PlannerOutput`, `ProposedTask`
- `packages/orchestration/feature_planner.py` — feature planning
- `packages/orchestration/proposed_tasks.py` — proposed task management
- `packages/core/models.py` — `Task`, `AcceptanceCheck`

Proposed changes:
- Create `packages/orchestration/goal_decomposer.py` with `GoalDecomposer` protocol
- `decompose(goal, repo_context) -> TaskPlan` where `TaskPlan` contains ordered `PlannedTask` items
- `PlannedTask` fields: `title`, `description`, `task_type`, `inputs`, `outputs`, `depends_on: list[str]`, `acceptance_criteria: list[str]`, `estimated_complexity: str`, `suggested_route_tier: str`
- `DeterministicGoalDecomposer`: rule-based decomposition for known patterns (docs, test, refactor)
- `LLMGoalDecomposer`: uses local LLM to decompose ambiguous goals (with structured output schema)
- Wire into `job_runner.py`: replace fixed 3-task skeleton with `GoalDecomposer` output
- Preserve backward compatibility: if decomposer returns empty, fall back to fixed tasks

Acceptance criteria:
- `GoalDecomposer.decompose()` returns a `TaskPlan` with dependency ordering
- `DeterministicGoalDecomposer` handles at least 3 common patterns (docs_update, test_addition, code_change)
- `PlannedTask.depends_on` forms a valid DAG (no cycles)
- `suggested_route_tier` maps to valid `BuilderRoutingTier` values
- Existing plan_job tests pass (backward compatible)
- New tests verify decomposition for known patterns

Priority rationale:
Goal decomposition is foundational to the AAA vision — jobs should start from human intent. Medium priority because the fixed planning skeleton works for demos but blocks real-world usage.

---

## Task 09: Worker/Reviewer Auto-Loop Controller

Impact: Medium
Effort: Medium

Context:
`job_fulfillment.py` defines states WORKING → REVIEWING → REPAIRING → APPROVAL_READY. `repair_loop_v2.py` has the state machine for individual repair items. `JobFulfillmentContract` has `max_review_rounds` and `max_repair_rounds`. But there is no controller that automatically advances through the loop: execute worker → run reviewer → create repairs → re-execute → re-review → until pass or max rounds.

Problem:
The fulfillment spine has the states but not the loop driver. Each state transition must be triggered manually. The worker/reviewer cycle described in the goal ("repeat worker/reviewer loops until all required tasks pass") requires an automated loop controller.

Goal:
Build a `FulfillmentLoopController` that drives the worker→reviewer→repair cycle within configured bounds, advancing `JobFulfillmentRecord` through states automatically until completion or human intervention is needed.

Relevant areas:
- `packages/orchestration/job_fulfillment.py` — states, contract, record
- `packages/orchestration/task_runner.py` — `run_next_task()`
- `packages/orchestration/task_reviewer.py` — (from Task 03) reviewer
- `packages/orchestration/repair_loop_v2.py` — repair item management
- `packages/orchestration/route_dispatcher.py` — (from Task 04) dispatch

Proposed changes:
- Create `packages/orchestration/fulfillment_loop.py` with `FulfillmentLoopController`
- `run_loop(job, record, contract, providers) -> FulfillmentLoopResult` executes one full cycle
- Loop steps: for each pending task → build context → route → dispatch worker → review output → if findings → create repair tasks → re-dispatch → re-review → advance state
- Hard stops: `max_review_rounds`, `max_repair_rounds`, budget exhausted, human approval required
- `FulfillmentLoopResult`: `record`, `tasks_completed`, `tasks_repaired`, `tasks_blocked`, `stop_reason`
- Each iteration persists state (crash-safe: can resume from last persisted state)
- Wire into CLI: `remedy do --auto-loop` flag

Acceptance criteria:
- Loop controller advances through WORKING → REVIEWING → REPAIRING → WORKING cycle
- Stops at `max_review_rounds` or `max_repair_rounds`
- Stops when any task requires human approval
- State is persisted after each step (crash recovery)
- Budget enforcement prevents unbounded execution
- New tests verify loop with fixture providers (deterministic)

Priority rationale:
The auto-loop is what makes Remedy autonomous. Without it, every state transition requires human intervention. Medium priority because manual stepping works, but automation is the AAA differentiator.

---

## Task 10: Next-Task Recommendation with Approve/Reject/Defer Actions

Impact: Medium
Effort: Low

Context:
`reviewer.py` produces `ReviewerRecommendation` with `status` (pending/accepted/rejected). `proof_chain.py` derives `NextSafeAction` with `label`, `command`, `reason`, `available`. `job_fulfillment.py` has `next_suggestion_ids` and `next_safe_action`. But there is no unified "recommended next tasks" output with approve/reject/defer/backlog actions.

Problem:
After job completion, recommendations come from multiple sources (reviewer, proof chain, fulfillment record) in different formats. There is no single ranked list with actionable buttons. The user cannot defer a recommendation to a backlog or schedule it for later.

Goal:
Build a unified `NextTaskQueue` that collects recommendations from all sources, ranks them, and provides approve/reject/defer/backlog actions that persist decisions.

Relevant areas:
- `packages/orchestration/reviewer.py` — `ReviewerRecommendation`
- `packages/orchestration/proof_chain.py` — `NextSafeAction`
- `packages/orchestration/job_fulfillment.py` — `next_suggestion_ids`, `next_safe_action`
- `packages/orchestration/decision_queue.py` — existing decision queue
- `packages/orchestration/fulfillment_report.py` — (from Task 06) report

Proposed changes:
- Create `packages/orchestration/next_task_queue.py` with `NextTaskQueue` class
- `RankedNextTask` dataclass: `rank`, `title`, `description`, `source` (reviewer/proof_chain/fulfillment), `impact`, `effort`, `action` (pending/approved/rejected/deferred/backlog), `created_job_id` (if approved and converted to job)
- `build_next_task_queue(job, fulfillment_record, events) -> list[RankedNextTask]` merges all sources
- Ranking: critical findings first, then by impact/effort ratio
- `approve_next_task(task_id)` → creates a new Job from the recommendation
- `reject_next_task(task_id)` → marks rejected with reason
- `defer_next_task(task_id, until)` → marks deferred with timestamp
- `backlog_next_task(task_id)` → moves to backlog (persisted list)
- CLI: `remedy next` shows ranked list, `remedy next approve/reject/defer/backlog <id>`

Acceptance criteria:
- `build_next_task_queue()` merges recommendations from reviewer, proof chain, and fulfillment
- Tasks ranked by impact with source attribution
- All 4 actions (approve/reject/defer/backlog) persist state
- `approve` creates a new Job with the recommendation as goal
- CLI `remedy next` displays the ranked list with actions
- New tests verify merge, ranking, and action persistence

Priority rationale:
This is the user-facing "what's next" interface. Lower priority because it's a UX improvement on top of working functionality, but essential for the AAA closed-loop workflow where every job ends with actionable next steps.
