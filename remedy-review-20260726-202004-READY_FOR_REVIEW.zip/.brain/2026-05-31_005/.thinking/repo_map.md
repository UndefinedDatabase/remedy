# Repo Map

- packages/orchestration/: execution engine, event ledger, brain graph, UI server, storage, worker registry, context packing
- packages/memory/: local JSONL memory gateway and models
- packages/artifacts/: reserved package for future artifact persistence
- apps/cli/commands/: operator commands for jobs, events, brain, patch, project, ui
- apps/ui/src/: React dashboard, polling shell, graph stage, API client
- tests/: broad step-based coverage with dedicated storage, run log, project brain, memory, UI, and CLI tests
