# Relevant Files

## Memory and context
- packages/memory/local_gateway.py
- packages/orchestration/llm_planner.py
- packages/orchestration/context_pack.py
- tests/test_memory_gateway.py
- tests/test_memory_learn.py

## Replay, events, and summaries
- packages/orchestration/event_ledger.py
- apps/cli/commands/event.py
- apps/cli/commands/job.py
- tests/test_run_log.py
- tests/test_cli_main.py

## Brain and project coordination
- packages/orchestration/project_brain.py
- packages/orchestration/project_brain_aggregate.py
- packages/orchestration/project_registry.py
- apps/ui/src/RemedyApp.tsx
- tests/test_project_brain.py

## Worker routing and execution
- packages/orchestration/worker_adapters.py
- packages/orchestration/task_runner.py
- packages/orchestration/worker_recommend.py
- packages/contracts/interfaces.py

## Storage and reliability
- packages/orchestration/storage.py
- packages/orchestration/ui_server.py
- tests/test_storage.py
