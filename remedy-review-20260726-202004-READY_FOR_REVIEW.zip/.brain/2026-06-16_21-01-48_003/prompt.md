How to improve the project? Make a full review
