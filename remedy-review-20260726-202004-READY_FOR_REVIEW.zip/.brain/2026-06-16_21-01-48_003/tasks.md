# Brainstorm Tasks — Full Project Review

## Task 01: Replace Exception-Swallowing Pattern in review_bundle.py with Structured Error Reporting

Impact: High
Effort: Medium

Context:
`packages/orchestration/review_bundle.py` is 2138 lines and contains ~40 bare `except Exception:` blocks. Each section builder function catches all exceptions and returns `{"status": "section_unavailable", "reason": "..."}`. This pattern silently hides real bugs — a typo in a field name, a missing import, or a data model change all produce the same "unavailable" response with no traceback.

Problem:
When a review bundle section fails, there is zero diagnostic information. Developers cannot distinguish between "module not installed" and "code has a bug." The pattern has spread to other modules too (~100 total `except Exception:` across orchestration), but review_bundle.py is the worst offender with 40 instances in a single file.

Goal:
Replace blind exception swallowing with structured error capture that preserves diagnostic information while maintaining the "graceful degradation" behavior. Sections should still degrade gracefully, but the *reason* for degradation must be visible.

Relevant areas:
- packages/orchestration/review_bundle.py (lines 1506-1968, section builder functions)
- packages/orchestration/repair_loop_v2.py (10 instances)
- packages/orchestration/real_test_execution.py (6 instances)
- packages/orchestration/overnight_mission.py (8 instances)
- packages/orchestration/test_execution_service.py (6 instances)

Proposed changes:
- Create a `_safe_section(name: str, builder: Callable) -> dict` helper that catches exceptions, logs the exception type + message (not full traceback) into the result dict under a `"error_type"` key, and returns the degraded result
- Replace all 40 try/except blocks in review_bundle.py with calls to `_safe_section`
- Add an `"error_detail"` field to degraded results that includes `type(exc).__name__` and a redacted message (no paths, no secrets)
- Add a `"degraded_section_count"` summary field to the top-level review bundle export
- Audit and apply the same pattern to the other 5 worst-offender files

Acceptance criteria:
- Zero bare `except Exception:` blocks in review_bundle.py
- Every degraded section includes `error_type` in its result dict
- Top-level review bundle export includes `degraded_section_count`
- All existing review_bundle tests pass unchanged
- No secrets, absolute paths, or raw tracebacks in any degraded section output

Priority rationale:
This is the single biggest maintainability hazard in the codebase. Every hidden exception is a potential production bug that will take 10x longer to diagnose. Fixing this makes every other debugging task faster.

---

## Task 02: Replace 63-Branch If/Elif Argument Parser in grouped.py with Data-Driven Registration

Impact: High
Effort: Low

Context:
`apps/cli/grouped.py` builds argparse trees from the command catalog. The `_add_command_args` function contains a 63-branch if/elif chain — one branch per CLI option name (`--json`, `--reason`, `--project`, etc.). Every new CLI option requires adding another elif branch to this function.

Problem:
The command catalog (`apps/cli/command_catalog.py`) already defines `ArgDef` with `name`, `help`, `required`, `is_option`, and `default` fields. The grouped.py if/elif chain duplicates this metadata by hardcoding how each named argument maps to argparse. This is unmaintainable, error-prone, and grows linearly with every new option.

Goal:
Replace the if/elif chain with a generic function that derives argparse arguments directly from `ArgDef` metadata. The catalog should be the single source of truth for argument shape.

Relevant areas:
- apps/cli/grouped.py (lines 54-200, `_add_command_args`)
- apps/cli/command_catalog.py (`ArgDef` dataclass)

Proposed changes:
- Extend `ArgDef` with optional fields: `action` (store_true, etc.), `dest` (explicit destination name), `nargs` (for optional-value args)
- Replace `_add_command_args` with a generic loop: for each arg, derive argparse kwargs from ArgDef fields
- Handle the `--json` → `dest="json"` and `--no-tests` → `action="store_true"` patterns via the new ArgDef fields
- Update the catalog entries to include `action`/`dest` where needed
- Remove the entire if/elif chain

Acceptance criteria:
- `_add_command_args` is <20 lines (a single loop, no branching on arg names)
- All existing CLI tests pass unchanged
- Adding a new CLI option requires only a catalog entry change, no grouped.py edit
- No behavioral change to any existing command

Priority rationale:
Every new CLI command or option requires touching this if/elif chain. This blocks feature velocity and introduces copy-paste bugs. Fix is small (1-2 files) with outsized maintainability impact.

---

## Task 03: Split review_bundle.py into Composable Section Modules

Impact: High
Effort: High

Context:
`packages/orchestration/review_bundle.py` is 2138 lines — the second largest module in the project. It contains 30+ internal "section builder" functions (e.g., `_build_progress_summary`, `_build_integrity_summary`, `_build_contract_summary`) plus data models, redaction logic, export formatting, and the top-level `build_review_bundle` orchestrator.

Problem:
All 30+ sections are defined in a single file with no intermediate types or contracts. Adding a new section means scrolling through 2000+ lines. Testing individual sections requires importing the entire module. The file mixes concerns: data aggregation, formatting, redaction, and export.

Goal:
Split review_bundle.py into a package with one module per concern, keeping the public API stable.

Relevant areas:
- packages/orchestration/review_bundle.py
- tests/orchestration/test_review_bundle.py
- tests/cli/test_review_bundle_runtime.py

Proposed changes:
- Create `packages/orchestration/review_bundle/` package
- Move section builders into grouped modules: `sections_progress.py`, `sections_integrity.py`, `sections_proof.py`, etc.
- Move redaction logic to `review_bundle/redaction.py`
- Move data models to `review_bundle/models.py`
- Keep `review_bundle/__init__.py` as the public API surface (re-exports)
- Update imports in test files

Acceptance criteria:
- No single file in review_bundle/ exceeds 400 lines
- Public API (`build_review_bundle`, `export_review_bundle_json`, etc.) unchanged
- All existing tests pass unchanged
- Each section module is independently importable and testable

Priority rationale:
This file is the largest single-file quality debt. It combines 30+ concerns in one module, making it hard to review, test, or extend. Every new review section makes it worse.

---

## Task 04: Align Protocol Interfaces with Actual Usage (Remove Async or Implement It)

Impact: Medium
Effort: Medium

Context:
`packages/contracts/interfaces.py` defines 5 Protocol classes with async methods: `LLMWorker.execute/stream`, `MemoryGateway.read/write/delete`, `RuntimeProvider.run`, `Verifier.verify`. However, the entire orchestration layer is synchronous. Only `packages/memory/local_gateway.py` has async def implementations. The Ollama providers use synchronous calls.

Problem:
The async protocols create a false contract. No code awaits these methods. The Protocol type checks would fail if anyone tried to use `isinstance()` checks against synchronous implementations. The interfaces suggest an async architecture that doesn't exist.

Goal:
Decide: either make the codebase async-ready (significant effort) or make the protocols match reality (sync). Given the current state, aligning to sync is the pragmatic choice.

Relevant areas:
- packages/contracts/interfaces.py (all 5 Protocol classes)
- packages/memory/local_gateway.py (has async implementations)
- packages/providers/ollama_planner/provider.py (sync)
- packages/providers/ollama_builder/provider.py (sync)
- tests/test_imports.py

Proposed changes:
- Remove `async` from all Protocol method signatures in interfaces.py
- Remove `AsyncIterator` import, change `stream` return type to `Iterator[str]`
- Update `local_gateway.py` to use sync methods (remove `async def`)
- Verify no other code depends on async protocol methods
- Add a `# Future: async variants can be added as separate protocols` comment

Acceptance criteria:
- All Protocol methods are synchronous
- `local_gateway.py` methods are synchronous
- All existing tests pass
- No `async def` in packages/contracts/ or packages/memory/
- Protocol classes remain `@runtime_checkable`

Priority rationale:
False contracts erode trust in the interface layer. Developers looking at interfaces.py will design async code that doesn't fit the actual architecture. Fixing this is a clean 2-file change with high signal value.

---

## Task 05: Add Ruff Linter and Formatter Configuration

Impact: High
Effort: Low

Context:
The project has no linter or formatter configuration. No `ruff.toml`, no `[tool.ruff]` in pyproject.toml, no `mypy.ini`, no pre-commit hooks. Code quality is enforced only through test assertions (e.g., tests checking for `shell=True` patterns). There are 62K+ lines of Python with no automated style enforcement.

Problem:
Without a linter, issues like unused imports, undefined names, unreachable code, and style inconsistencies accumulate silently. The test-based checks (checking source code for string patterns) are fragile and incomplete. A proper linter would catch the `except Exception:` pattern, unused variables, and more.

Goal:
Add Ruff configuration to pyproject.toml with a pragmatic rule set that passes on the existing codebase (or with minimal fixes), then enable stricter rules incrementally.

Relevant areas:
- pyproject.toml
- packages/orchestration/*.py (62K lines)
- apps/cli/*.py
- tests/*.py

Proposed changes:
- Add `[tool.ruff]` section to pyproject.toml with target Python 3.10
- Enable safe rule sets: E (pycodestyle errors), F (pyflakes), I (isort), UP (pyupgrade)
- Set `line-length = 120` (matches existing code style)
- Add `[tool.ruff.lint.per-file-ignores]` for tests (allow assert, etc.)
- Run `ruff check --fix` to auto-fix safe issues
- Add `ruff check` to the test CI or as a documented developer step

Acceptance criteria:
- `ruff check` passes on the entire codebase with the configured rule set
- pyproject.toml has a `[tool.ruff]` section
- At least E, F, I, UP rule sets are enabled
- No behavioral changes to any code
- README or docs mentions running ruff

Priority rationale:
This is the highest-leverage, lowest-effort improvement. A linter catches entire categories of bugs automatically. Every other task becomes easier when a linter guards against regressions. Low effort because Ruff auto-fixes most issues.

---

## Task 06: Remove Legacy UI Code in apps/ui/legacy/

Impact: Medium
Effort: Low

Context:
`apps/ui/legacy/` contains the old PixiJS-based brain graph renderer: `main.ts`, `brain/renderer.ts`, `brain/detail.ts`, plus a full `legacy/dist/` directory with bundled JavaScript assets (WebGLRenderer, CanvasRenderer, etc.). The main UI has been completely rebuilt using React + react-force-graph-2d in `apps/ui/src/`.

Problem:
The legacy code is dead weight. It adds confusion for new developers ("which renderer is active?"), bloats the repository with unused dist assets, and creates a false impression that PixiJS is a project dependency.

Goal:
Remove the entire `apps/ui/legacy/` directory and any references to it.

Relevant areas:
- apps/ui/legacy/ (entire directory)
- apps/ui/legacy/dist/ (bundled JS assets)
- apps/ui/legacy/brain/ (old PixiJS renderers)
- apps/ui/package.json (check for PixiJS/legacy dependencies)
- apps/ui/src/ (verify no imports from legacy/)

Proposed changes:
- Verify no file in `apps/ui/src/` imports from `../legacy/` or references legacy renderers
- Remove `apps/ui/legacy/` directory entirely
- Remove any PixiJS-related dependencies from `apps/ui/package.json` if present
- Update any docs that reference the legacy renderer

Acceptance criteria:
- `apps/ui/legacy/` directory does not exist
- No imports reference legacy paths
- UI builds and serves correctly without legacy code
- No PixiJS dependencies remain in package.json (unless used elsewhere)

Priority rationale:
Dead code confuses contributors and bloats the repo. This is a clean deletion with zero risk — the legacy renderer is completely superseded by the React implementation.

---

## Task 07: Update README.md to Reflect Current Project State

Impact: Medium
Effort: Medium

Context:
README.md is 590 lines, primarily documenting Steps 1-10 in exhaustive detail. The "What Is NOT Implemented Yet" section at line 562 lists features that have been implemented (agent loops, provider implementations, patch application, run contracts, etc.). The project is at Step 2025+ but the README still reads like a Step 10 project.

Problem:
The README is the first thing contributors see. An outdated "not implemented" list undermines confidence in the project. The step-by-step history (Steps 1-10) is valuable for archaeology but shouldn't dominate the README. Current capabilities and usage are buried or missing.

Goal:
Restructure README to lead with current capabilities, move historical step details to docs/, and accurately reflect what's implemented.

Relevant areas:
- README.md (590 lines)
- docs/ (60+ feature documents)

Proposed changes:
- Move Step 1-10 detailed history to `docs/history.md` or `docs/step-history.md`
- Rewrite README intro to describe current capabilities (orchestration, CLI, UI, providers, overnight missions, proof chains, etc.)
- Update "What Is NOT Implemented Yet" to accurately reflect current state
- Add a "Quick Start" section with the most common CLI commands
- Keep README under 200 lines — link to docs/ for details
- Add a "Project Structure" section reflecting the actual current structure

Acceptance criteria:
- README is under 200 lines
- "What Is NOT Implemented Yet" section is accurate
- Current capabilities (agent loops, overnight missions, UI, etc.) are mentioned
- Step history is preserved in docs/ but not in README
- All links in README are valid

Priority rationale:
README is the project's front door. An outdated README creates a worse first impression than no README at all. Medium effort because it requires understanding what IS implemented to write accurate descriptions.

---

## Task 08: Extract Common Patterns from Orchestration Megamodules into Shared Utilities

Impact: Medium
Effort: Medium

Context:
Multiple orchestration modules repeat the same patterns: safe JSON export with redaction, safe file path construction, timestamp generation, "section unavailable" fallback dicts, safe string truncation, and data directory resolution. For example, `_scrub_public()` and `_safe_path_label()` are defined in `provider_trust.py` but imported by `token_economy.py`.

Problem:
Utility functions are scattered across domain modules. `provider_trust.py` exports `_scrub_public` (a private-by-convention function) that's imported by other modules. Redaction logic is duplicated between review_bundle.py and other exporters. Data path resolution is in `data_paths.py` but some modules still have local path construction.

Goal:
Extract genuinely shared utilities into dedicated utility modules under `packages/orchestration/`, reducing coupling between domain modules.

Relevant areas:
- packages/orchestration/provider_trust.py (`_scrub_public`, `_safe_path_label`)
- packages/orchestration/token_economy.py (imports from provider_trust)
- packages/orchestration/review_bundle.py (redaction, truncation, fallback dicts)
- packages/orchestration/data_paths.py (path resolution)
- packages/orchestration/markdown_output_safety.py (output sanitization)
- packages/orchestration/redaction_patterns.py (redaction)

Proposed changes:
- Create `packages/orchestration/safe_export.py` for `_scrub_public`, `_safe_path_label`, safe dict construction, and truncation helpers
- Move redaction helpers to a single `redaction.py` (check if `redaction_patterns.py` already covers this)
- Update imports in provider_trust.py, token_economy.py, review_bundle.py, etc.
- Rename `_scrub_public` to `scrub_public` (it's a public API if other modules import it)

Acceptance criteria:
- No cross-module imports of `_private` functions
- Shared utility functions live in dedicated utility modules
- All existing tests pass
- No new functionality — pure extraction refactor

Priority rationale:
Cross-module private imports are a code smell that makes refactoring dangerous. Extracting shared utilities makes module boundaries cleaner and reduces the risk of breaking changes when any single module is refactored.

---

## Task 09: Clean Up Empty Package Stubs or Document Them as Planned

Impact: Low
Effort: Low

Context:
Six packages have been empty since Step 1: `packages/artifacts/`, `packages/verification/`, `packages/runtimes/`, `apps/api/`, `apps/worker/`, and three provider stubs (`claude_agent/`, `docker_runtime/`, `mempalace/`). Each contains only an empty `__init__.py`.

Problem:
Empty packages create confusion: "Is this coming soon? Is it abandoned? Should I implement something here?" The pyproject.toml `packages = ["packages", "apps"]` includes them in the wheel, adding dead weight to the distribution. New contributors waste time investigating these stubs.

Goal:
Either remove empty stubs that have no near-term implementation plan, or add a clear docstring to each `__init__.py` explaining the planned purpose and timeline.

Relevant areas:
- packages/artifacts/__init__.py
- packages/verification/__init__.py
- packages/runtimes/__init__.py
- packages/providers/claude_agent/__init__.py
- packages/providers/docker_runtime/__init__.py
- packages/providers/mempalace/__init__.py
- apps/api/__init__.py
- apps/worker/__init__.py
- pyproject.toml (package includes)

Proposed changes:
- For stubs with planned implementations (claude_agent, docker_runtime): add a docstring explaining planned purpose, referencing relevant docs/
- For stubs with no near-term plan (artifacts, verification, runtimes): add a `# Planned: <description>. Not yet implemented.` comment or remove entirely
- For apps/api and apps/worker: add docstrings explaining planned role
- Consider excluding empty packages from wheel build in pyproject.toml

Acceptance criteria:
- Every empty `__init__.py` either has a docstring explaining its purpose or is removed
- No empty packages without documentation
- pyproject.toml accurately reflects included packages
- No import breakage from any changes

Priority rationale:
Low effort, low risk, but improves project navigability. Clearing dead wood makes the project structure honest about what exists vs. what's planned.

---

## Task 10: Introduce Orchestration Module Size Budget and Split ui_server.py

Impact: Medium
Effort: High

Context:
`packages/orchestration/ui_server.py` is 2620 lines — the largest module in the project. It contains HTTP route handlers, WebSocket support, static file serving, browser launching, CORS handling, data fetching, view model construction, and server lifecycle management — all in one file. Three other modules exceed 2000 lines: `review_bundle.py` (2138), `progress_ledger.py` (2088).

Problem:
2600-line single-file servers are hard to review, hard to test in isolation, and hard to modify safely. A routing change risks breaking WebSocket handling. Static file serving logic is interleaved with data transformation. The file violates the project's own commit discipline ("avoid large or mixed commits").

Goal:
Split ui_server.py into a package with clear separation of concerns, and establish a soft module size budget to prevent future bloat.

Relevant areas:
- packages/orchestration/ui_server.py (2620 lines)
- packages/orchestration/ui_view_model.py (1127 lines, already partially split)
- tests/ui_server/*.py (test files)
- apps/ui/ (frontend consuming the API)

Proposed changes:
- Create `packages/orchestration/ui_server/` package
- Split into: `routes.py` (HTTP handlers), `websocket.py` (WS handlers), `static.py` (static file serving), `server.py` (lifecycle, CORS, startup), `data_fetch.py` (backend data aggregation)
- Keep `ui_server/__init__.py` as public API surface
- Add a comment in AGENTS.md or docs/architecture.md: "Orchestration modules should stay under 500 lines. Split when approaching this limit."
- Update test imports

Acceptance criteria:
- No single file in ui_server/ exceeds 600 lines
- Public API (`start_ui_server`, route handlers) unchanged
- All ui_server tests pass unchanged
- UI frontend works identically (same API surface)
- Architecture docs mention the module size guideline

Priority rationale:
ui_server.py is the largest file and combines the most unrelated concerns. Splitting it sets a precedent for keeping other growing modules manageable. High effort because HTTP routing refactors require careful testing.
