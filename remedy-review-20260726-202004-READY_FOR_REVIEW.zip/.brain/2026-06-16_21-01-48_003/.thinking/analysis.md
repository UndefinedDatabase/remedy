# Analysis

## Finding 1: Exception Swallowing Epidemic
~100 bare `except Exception:` blocks across orchestration. review_bundle.py alone has ~40.
Pattern: every section builder catches Exception and returns `{"status": "section_unavailable"}`.
Risk: Real bugs hidden behind "section_unavailable" messages. No logging, no tracing.

## Finding 2: CLI Argument Parser — Unmaintainable If/Elif Chain
grouped.py has a 63-branch if/elif chain in _add_command_args(). Each new CLI option
requires adding another elif. The catalog already has arg metadata — the parser should
be data-driven, not hardcoded.

## Finding 3: Module Bloat in Orchestration
15 files exceed 1000 lines. Total: 62K lines in packages/orchestration/.
Many files combine data models, business logic, persistence, formatting, and export in one module.
Splitting by concern would improve testability and readability.

## Finding 4: Async/Sync Protocol Mismatch
contracts/interfaces.py defines all Protocol methods as async (execute, stream, read, write, etc.)
but the entire codebase is synchronous. Only packages/memory/local_gateway.py has async defs.
The protocols are never type-checked at runtime against actual implementations.

## Finding 5: README Staleness
README is 590 lines. The "What Is NOT Implemented Yet" section lists features that ARE implemented:
agent loops, provider implementations, patch application, etc. README describes Steps 1-10 in detail
but the project is at Step 2025+.

## Finding 6: Empty Package Stubs
6 packages (artifacts, verification, runtimes, api worker, 3 providers) are empty __init__.py.
They've been empty since Step 1. Either implement or remove to reduce confusion.

## Finding 7: Legacy UI Code
apps/ui/legacy/ contains old PixiJS-based renderers (detail.ts, renderer.ts, main.ts) plus
a full legacy dist/ with bundled assets. The main UI has been rebuilt with React + force-graph.
Legacy code is dead weight.

## Finding 8: No Linter/Formatter Configuration
No ruff.toml, no mypy.ini, no pre-commit hooks. pyproject.toml has no [tool.ruff] or [tool.mypy]
sections. Code quality is enforced only by tests checking for specific patterns (shell=True, etc.)

## Finding 9: Monolithic Data Models in review_bundle.py
review_bundle.py builds a giant JSON export by calling 30+ internal "section builder" functions,
each with its own try/except. This is effectively a 2138-line function composition with no
intermediate types or contracts.

## Finding 10: Provider Trust + Token Economy + Builder Routing Overlap
Multiple modules handle similar concerns around "should this route/provider be used":
provider_trust.py (1078 lines), token_economy.py, builder_routing.py (1077 lines),
token_policy.py, worker_registry.py (1035 lines). Boundary between them is unclear.
