# Relevant Files for Improvement Analysis

## Critical Quality Issues
- packages/orchestration/review_bundle.py — 2138 lines, ~40 bare except Exception: blocks
- apps/cli/grouped.py — 63-branch if/elif chain for argument parsing
- packages/contracts/interfaces.py — async Protocol methods never used (all impl is sync)
- README.md — 590 lines, "What Is NOT Implemented" section outdated

## Module Bloat (>1000 lines each)
- packages/orchestration/ui_server.py — 2620 lines
- packages/orchestration/review_bundle.py — 2138 lines
- packages/orchestration/progress_ledger.py — 2088 lines
- packages/orchestration/brain_detail.py — 1737 lines
- packages/orchestration/repository_snapshot.py — 1650 lines
- packages/orchestration/repair_loop.py — 1466 lines
- packages/orchestration/project_brain.py — 1218 lines
- packages/orchestration/repair_loop_v2.py — 1168 lines
- packages/orchestration/orchestrator_brain.py — 1139 lines
- packages/orchestration/ui_view_model.py — 1127 lines
- packages/orchestration/overnight_executor.py — 1118 lines
- packages/orchestration/provider_trust.py — 1078 lines
- packages/orchestration/builder_routing.py — 1077 lines
- packages/orchestration/command_discovery.py — 1071 lines
- packages/orchestration/test_execution_service.py — 1070 lines

## Empty Stubs
- packages/providers/claude_agent/__init__.py
- packages/providers/docker_runtime/__init__.py
- packages/providers/mempalace/__init__.py
- packages/runtimes/__init__.py
- packages/verification/__init__.py
- packages/artifacts/__init__.py
- apps/api/__init__.py
- apps/worker/__init__.py

## Legacy Code
- apps/ui/legacy/ — Old PixiJS-based brain renderers (replaced by force-graph)
