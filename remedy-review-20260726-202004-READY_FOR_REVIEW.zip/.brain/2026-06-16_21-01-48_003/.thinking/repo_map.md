# Repo Map

## Structure
- apps/cli/ — CLI entry point (grouped.py, command_catalog.py, 50+ command files)
- apps/ui/ — React/TypeScript frontend (Vite, force-graph, timeline, pipeline views)
- apps/ui/legacy/ — Old PixiJS-based renderers (still present)
- apps/api/ — Empty stub
- apps/worker/ — Empty stub
- packages/core/ — Pydantic domain models (Job, Task, Artifact, RunState)
- packages/contracts/ — Protocol interfaces (LLMWorker, MemoryGateway, RuntimeProvider, Verifier)
- packages/orchestration/ — 90+ modules, 62K lines total — the bulk of the project
- packages/memory/ — Local gateway + context summary
- packages/providers/ — Ollama planner/builder (real), claude_agent/docker_runtime/mempalace (stubs)
- packages/runtimes/ — Empty stub
- packages/verification/ — Empty stub
- packages/artifacts/ — Empty stub
- scripts/ — Smoke test runners
- tests/ — 204 test files across cli/, orchestration/, regression/, storage/, ui_contracts/, ui_server/
- docs/ — 60+ markdown files documenting features

## Key Metrics
- Python files: ~300+
- Total orchestration lines: 61,843
- Test files: 204
- Largest files: ui_server.py (2620), review_bundle.py (2138), progress_ledger.py (2088)
- CLI command files: 50+
- Docs files: 60+
- .data/ size: 308MB (gitignored)
- remedy-review-*.zip: 71 files (gitignored)
