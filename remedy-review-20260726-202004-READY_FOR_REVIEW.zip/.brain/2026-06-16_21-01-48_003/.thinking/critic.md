# Critic Review

## Rejected Ideas
- "Add type hints everywhere" — too generic, not actionable
- "Improve test coverage" — already 204 test files, coverage is decent
- "Add logging" — valid but too broad without specifying WHERE
- "Refactor everything" — not a task, it's a wish

## Kept Ideas (Evidence-Backed)
1. Exception swallowing — 100 instances, real risk, concrete fix
2. CLI if/elif chain — 63 branches, measurable, data-driven fix is clear
3. Module splitting — specific files identified, clear split points
4. Async/sync mismatch — protocols unused, either align or remove
5. README update — specific outdated sections identified
6. Dead code removal — legacy/, empty stubs are concrete
7. Linter/formatter — zero config exists, easy to add
8. review_bundle refactor — specific file, specific pattern
9. Route/trust/economy boundary — specific modules, unclear responsibilities
10. Data-driven CLI arg parsing — specific code, specific solution

## Priority Ordering Rationale
Prioritized by: impact on maintainability x effort to fix x risk of leaving unfixed
- Exception swallowing is #1 because it actively hides bugs in production
- CLI arg parsing is #2 because it blocks every new feature addition
- review_bundle is #3 because it's the single largest quality debt file
