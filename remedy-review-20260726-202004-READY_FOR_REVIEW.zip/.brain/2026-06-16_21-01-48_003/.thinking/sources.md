# Sources

## Direct Reads
- pyproject.toml — build config, dependencies, test markers
- README.md — 590 lines, step-by-step history
- packages/core/models.py — Pydantic domain models
- packages/contracts/interfaces.py — Protocol interfaces (async)
- packages/orchestration/storage.py — atomic job persistence
- packages/orchestration/agent_loop.py — execution loop
- packages/orchestration/integrity_gate.py — pre-handoff checks
- packages/orchestration/repair_loop.py — failure→fix cycle
- packages/orchestration/token_economy.py — token cost estimation
- packages/orchestration/main_builder_adapter.py — external builder rail
- packages/orchestration/proof_chain.py — provenance chain
- apps/cli/main.py — CLI thin bridge
- apps/cli/grouped.py — argparse tree builder (407 lines)
- apps/cli/command_catalog.py — command registry
- .gitignore — comprehensive, covers .data/, .brain/, review zips, node_modules

## Grep Searches
- `except (Exception|BaseException):` — ~100 matches across orchestration
- `elif arg.name ==` — 63 matches in grouped.py
- `async def` — 10 matches (only in contracts + memory gateway)
- `shell=True` — 0 in production code, 90+ in test assertions (good)
- `TODO|FIXME` — minimal, mostly in verifier_profiles.py (used as forbidden phrases)
- `subprocess.run/call/Popen` — found in autorun, test_runner, integrity_gate, ui_server, etc.

## Line Counts
- wc -l packages/orchestration/*.py → 61,843 total, top 15 files >1000 lines
- wc -l apps/cli/grouped.py → 407 lines
- wc -l README.md → 590 lines
- find tests -name '*.py' | wc -l → 204 test files

## Size Checks
- du -sh .data/ → 308MB
- ls remedy-review-*.zip | wc -l → 71 zip files
