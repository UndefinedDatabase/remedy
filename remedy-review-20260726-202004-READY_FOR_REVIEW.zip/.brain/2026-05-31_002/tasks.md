## Task 01: Integrate Project Memory Into Planning And Execution

Impact: High  
Effort: Medium  

Context:
Remedy already has a project-scoped memory system in `packages/memory/local_gateway.py` with `store_memory()`, `recall_memory()`, `upsert_memory()`, and approval-aware helpers. The current planning path in `packages/orchestration/llm_planner.py` and the context assembly in `packages/orchestration/context_pack.py` do not inject recalled memory into live planning or task execution.

Problem:
The system has durable memory infrastructure, but planners and builders still operate mostly statelessly. That leaves project-specific lessons, prior failures, and accepted guidance out of the execution loop.

Goal:
Make planning and task execution memory-aware by recalling approved project memory and including it in planner prompts and execution context in a bounded, testable way.

Relevant areas:
- `packages/memory/local_gateway.py`
- `packages/orchestration/llm_planner.py`
- `packages/orchestration/context_pack.py`
- `packages/orchestration/task_runner.py`
- `tests/test_memory_gateway.py`
- `tests/test_memory_learn.py`

Proposed changes:
- Add a project-memory retrieval step before planning that pulls approved, relevant memory entries by project or job scope.
- Extend planning and execution context models to carry a bounded memory summary instead of raw unbounded memory content.
- Thread that summary into planner and builder call sites without breaking deterministic verification boundaries.
- Add tests covering empty memory, approved memory, and memory-budget truncation behavior.

Acceptance criteria:
- Planning and task execution receive recalled approved memory when a project has relevant entries.
- Memory summaries are bounded and do not expose forbidden raw content fields.
- Existing planner and memory tests still pass, with new coverage for recall integration.
- A job with no stored memory behaves exactly as before.

Priority rationale:
This is the highest-leverage differentiator already latent in the codebase: the memory layer exists, but wiring it into execution would make Remedy feel project-aware instead of stateless.

## Task 02: Add Event-Ledger Replay And Checkpoint Resume

Impact: High  
Effort: High  

Context:
`packages/orchestration/event_ledger.py` already provides normalized, redacted event records and timelines. The repo also has continuation-oriented modules such as `continue_from_node.py`, but there is no job-level replay or resume capability built on top of the existing event history.

Problem:
Long-running or interrupted jobs cannot be resumed from a known checkpoint using the event stream that Remedy already records. Recovery depends on ad hoc manual inspection instead of deterministic replay.

Goal:
Implement a replay and checkpoint-resume path that can reconstruct job progress from run-log events and continue from a safe boundary.

Relevant areas:
- `packages/orchestration/event_ledger.py`
- `packages/orchestration/run_log.py`
- `packages/orchestration/continue_from_node.py`
- `apps/cli/commands/event.py`
- `apps/cli/commands/job.py`
- `tests/test_run_log.py`

Proposed changes:
- Define a replay model that maps event sequences to resumable checkpoints such as planned, task-started, task-completed, and patch-approved boundaries.
- Add orchestration helpers that rebuild checkpoint state from existing run logs without exposing redacted content.
- Add a CLI entry point to inspect available checkpoints and resume from the latest safe one.
- Add focused tests for interrupted runs, replay determinism, and invalid checkpoint handling.

Acceptance criteria:
- A job with prior run-log events can report resumable checkpoints.
- Replay reconstructs safe state without requiring raw prompts, raw output, or diff previews.
- Resume behavior is covered by tests for at least one interrupted-run scenario.
- Existing run-log behavior remains backward compatible.

Priority rationale:
Fault-tolerant resume is a major platform step-up, and most of the foundational event machinery is already in place.

## Task 03: Surface Multi-Job Project Brain As A First-Class Product Capability

Impact: High  
Effort: Medium  

Context:
`packages/orchestration/project_brain_aggregate.py` already builds a cross-job aggregate brain graph, and `packages/orchestration/project_registry.py` provides project/job linkage. Today, that capability is not surfaced as a primary API or UI feature.

Problem:
The repo can model multi-job coordination internally, but operators still experience Remedy mainly as a single-job tool. That leaves a major differentiator hidden behind implementation-only code.

Goal:
Expose an aggregate project brain endpoint and corresponding UI flow so teams can inspect coordination across all jobs in a project.

Relevant areas:
- `packages/orchestration/project_brain_aggregate.py`
- `packages/orchestration/project_registry.py`
- `packages/orchestration/ui_server.py`
- `apps/cli/commands/project.py`
- `apps/ui/src/RemedyApp.tsx`
- `tests/test_project_brain.py`

Proposed changes:
- Add a project-level API payload that exports aggregate nodes, edges, and summary data from the existing aggregate builder.
- Add CLI support to fetch or summarize project-level brain data.
- Extend the UI to switch between single-job and project aggregate views.
- Add tests for aggregate graph export and project-linked job visibility.

Acceptance criteria:
- Operators can request an aggregate graph for a project without custom scripts.
- The aggregate payload contains project, repo, and job linkage derived from existing project metadata.
- UI or CLI output clearly distinguishes project-scope from single-job scope.
- Aggregate graph behavior is covered by focused tests.

Priority rationale:
This turns a mostly hidden backend capability into a standout feature that moves Remedy toward real multi-job orchestration.

## Task 04: Wire Worker Adapter Selection Into Task Execution

Impact: High  
Effort: Medium  

Context:
`packages/orchestration/worker_adapters.py` defines worker provider specs for Ollama, Claude Code, Copilot, OpenAI, and other future providers. `packages/orchestration/worker_recommend.py` exists, but `packages/orchestration/task_runner.py` still relies on manually injected builder callables instead of provider routing.

Problem:
The repo advertises provider-neutral worker infrastructure, but execution does not actually use that registry to route tasks by role, cost, or capability.

Goal:
Make task execution capable of selecting a provider through the existing worker adapter scaffolding instead of relying on a single hard-coded path.

Relevant areas:
- `packages/orchestration/worker_adapters.py`
- `packages/orchestration/worker_recommend.py`
- `packages/orchestration/task_runner.py`
- `packages/contracts/interfaces.py`
- `tests/test_task_runner.py`

Proposed changes:
- Define a minimal worker-selection contract for task execution that chooses a provider by task role and availability.
- Connect `task_runner` to the worker recommendation or registry layer while preserving current default behavior.
- Record provider selection in structured metadata and run-log events.
- Add tests for default-provider selection, unsupported-role handling, and provider override behavior.

Acceptance criteria:
- Task execution can choose a provider through a worker-selection layer rather than a single injected path.
- Existing single-provider behavior remains the default fallback.
- Provider choice is visible in structured execution metadata.
- New tests cover at least one routed and one fallback execution case.

Priority rationale:
Provider routing is already scaffolded in the codebase and is a practical way to differentiate Remedy on quality, latency, and cost without a full rewrite.

## Task 05: Introduce Artifact Archival And Indexed Retrieval

Impact: High  
Effort: High  

Context:
Artifacts are still stored inline inside job JSON, while `packages/artifacts/__init__.py` remains only a reserved namespace. Current indexing in orchestration is lightweight and does not provide version history, archival, or scalable retrieval.

Problem:
Inline artifact storage bloats job files, makes metadata queries expensive, and leaves Remedy without a durable artifact history layer for larger runs.

Goal:
Add an artifact persistence layer that stores artifact metadata and payloads separately, supports retrieval by kind or id, and keeps job files lightweight.

Relevant areas:
- `packages/artifacts/__init__.py`
- `packages/orchestration/artifact_index.py`
- `packages/orchestration/storage.py`
- `packages/core/models.py`
- `tests/test_artifact_kinds.py`
- `tests/test_storage.py`

Proposed changes:
- Define a minimal artifact store in `packages/artifacts/` that separates metadata from content.
- Update orchestration storage and retrieval paths to lazy-load artifact content when needed.
- Preserve current artifact identifiers and provenance metadata during migration.
- Add tests for artifact lookup, archival persistence, and backward compatibility with existing job data.

Acceptance criteria:
- Job metadata can be loaded without deserializing full inline artifact payloads.
- Artifacts can be retrieved by id or kind from the new store.
- Existing jobs remain readable or are migrated safely.
- Storage and artifact tests cover the new retrieval path.

Priority rationale:
A real artifact layer is necessary for enterprise-scale runs and unlocks search, versioning, and compliance-friendly history.

## Task 06: Replace Raw Job JSON With A Structured Operator Summary

Impact: Medium  
Effort: Medium  

Context:
`apps/cli/commands/job.py` currently renders `job show` as `job.model_dump_json(indent=2)`. The repo already stores enough structure to summarize task states, artifacts, providers, and recent outcomes more directly.

Problem:
Operators must parse raw JSON to understand what a job is doing, which tasks are blocked, and what artifacts matter. That is unnecessarily high friction for a system intended to be auditable and operator-friendly.

Goal:
Add a human-readable job summary view that highlights state, task progress, recent events, and important artifacts without forcing users into raw JSON by default.

Relevant areas:
- `apps/cli/commands/job.py`
- `packages/orchestration/artifact_index.py`
- `packages/orchestration/run_log.py`
- `tests/test_cli_main.py`
- `tests/test_cli_execution_loop_closure.py`

Proposed changes:
- Add a structured default renderer for job summaries with task counts, current state, artifact highlights, and recent execution metadata.
- Preserve an explicit JSON mode for scripts and backward-compatible machine use.
- Reuse existing artifact and run-log helpers instead of adding a second summary model.
- Add focused CLI tests for summary rendering and JSON fallback.

Acceptance criteria:
- `job show` produces a concise human-readable summary by default.
- JSON output remains available through an explicit flag or command path.
- The summary includes task state and artifact highlights without leaking redacted content.
- CLI tests cover both summary and JSON modes.

Priority rationale:
This is a fast operator-experience win that makes the product feel much more intentional without large architectural risk.

## Task 07: Extend Event Search By Provider, Outcome, Role, And Scope

Impact: Medium  
Effort: Medium  

Context:
`packages/orchestration/event_ledger.py` already normalizes event type, outcome, scope, timestamp, and metadata. `apps/cli/commands/event.py` currently filters only by event type and since-timestamp.

Problem:
Operators cannot quickly answer practical questions such as which provider failed, which planner events errored, or which repo-scoped operations happened recently without manually parsing raw event output.

Goal:
Make the event CLI usable for real debugging by adding metadata-aware filters and summaries.

Relevant areas:
- `packages/orchestration/event_ledger.py`
- `apps/cli/commands/event.py`
- `packages/orchestration/run_log.py`
- `tests/test_run_log.py`
- `tests/test_cli_main.py`

Proposed changes:
- Extend event selection to filter by provider, role, outcome, and derived scope where available.
- Add a summary mode that counts matching events by type and outcome.
- Keep filtering strictly on safe normalized metadata already allowed by the ledger.
- Add tests covering multiple filter combinations and empty-result handling.

Acceptance criteria:
- Operators can filter events by provider, role, outcome, and scope through the CLI.
- Filtering uses normalized safe metadata and does not expose redacted raw fields.
- Summary output is consistent with filtered event sets.
- New tests verify at least two combined-filter scenarios.

Priority rationale:
The underlying event data already exists, so this is a low-risk way to make Remedy far more diagnosable in real use.

## Task 08: Add Brain Graph Search, Filtering, And Persisted View State

Impact: Medium  
Effort: Medium  

Context:
The project brain already exports rich graphs, but large graphs are difficult to navigate. The current UI shell in `apps/ui/src/RemedyApp.tsx` does not offer durable search, filter, or persisted graph state for practical exploration.

Problem:
As graph size grows, operators cannot isolate failed nodes, patch intents, or memory relationships efficiently. The brain becomes visually rich but operationally cumbersome.

Goal:
Add usable graph navigation features for large-brain workflows: search, semantic filters, and persisted pan/zoom/selection state.

Relevant areas:
- `packages/orchestration/project_brain.py`
- `packages/orchestration/ui_view_model.py`
- `apps/ui/src/RemedyApp.tsx`
- `apps/ui/src/components/graph/`
- `tests/test_project_brain.py`

Proposed changes:
- Add backend or view-model support for filtering by node kind, state, or query text.
- Add a UI search and filter surface that narrows the rendered graph without losing context.
- Persist graph state such as selected node and viewport locally so operators can resume exploration.
- Add tests for filtered graph payloads and UI-state persistence boundaries where feasible.

Acceptance criteria:
- Operators can narrow large graphs by at least node type and text query.
- Graph state persists across refreshes or polling updates without breaking selection.
- Filtered graph output remains structurally valid.
- Existing graph export tests continue to pass.

Priority rationale:
The project brain is already a flagship concept; search and filtering are what make it truly usable at scale.

## Task 09: Implement Live Streaming Progress From Execution To UI

Impact: Medium  
Effort: High  

Context:
`apps/ui/src/RemedyApp.tsx` currently polls every 5 seconds for dashboard data. The contracts layer already defines streaming concepts, and run logs capture detailed execution transitions that could support a more live operator experience.

Problem:
The UI feels delayed and opaque during active execution. Operators do not get near-real-time progress, provider activity, or task transition feedback.

Goal:
Introduce a live progress channel for active runs so the UI can reflect execution changes immediately rather than waiting for polling snapshots.

Relevant areas:
- `apps/ui/src/RemedyApp.tsx`
- `packages/contracts/interfaces.py`
- `packages/orchestration/ui_server.py`
- `packages/orchestration/run_log.py`
- `tests/test_run_log.py`

Proposed changes:
- Add a live event delivery path from the server, such as server-sent events or a websocket endpoint, using safe run-log-derived payloads.
- Update the UI to subscribe to live updates and merge them into dashboard state.
- Preserve polling as a fallback path if the live channel is unavailable.
- Add tests for live payload shape and fallback behavior.

Acceptance criteria:
- Active jobs can push progress updates to the UI without waiting for the next poll cycle.
- Live payloads use the same redaction and safety rules as existing run-log views.
- The UI still functions when the live channel is unavailable.
- Focused tests cover the live transport contract and fallback path.

Priority rationale:
Real-time execution visibility is a visible product upgrade and builds directly on existing execution metadata.

## Task 10: Harden Persistence And Surface Degraded State Explicitly

Impact: High  
Effort: Medium  

Context:
`packages/orchestration/storage.py` persists jobs via direct `write_text()` and silently skips corrupted files in `list_jobs()`. Other orchestration paths also use soft-failure patterns that can hide degraded behavior from operators.

Problem:
A partial write or corrupted file can make jobs disappear or silently degrade behavior. Remedy aims to be auditable, but these paths currently hide important failure states.

Goal:
Make persistence atomic and make degraded or corrupted state visible instead of silent.

Relevant areas:
- `packages/orchestration/storage.py`
- `packages/orchestration/ui_server.py`
- `apps/cli/commands/job.py`
- `tests/test_storage.py`
- `tests/test_imports.py`

Proposed changes:
- Replace direct writes with atomic temp-file-plus-rename persistence.
- Change corrupted-file handling to record or surface skipped files instead of silently dropping them.
- Add a lightweight degraded-state signal in operator-facing surfaces where a fallback path is used.
- Add focused tests for interrupted write safety and corrupted-job visibility.

Acceptance criteria:
- Job saves use an atomic write strategy.
- Corrupted or unreadable job files are surfaced to operators or logs instead of disappearing silently.
- Degraded-state markers are visible where fallback behavior is triggered.
- Storage tests cover both atomic save and corrupted-file reporting paths.

Priority rationale:
This is foundational trust work: Remedy cannot stand out operationally if its own persistence and degradation paths are opaque.
