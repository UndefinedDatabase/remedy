How to make this project outstanding? I want to improve it a lot!
