# Critic

Reject these weak ideas:

- Generic "make the UI prettier" work such as dark mode, cosmetic redesigns, or animation passes.
- Vague "add more logging" without a concrete operator workflow or surface.
- Rebuilding the platform around a new API style or speculative infrastructure with no current code anchor.
- Generic AI claims that are not tied to an implemented module or testable contract.
- Large greenfield features that ignore the existing memory, event, project-brain, or worker scaffolding.

Keep only ideas that are grounded in code already present and that can plausibly differentiate Remedy within the next implementation cycle.
