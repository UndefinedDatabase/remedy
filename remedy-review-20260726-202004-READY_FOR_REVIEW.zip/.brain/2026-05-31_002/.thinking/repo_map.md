# Repo Map

```
remedy/
├── packages/
│   ├── core/          — Pydantic domain models (Job, Task, Artifact, RunState, Budget). Zero external deps.
│   ├── contracts/     — Protocol interfaces (LLMWorker, MemoryGateway, RuntimeProvider, Verifier). Zero deps.
│   ├── orchestration/ — 49 modules: job_runner, task_runner, llm_planner, verifier, project_brain,
│   │                    approval_queue, patch_intent, patch_apply, permissions, run_log, event_ledger,
│   │                    autonomy_loop, agent_loop, context_pack, context_coverage, storage, data_paths,
│   │                    repo_applicator, task_registry, timeline, decision_queue, change_set, ...
│   ├── memory/        — local_gateway.py (JSONL, redaction-safe, conforming to MemoryGateway). Unused by orchestration.
│   ├── artifacts/     — __init__.py only (reserved stub)
│   ├── verification/  — __init__.py only (reserved stub; logic lives in orchestration/verifier.py)
│   ├── runtimes/      — __init__.py only (reserved stub)
│   └── providers/
│       ├── ollama_planner/   — OllamaPlanner.plan() — no timeout, no retry, no stream()
│       ├── ollama_builder/   — OllamaBuilder — same gaps
│       ├── claude_agent/     — stub
│       ├── docker_runtime/   — stub (__init__.py only)
│       └── mempalace/        — stub
├── apps/
│   ├── cli/   — 22 command modules, grouped argparse CLI, command_catalog.py
│   ├── api/   — __init__.py only (empty)
│   ├── ui/    — React 19 + TypeScript + Vite + MUI; 26 components; ELK graph layout
│   └── worker/— __init__.py only (empty)
├── tests/     — 80+ files, 2994+ tests, step-based naming
└── docs/
    ├── architecture.md         — 3000+ line design doc
    └── ui/REMEDY_UI_REBUILD_SPEC.md
```

## Storage layout
```
.data/
  jobs/<job_id>.json          — full Job (non-atomic write)
  workspaces/<job_id>/
    task_output/              — materialized builder outputs
    runs/<run_id>.jsonl       — append-only event log
  memory/                     — LocalMemoryGateway files (unused by orchestration)
  projects/<project_id>.json
```
