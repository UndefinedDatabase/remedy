# Analysis

## What the project is
Remedy is a modular orchestration kernel for artifact-driven AI agent workflows.
Core loop: Job → (LLM) Plan → Tasks → (LLM) Builder Outputs → Verification → Repo Application.
The architecture is clean: Core (models) → Contracts (protocols) → Orchestration (logic) → Providers (LLM/runtime adapters) → Apps (CLI/UI).

## What is mature
- 49-module orchestration layer with clean separation
- Append-only run log with 200+ event types
- 20-node-type project brain graph
- Deterministic verifier with profiles
- Explicit permissions model (4 capabilities)
- Redaction policy enforced across all layers
- 80+ test files, 2994+ tests
- CLI with 22 command groups

## Key gaps found (with evidence)

### 1. Data integrity (storage.py:45)
`path.write_text()` is not POSIX-atomic. Concurrent CLI calls or a kill during write
leaves a zero-byte file. `list_jobs()` silently drops it. Silent data loss.

### 2. LLM reliability (ollama_planner/provider.py, ollama_builder/provider.py)
`client.chat()` — no timeout argument, no retry loop. Ollama under GPU load or model loading
causes indefinite hang. No way to interrupt cleanly. Job stuck in RUNNING state.

### 3. No REST API (apps/api/)
Entire job management is CLI-only. UI uses mock data. External CI/scripts cannot integrate.
The orchestration layer is importable — only HTTP wiring is missing.

### 4. Memory gateway unused (memory/local_gateway.py)
Fully implemented, redaction-safe, tested. Neither `plan_job_with_llm` nor `run_next_task`
imports it. Every planning call starts from zero context. Agent repeats the same analysis.

### 5. Silent exception swallowing (task_runner.py, autonomy_loop.py, ui_server.py)
9 `except Exception: pass` blocks in production hot paths. Builder failures vanish.
Task stays RUNNING forever. User sees no error.

### 6. stream() is dead code (contracts/interfaces.py:30)
`LLMWorker.stream()` defined in the protocol, never implemented by either Ollama provider.
Long LLM calls (30-120s) give the user a frozen black box.

### 7. Context pack has no eviction (context_pack.py:80-160)
Sets `truncated=True` but returns full content anyway. Large jobs silently overflow model
context windows. The model truncates at input — no error, just wrong answers.

### 8. UI has no fault tolerance (RemedyApp.tsx, remedyApi.ts)
Any render error → blank screen. API error → polling hammers the server every 5s forever.
No error boundary, no backoff, no user-visible error state.

### 9. Docker runtime is a stub (providers/docker_runtime/)
Tasks run in the caller's process. Autonomy level 3+ executes untrusted task commands
with no sandboxing. The RuntimeProvider protocol exists; no implementation.

### 10. Brain graph has no filter or search (project_brain.py)
Full graph returned on every poll. 100-task jobs → 500+ nodes. ELK re-layout on every
5s poll. Unusable at scale. No server-side query capability.

## What was not a gap (verified clean)
- Exception handling in CLI entry points (correct argparse error handling)
- All `pass` statements in except blocks in non-critical paths (all have rationale comments)
- Security: no shell=True, no eval/exec, safe executables list, path traversal checks
- Test coverage: all active code paths have tests (gaps are only in empty stubs)
