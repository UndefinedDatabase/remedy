# Relevant Files

Files read and confirmed during analysis:

## Storage & Persistence
- `packages/orchestration/storage.py` — `save_job()` uses `path.write_text()` (non-atomic, line 45); `list_jobs()` silently skips corrupt files (line 71)
- `packages/orchestration/data_paths.py` — resolves `REMEDY_DATA_DIR`

## LLM Providers
- `packages/providers/ollama_planner/provider.py` — `OllamaPlanner.plan()` calls `client.chat()` with no timeout (~line 225); no `stream()` implementation
- `packages/providers/ollama_builder/provider.py` — same gaps
- `packages/contracts/interfaces.py` — `LLMWorker.stream()` defined at line ~30; `MemoryGateway` protocol at line ~32; `RuntimeProvider` at line ~50

## Memory
- `packages/memory/local_gateway.py` — fully implemented JSONL gateway with redaction; never called by orchestration
- `packages/memory/models.py` — MemoryEntry schema

## Orchestration hot paths
- `packages/orchestration/task_runner.py` — `except Exception: pass` in builder call site
- `packages/orchestration/autonomy_loop.py` — `except Exception: pass` in loop body
- `packages/orchestration/context_pack.py` — `build_context_pack()` marks `truncated=True` but does not evict sections
- `packages/orchestration/project_brain.py` — returns full graph, no filter/search params
- `packages/orchestration/event_schemas.py` — event type definitions
- `packages/orchestration/run_log.py` — append-only JSONL event log

## UI
- `apps/ui/src/RemedyApp.tsx` — polls every 5s; no error boundary; no backoff
- `apps/ui/src/api/remedyApi.ts` — `fetchJson()` throws on non-OK; no retry
- `apps/ui/src/components/shell/RemedyShell.tsx`
- `apps/ui/src/components/panels/RightLivePanel.tsx`
- `apps/ui/src/components/graph/BrainGraphStage.tsx`
- `apps/ui/src/components/layers/LayerSwitcher.tsx`
- `apps/ui/package.json` — React 19, Vite 6, MUI 6.4, elkjs

## Empty stubs
- `apps/api/__init__.py` — no code
- `apps/worker/__init__.py` — no code
- `packages/providers/docker_runtime/__init__.py` — no code

## Configuration
- `pyproject.toml` — `pydantic>=2.0` only hard dep; `ollama>=0.4` optional; hatchling build
