# Sources

- packages/memory/local_gateway.py: implemented JSONL memory storage, recall, upsert, and approval-aware helpers
- packages/orchestration/llm_planner.py: planning flow with no memory recall hook
- packages/orchestration/context_pack.py: memory is summarized passively, not used to steer planning or execution
- packages/orchestration/event_ledger.py: normalized redacted event surface with summary and timeline builders
- apps/cli/commands/event.py: event filtering limited to type and since
- packages/orchestration/project_brain_aggregate.py: cross-job aggregate graph already implemented
- packages/orchestration/worker_adapters.py: provider-neutral worker specs marked future and not integrated
- packages/orchestration/storage.py: direct write_text persistence and silent corrupted-file skip in list_jobs
- apps/cli/commands/job.py: job show prints raw model_dump_json
- apps/ui/src/RemedyApp.tsx: five-second polling loop and brittle top-level error path
- packages/artifacts/__init__.py: reserved namespace signaling missing artifact persistence layer
- tests/test_storage.py, tests/test_project_brain.py, tests/test_run_log.py: narrow verification anchors for the proposed work items
