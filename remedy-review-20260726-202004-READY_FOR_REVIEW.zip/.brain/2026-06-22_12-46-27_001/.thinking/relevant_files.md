# Relevant Files

## Core models
- packages/core/models.py — Job, Task, Artifact, Budget, RunState, ArtifactKind

## Fulfillment spine (current target)
- packages/orchestration/job_fulfillment.py — v0 fixture-only spine

## Planning
- packages/orchestration/job_runner.py — deterministic plan_job
- packages/orchestration/llm_planner.py — LLM planner with provider injection
- packages/orchestration/planner_models.py — PlannerOutput, ProposedTask

## Builder / Worker
- packages/orchestration/builder_models.py — TaskExecutionContext, BuilderOutput
- packages/orchestration/task_runner.py — run_next_task with injected builder
- packages/orchestration/worker_recommend.py — worker scoring
- packages/orchestration/builder_routing.py — expensive builder routing tiers

## Context / Token
- packages/orchestration/context_pack.py — budget-aware context generation
- packages/orchestration/token_policy.py — zero/local/expensive routing
- packages/orchestration/token_economy.py — token economy reporting
- packages/orchestration/context_optimizer.py — context budget optimizer

## Review / Repair
- packages/orchestration/reviewer.py — reviewer recommendation loop (inert)
- packages/orchestration/repair_loop.py — v0 repair (fixture)
- packages/orchestration/repair_loop_v2.py — token-aware repair
- packages/orchestration/repair_context.py — safe failure summaries

## Apply / Test / Proof
- packages/orchestration/source_apply.py — safe patch application
- packages/orchestration/real_test_execution.py — bounded test execution
- packages/orchestration/proof_chain.py — full proof chain

## Governance
- packages/orchestration/agent_loop.py — execution loop
- packages/orchestration/autonomy_loop.py — contract-gated autonomy
- packages/orchestration/approval_queue.py — approval state management

## Docs
- docs/architecture.md — system architecture
- docs/core-product-spine-v0.md — product spine definition
- docs/first-fulfilled-job-demo-v0.md — fulfilled job demo spec
