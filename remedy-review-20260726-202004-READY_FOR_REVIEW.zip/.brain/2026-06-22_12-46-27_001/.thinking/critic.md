# Critic Review

## Removed ideas (too generic / no evidence)
- "Add logging" — already has event ledger + timeline
- "Add config system" — remedy.toml already exists
- "Add error handling" — already has structured error flows
- "Add documentation" — 70+ docs already exist
- "Add CI/CD" — out of scope for orchestration kernel

## Concerns with proposed tasks

### Per-task context selection (Task 02)
Risk: over-engineering. The current job-level context pack may be sufficient
for small jobs. Per-task selection adds complexity. BUT: the goal explicitly
says "pass only the smallest task-relevant context" — this is a hard requirement.
Decision: keep, but make it incremental (extend context_pack, don't replace).

### Isolated workspace (Task 04)
Risk: significant infrastructure. Git worktree management, tmpdir lifecycle,
copy strategies. BUT: the goal says "run apply/test/proof gates in an isolated
workspace before touching the real repo" — non-negotiable.
Decision: keep. Start with tmpdir copy (simpler than worktree).

### Cost-aware routing (Task 03)
Risk: premature optimization. Token costs are theoretical until real providers run.
BUT: the routing decision + reasoning must be RECORDED even if fixture.
Decision: keep, but frame as "decision recording + policy" not "actual cost optimization".

### Job-level goal review (Task 07)
Risk: requires LLM to evaluate goal satisfaction. In fixture mode, this is meaningless.
Decision: keep as contract extension. LLM-backed goal review is a future provider.
For now, add the contract field + reviewer interface, wire LLM later.

## Ordering validation
1. Worker prompt builder — foundational, everything depends on bounded prompts
2. Per-task context selection — needed by prompt builder
3. Cost-aware task routing — needed by prompt builder to pick model
4. Isolated workspace — safety gate, independent of 1-3
5. Worker/reviewer loop engine — consumes 1-3, needs 4 for safety
6. Rich job report — consumes outputs of all above
7. Goal-level final review — extends contract, needs 6
8. Next-task ranking — post-completion, consumes 6
9. Per-task cost accounting — cross-cutting, can be added incrementally
10. Local LLM execution path — wires existing providers into routing

Order is correct. Dependencies flow downward.
