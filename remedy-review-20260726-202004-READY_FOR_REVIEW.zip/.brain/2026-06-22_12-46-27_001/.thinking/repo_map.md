# Repo Map

## Structure
```
apps/cli/          — CLI commands (do_cmd, brain, feature_cmd, etc.)
apps/ui/           — Vite/React dashboard
apps/api/          — Reserved API layer
apps/worker/       — Reserved worker adapter

packages/core/     — models.py (Job, Task, Artifact, Budget, RunState)
packages/contracts/— Reserved interfaces
packages/orchestration/ — ~100 modules: the engine
packages/providers/ — ollama_planner, ollama_builder, claude_agent, docker_runtime, mempalace
packages/runtimes/  — Runtime abstraction
packages/memory/    — Memory gateway layer
packages/verification/ — Reserved (active verifier in orchestration/)
packages/artifacts/ — Reserved

docs/              — ~70 design/user-guide docs
tests/             — pytest suite (cli, orchestration, regression, ui_contracts, storage)
scripts/           — smoke runners, agent tooling doctor
```

## Key orchestration modules (relevant to goal)
- job_runner.py — deterministic plan_job (fixture skeleton)
- llm_planner.py — LLM-backed planning (provider-injected)
- task_runner.py — single-task execution with builder callable
- builder_models.py — TaskExecutionContext, BuilderOutput
- builder_routing.py — expensive builder routing policy (local→external tiers)
- context_pack.py — token-budget-aware context generator (compact/caveman)
- token_policy.py — deterministic routing policy (zero/local/expensive tiers)
- worker_recommend.py — local-first worker recommendation
- reviewer.py — post-task reviewer (inert fixture)
- repair_loop.py — v0 structured repair (no real provider)
- repair_loop_v2.py — token-aware repair loop (metadata/eval layer)
- proof_chain.py — Goal→Job→Task→Artifact→Apply→Test→Proof chain
- job_fulfillment.py — v0 spine (fixture-demo only)
- agent_loop.py — plan→build→approve→test→repeat loop
- autonomy_loop.py — contract-gated local autonomy
- source_apply.py — safe structured patch application
- real_test_execution.py — bounded test execution + snapshot/rollback
- event_ledger.py — safe normalized event query
- event_schemas.py — per-event metadata schemas
