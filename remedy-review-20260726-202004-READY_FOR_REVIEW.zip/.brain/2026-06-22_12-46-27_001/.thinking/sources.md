# Sources

## Files read in full
- packages/core/models.py (140 lines)
- packages/orchestration/job_runner.py (95 lines)
- packages/orchestration/planner_models.py (34 lines)
- packages/orchestration/worker_recommend.py (171 lines)
- packages/orchestration/verifier_profiles.py (119 lines)
- packages/orchestration/repair_context.py (91 lines)
- packages/verification/__init__.py (17 lines)
- packages/orchestration/event_ledger.py (221 lines)
- packages/orchestration/event_schemas.py (93 lines)
- packages/orchestration/job_fulfillment.py (864 lines)

## Files read partially (first 60-80 lines)
- packages/orchestration/agent_loop.py
- packages/orchestration/builder_routing.py
- packages/orchestration/context_pack.py
- packages/orchestration/token_policy.py
- packages/orchestration/reviewer.py
- packages/orchestration/repair_loop.py
- packages/orchestration/proof_chain.py
- packages/orchestration/task_runner.py
- packages/orchestration/do_run.py
- packages/orchestration/autonomy_loop.py
- packages/orchestration/builder_models.py
- packages/orchestration/llm_planner.py
- packages/orchestration/real_test_execution.py
- packages/orchestration/source_apply.py
- packages/orchestration/repair_loop_v2.py
- docs/architecture.md
- docs/core-product-spine-v0.md
- docs/first-fulfilled-job-demo-v0.md

## Grep searches
- fulfill/fulfillment across orchestration
- Report/report classes across orchestration
- workspace isolation patterns across orchestration
