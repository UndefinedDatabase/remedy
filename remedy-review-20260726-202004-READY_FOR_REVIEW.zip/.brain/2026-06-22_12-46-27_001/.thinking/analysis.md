# Analysis: AAA Job Fulfillment Pipeline

## Current State

Remedy has a solid foundation with clean separation (core/orchestration/providers).
The v0 fulfillment spine (`job_fulfillment.py`) proves the lifecycle works end-to-end
in fixture mode: plan→work→review→repair→apply→test→proof→complete→suggest.

**What exists and works:**
- Job/Task/Artifact data model (Pydantic, clean)
- Deterministic + LLM planning (provider-injected)
- Builder execution context (TaskExecutionContext)
- Token policy with zero/local/expensive tiers
- Context pack with budget-aware generation
- Builder routing with anti-loop governor
- Worker recommendation scoring
- Patch apply with snapshot/rollback
- Bounded test execution
- Proof chain (Goal→Apply→Test→Proof)
- Event ledger with redaction
- Fulfillment contract checking

**What's missing for AAA:**

### GAP 1: No per-task worker prompt builder
TaskExecutionContext carries context, but there's no module that GENERATES bounded
worker prompts — task-specific, minimal, with explicit constraints. The builder
callable receives context but the prompt construction is left to the provider.

### GAP 2: No per-task context selection/compression
context_pack.py builds ONE pack per job. For AAA, each task needs its own minimal
context slice — only files/artifacts/history relevant to THAT task.

### GAP 3: No real cost-aware model routing per task
token_policy.py defines tiers statically. builder_routing.py picks a tier.
But there's no per-task decision that says "this task is low-risk docs → use local
LLM" vs "this task is architecture review → use frontier model".

### GAP 4: No isolated workspace for apply+test before real repo
source_apply.py writes to real repo (with snapshot/rollback). AAA requires an
isolated workspace (git worktree, tmpdir copy) where apply+test runs BEFORE
touching the real repo.

### GAP 5: No structured worker/reviewer loop engine
The v0 spine hardcodes fixture review. There's no general loop engine that:
  1. Runs worker → collects untrusted artifact
  2. Runs reviewer prompt → produces findings
  3. Converts findings → repair tasks
  4. Repeats until all pass or max rounds

### GAP 6: No rich human-readable job report
summarize_job_fulfillment() is a text summary. AAA requires a full report showing
every task, selected context, worker route, token/cost reasoning, review findings,
repair actions, test results, proof status, and decisions.

### GAP 7: No job-level final review against original goal
JobFulfillmentContract checks structural gates (tasks done, tests pass, proof ok).
It does NOT verify that the output actually satisfies the original human goal.

### GAP 8: No ranked next-task proposals with approve/reject/defer/backlog
proposed_tasks.py exists with basic CRUD. But there's no ranking algorithm,
no integration with fulfillment report, and no backlog concept.

### GAP 9: No cost/token accounting per task
Token estimates exist (context_pack, token_economy) but there's no per-task
accounting of actual tokens used, cost incurred, model chosen, and reasoning.

### GAP 10: No local LLM cheap-route execution path
ollama_planner/builder providers exist but are disconnected from the routing
decision. There's no automatic "route this task to local Ollama because it's
low-risk" path in the fulfillment spine.
