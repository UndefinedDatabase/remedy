# Tasks — AAA Job Fulfillment Pipeline

## Task 01: Bounded Worker Prompt Builder

Impact: High
Effort: Medium

Context:
`packages/orchestration/builder_models.py` defines `TaskExecutionContext` — the structured input every builder receives. `task_runner.py:run_next_task()` builds this context from job/task state and passes it to the injected builder callable. Currently the builder callable receives raw context and constructs its own prompt internally (provider-side). There is no orchestration-owned module that generates a bounded, task-specific prompt with explicit constraints, token budget, and scope boundaries.

Problem:
The prompt given to a worker is uncontrolled. Each provider decides what to include, how much context to pass, and what constraints to enforce. This means: (a) expensive models receive unnecessary context, (b) prompts lack explicit scope boundaries that prevent drift, (c) there's no way to record "what prompt was actually sent" for audit/reporting, (d) cheap local models receive the same context as expensive ones.

Goal:
Create `packages/orchestration/worker_prompt_builder.py` that takes a `TaskExecutionContext` + routing decision + per-task context slice and produces a `WorkerPrompt` — a structured, auditable prompt object with: task instruction, selected context sections, explicit constraints, token budget, expected output format, and scope boundaries. The prompt is the contract between orchestration and worker.

Relevant areas:
- packages/orchestration/builder_models.py (TaskExecutionContext, BuilderOutput)
- packages/orchestration/task_runner.py (run_next_task — call site)
- packages/orchestration/context_pack.py (context generation — input)
- packages/orchestration/token_policy.py (budget constraints — input)

Proposed changes:
- Create `worker_prompt_builder.py` with `WorkerPrompt` dataclass and `build_worker_prompt()` function
- `WorkerPrompt` fields: task_instruction, context_sections (list), constraints (list), token_budget, expected_output_format, scope_boundary, model_tier, prompt_hash (for audit)
- `build_worker_prompt(task_ctx, context_slice, route_decision)` produces the prompt
- Add `export_worker_prompt_json()` for audit trail
- Wire into `task_runner.py` so `run_next_task()` builds a `WorkerPrompt` before calling builder
- Builder callable signature extends to accept `WorkerPrompt` (backward-compatible via optional param)

Acceptance criteria:
- `WorkerPrompt` is a frozen dataclass with all required fields
- `build_worker_prompt()` produces deterministic output for fixture inputs
- `export_worker_prompt_json()` produces safe JSON (no raw content/secrets)
- Prompt hash is deterministic for same inputs
- Unit test covers: fixture prompt generation, JSON export, hash stability
- No provider imports, no network, no subprocess

Priority rationale:
Foundation for everything else. Per-task context selection (Task 02), routing (Task 03), the worker/reviewer loop (Task 05), and the audit report (Task 06) all depend on having a structured, bounded prompt object.

---

## Task 02: Per-Task Context Selection and Compression

Impact: High
Effort: Medium

Context:
`packages/orchestration/context_pack.py` builds ONE `ContextPack` per job with sections like job_summary, task_list, event_digest. Token estimation uses `ceil(chars/4)`. Modes are `compact` and `caveman`. The pack is job-scoped — every task gets the same context regardless of what it actually needs. `token_policy.py` defines budget categories but doesn't drive per-task context selection.

Problem:
A docs_update task does not need event history or prior task summaries. An architecture review task does not need unrelated file contents. Passing full job context to every task wastes tokens (especially on expensive models) and increases prompt noise, reducing output quality. The goal explicitly requires "pass only the smallest task-relevant context needed to complete that task."

Goal:
Extend `context_pack.py` (or create a new `task_context_selector.py`) to produce per-task context slices. Each slice contains only the sections relevant to that specific task, compressed to fit the task's token budget. The selector uses task_type, task inputs, and the routing decision to determine what context to include.

Relevant areas:
- packages/orchestration/context_pack.py (current job-level context generation)
- packages/orchestration/token_policy.py (budget categories)
- packages/orchestration/builder_models.py (TaskExecutionContext — consumes context)
- packages/orchestration/task_registry.py (task type specs — relevance hints)
- packages/orchestration/context_optimizer.py (existing budget optimizer)

Proposed changes:
- Create `task_context_selector.py` with `TaskContextSlice` dataclass and `select_task_context()` function
- `TaskContextSlice` fields: task_id, included_sections (list[PackSection]), excluded_sections (list[str]), total_tokens, budget, compression_applied, relevance_scores
- `select_task_context(task, job, events, budget, route_tier)` produces a `TaskContextSlice`
- Relevance scoring: task_type → required sections mapping (e.g., "docs_update" needs file list + task description only; "architecture_review" needs full artifact history)
- Compression: if selected sections exceed budget, compress lowest-priority sections first (caveman mode), then drop
- Add `export_task_context_slice_json()` for audit trail
- Wire into `worker_prompt_builder.py` (Task 01) as input

Acceptance criteria:
- `select_task_context()` returns different slices for different task types given same job
- A "docs_update" task gets strictly fewer sections than an "architecture_review" task
- Total tokens in slice respects budget (never exceeds)
- Compression kicks in when raw sections exceed budget
- `export_task_context_slice_json()` shows included/excluded with reasoning
- Unit test: fixture job with 3 task types → 3 different slices with different section counts

Priority rationale:
Second foundation piece. Worker prompts (Task 01) need context slices. Cost-aware routing (Task 03) needs to know context size before picking a model. The audit report (Task 06) needs to show "what context was selected and why."

---

## Task 03: Cost-Aware Per-Task Model Routing

Impact: High
Effort: Medium

Context:
`packages/orchestration/builder_routing.py` implements expensive builder routing with tiers: `deterministic_only`, `local_advisor`, `local_candidate_generator`, `external_candidate_generator`, `human_review_required`. `token_policy.py` classifies steps as zero_token, local_first, or expensive_model. `worker_recommend.py` scores workers (local > external, available > future). These three modules operate independently and produce job-level decisions, not per-task decisions.

Problem:
There's no per-task routing decision that combines: (a) task risk/complexity, (b) context size, (c) available models + cost, (d) token budget, into a single "use this model for this task because..." decision. The goal requires: "cheap, repetitive, low-risk, or narrow tasks should prefer local LLMs; expensive frontier models reserved for high-risk, ambiguous, architecture-heavy, or final-review work."

Goal:
Create `packages/orchestration/task_route_decision.py` that produces a per-task `TaskRouteDecision` combining task characteristics, context size, and available providers into a model/route choice with cost reasoning.

Relevant areas:
- packages/orchestration/builder_routing.py (tier vocabulary + routing policy)
- packages/orchestration/token_policy.py (zero/local/expensive classification)
- packages/orchestration/worker_recommend.py (worker scoring)
- packages/orchestration/task_registry.py (task type metadata)
- packages/orchestration/model_route_tournament.py (tournament harness — future integration)

Proposed changes:
- Create `task_route_decision.py` with `TaskRouteDecision` frozen dataclass
- Fields: task_id, task_type, risk_level, complexity_signal, context_tokens, selected_tier, selected_provider, cost_estimate_cents, reasoning (list[str]), alternatives (list), override_reason
- `decide_task_route(task, job, context_slice, available_providers)` → `TaskRouteDecision`
- Decision logic: task_type risk mapping (docs_update=low, architecture_review=high) + context_tokens threshold + provider availability → tier selection
- Low-risk + small context → local_first; high-risk + large context → expensive; ambiguous → human_review_required
- `export_task_route_decision_json()` for audit
- Integrate with `worker_prompt_builder.py` (Task 01) to set model_tier on WorkerPrompt

Acceptance criteria:
- "docs_update" task routes to local_first tier
- "architecture_review" task routes to expensive_model tier
- Decision includes human-readable reasoning list
- Cost estimate is 0 for local models, >0 for external
- `export_task_route_decision_json()` produces complete audit record
- Unit test: 3 task types → 3 different route decisions with different tiers

Priority rationale:
Third foundation piece. The worker prompt (Task 01) needs to know which model tier. The audit report (Task 06) needs per-task cost reasoning. The fulfillment loop (Task 05) needs routing to dispatch to correct provider.

---

## Task 04: Isolated Workspace for Apply + Test Gates

Impact: High
Effort: High

Context:
`packages/orchestration/source_apply.py` applies patches directly to the real repo with snapshot/rollback safety. `real_test_execution.py` runs tests in the real repo. `repository_snapshot.py` provides snapshot creation + revert. The safety model is: snapshot → apply → test → revert-if-fail. But the apply happens in the real repo — a crash mid-apply leaves the repo dirty.

Problem:
The goal requires "run apply/test/proof gates in an isolated workspace before touching the real repo." Current architecture applies directly to the real repo. A crash, power failure, or unexpected test side-effect can leave the real repo in a broken state even with snapshot/rollback. An isolated workspace (tmpdir copy or git worktree) eliminates this risk entirely.

Goal:
Create `packages/orchestration/isolated_workspace.py` that provides a temporary copy of the repo where apply+test can run safely. Only after all gates pass does the change get promoted to the real repo.

Relevant areas:
- packages/orchestration/source_apply.py (apply_structured_patch — current apply path)
- packages/orchestration/real_test_execution.py (execute_test_run — current test path)
- packages/orchestration/repository_snapshot.py (snapshot/revert — safety layer)
- packages/orchestration/job_fulfillment.py (fulfillment spine — integration point)
- packages/runtimes/__init__.py (runtime abstraction)

Proposed changes:
- Create `isolated_workspace.py` with `IsolatedWorkspace` context manager
- `IsolatedWorkspace(repo_root, job_id)` creates a tmpdir shallow copy (symlinks for .git, real copies for working tree — fast + safe)
- Methods: `apply(patch)` → apply in isolated dir; `run_tests(command)` → run in isolated dir; `promote()` → copy changed files to real repo; `discard()` → delete tmpdir
- `promote()` only succeeds if apply+test+proof all passed
- Add `IsolatedApplyResult` with workspace_path, apply_result, test_result, promoted flag
- Wire into `job_fulfillment.py:run_job_fulfill()` — apply+test happens in isolated workspace, promote on success
- Existing `source_apply.py` used inside the isolated workspace (reuse, not replace)

Acceptance criteria:
- Apply in isolated workspace does NOT modify real repo
- Test runs in isolated workspace with correct PYTHONPATH / working directory
- `promote()` copies only changed files to real repo
- `discard()` cleans up completely (no leaked tmpdirs)
- Crash during apply leaves real repo untouched
- Unit test: apply in isolated → verify real repo unchanged → promote → verify real repo updated

Priority rationale:
Safety gate. Without isolation, apply+test in the real repo is a risk for production use. This is independent of Tasks 01-03 and can be built in parallel. The fulfillment loop (Task 05) needs this before it can safely run apply+test cycles.

---

## Task 05: Worker/Reviewer Loop Engine

Impact: High
Effort: High

Context:
`packages/orchestration/job_fulfillment.py` hardcodes a fixture review flow: fixture_review() returns pass or one_finding, fixture_repair_output() produces deterministic repair. `reviewer.py` defines ReviewerRecommendation and run_reviewer() but uses an inert fixture reviewer. `repair_loop.py` and `repair_loop_v2.py` handle failure→fix→retest but are disconnected from the fulfillment spine. The `agent_loop.py` drives plan→build→approve→test cycles but doesn't integrate structured review or repair.

Problem:
There's no general-purpose loop engine that: (1) collects worker output as untrusted artifact, (2) runs a reviewer prompt against the artifact, (3) converts review findings into repair tasks, (4) dispatches repair tasks to workers, (5) repeats until all tasks pass or max rounds reached. The v0 spine hardcodes this for fixtures. AAA requires a pluggable, provider-injected loop.

Goal:
Create `packages/orchestration/fulfillment_loop.py` — the general-purpose worker/reviewer loop engine that replaces the hardcoded fixture flow in `job_fulfillment.py`.

Relevant areas:
- packages/orchestration/job_fulfillment.py (current fixture flow — to be replaced)
- packages/orchestration/reviewer.py (reviewer interface — to be consumed)
- packages/orchestration/repair_loop.py (repair building blocks — to be reused)
- packages/orchestration/repair_loop_v2.py (token-aware repair — to be integrated)
- packages/orchestration/task_runner.py (task execution — to be consumed)
- packages/orchestration/agent_loop.py (existing loop — design reference)

Proposed changes:
- Create `fulfillment_loop.py` with `FulfillmentLoop` class
- Constructor: `FulfillmentLoop(job, contract, worker_fn, reviewer_fn, workspace, route_fn)`
- `run()` method drives the loop: for each pending task → build prompt (Task 01) → select context (Task 02) → route (Task 03) → call worker → collect artifact (untrusted) → call reviewer → if findings: create repair tasks, loop → if pass: proceed to apply
- Loop bounded by contract.max_review_rounds and contract.max_repair_rounds
- Each iteration produces a `LoopIteration` record (task_id, worker_prompt_hash, context_slice_summary, route_decision, artifact_id, review_verdict, findings, repair_task_ids)
- `FulfillmentLoopResult` collects all iterations + final status
- Replace hardcoded fixture flow in `run_job_fulfill()` with `FulfillmentLoop(...)`
- Fixture mode: pass fixture_worker_output and fixture_review as callables

Acceptance criteria:
- FulfillmentLoop produces same result as current fixture flow for fixture inputs
- Loop stops at max_review_rounds (does not infinite-loop)
- Each iteration is recorded with full audit trail
- Worker callable and reviewer callable are pluggable (injected)
- Review findings correctly convert to repair tasks via `finding_to_repair_task()`
- Unit test: fixture loop with one_finding_then_pass → 2 review rounds → completed

Priority rationale:
Core engine. This is what makes the fulfillment spine real instead of fixture-only. Depends on Tasks 01-03 for prompt/context/routing. Depends on Task 04 for safe apply+test. Everything downstream (report, goal review, next tasks) consumes this loop's output.

---

## Task 06: Human-Readable Job Fulfillment Report

Impact: High
Effort: Medium

Context:
`summarize_job_fulfillment()` in `job_fulfillment.py` produces a 15-line text summary. `export_job_fulfillment_json()` exports structured JSON. Various other modules have their own report types (BundleSafetyReport, ProviderTrustReport, EvalReport). There is no unified, rich, human-readable report that shows the complete fulfillment story.

Problem:
The goal requires "produce a human-readable report showing every task, selected context, worker route, token/cost reasoning, review, repair, test, proof, and decision, followed by ranked recommended next tasks." Current reporting is fragmented across modules and lacks the per-task detail needed for AAA.

Goal:
Create `packages/orchestration/fulfillment_report.py` that produces a comprehensive, structured, human-readable report from a `FulfillmentLoopResult` (Task 05) + proof chain + next suggestions.

Relevant areas:
- packages/orchestration/job_fulfillment.py (current summary/export — to be extended)
- packages/orchestration/proof_chain.py (proof chain — report section)
- packages/orchestration/proposed_tasks.py (next suggestions — report section)
- packages/orchestration/event_ledger.py (event timeline — report section)
- packages/orchestration/token_economy.py (token accounting — report section)

Proposed changes:
- Create `fulfillment_report.py` with `FulfillmentReport` dataclass
- Fields: job_summary, task_reports (list[TaskReport]), total_tokens, total_cost_cents, proof_summary, final_review_summary, next_suggestions (ranked), decision_log
- `TaskReport` fields: task_id, description, context_sections_included, context_sections_excluded, context_tokens, route_decision (tier + reasoning), worker_prompt_hash, artifact_summary, review_verdict, review_findings, repair_actions, test_result, proof_status, cost_cents
- `build_fulfillment_report(loop_result, proof_chain, suggestions)` → `FulfillmentReport`
- `render_fulfillment_report(report)` → human-readable markdown string
- `export_fulfillment_report_json(report)` → safe JSON dict
- Wire into `run_job_fulfill()` — produce report after completion

Acceptance criteria:
- Report contains one TaskReport per task with all required fields populated
- Markdown rendering is human-readable without tooling
- JSON export contains no raw content/secrets/absolute paths
- Token/cost totals are sum of per-task values
- Next suggestions are ranked by priority
- Unit test: fixture fulfillment → report with 2+ task reports, all fields populated

Priority rationale:
Primary user-facing output. The report is what makes the fulfillment pipeline transparent and auditable. Without it, the pipeline is a black box. Depends on Tasks 01-05 for the data it reports on.

---

## Task 07: Job-Level Goal Review Contract

Impact: Medium
Effort: Medium

Context:
`JobFulfillmentContract` in `job_fulfillment.py` checks structural gates: all tasks completed, review pass, apply exists, test passed, proof verified. It does NOT check whether the output actually satisfies the original human goal. The `proof_chain.py` verifies evidence linkage but not semantic goal satisfaction.

Problem:
A job can pass all structural gates (tasks done, tests pass) but produce output that doesn't match the human's original goal. The goal requires "perform a final job-level review against the job contract." This means semantic review: does the combined output of all tasks satisfy the user_prompt?

Goal:
Extend `JobFulfillmentContract` with a goal-level review gate that evaluates combined task outputs against the original user_prompt. In fixture mode, use a deterministic check. In real mode, use an injected reviewer callable (future: LLM-backed).

Relevant areas:
- packages/orchestration/job_fulfillment.py (JobFulfillmentContract.check())
- packages/orchestration/reviewer.py (reviewer callable pattern)
- packages/orchestration/proof_chain.py (proof chain — evidence for goal review)
- packages/core/models.py (Job.user_prompt — the original goal)

Proposed changes:
- Add `GoalReviewResult` dataclass: verdict (pass/fail/partial), coverage_score (0-100), missing_aspects (list[str]), reasoning (str), reviewer_id (str)
- Add `goal_reviewer_fn` parameter to `JobFulfillmentContract` (optional callable)
- Add `requires_goal_review: bool = False` to contract (opt-in, default off for backward compat)
- `_check_goal_review(job, artifacts, reviewer_fn)` → `GoalReviewResult`
- Fixture goal reviewer: checks that artifact summaries contain keywords from user_prompt
- Contract.check() includes goal review result when enabled
- Report (Task 06) includes goal review section

Acceptance criteria:
- Contract with `requires_goal_review=False` behaves identically to current
- Contract with `requires_goal_review=True` calls goal reviewer
- Fixture goal reviewer produces deterministic result
- Goal reviewer callable is injectable (same pattern as builder/reviewer)
- GoalReviewResult appears in fulfillment report
- Unit test: fixture goal review with matching/non-matching goal → pass/fail

Priority rationale:
Quality gate. Structural gates are necessary but not sufficient. Goal review ensures the pipeline actually delivers what the human asked for. Depends on Tasks 05-06 for the artifacts and report to review.

---

## Task 08: Ranked Next-Task Proposals with User Actions

Impact: Medium
Effort: Low

Context:
`packages/orchestration/proposed_tasks.py` has `ProposedTask` model with add/list/approve/reject CRUD. `_generate_next_suggestions()` in `job_fulfillment.py` creates 3 hardcoded suggestions after completion. There's no ranking algorithm, no "defer" or "backlog" action, and no integration with the fulfillment report.

Problem:
The goal requires "ranked recommended next tasks that the user can approve, reject, defer, or send to backlog." Current suggestions are unranked hardcoded fixtures with only approve/reject (no defer/backlog).

Goal:
Extend `proposed_tasks.py` with ranking, defer/backlog actions, and smart suggestion generation based on fulfillment results.

Relevant areas:
- packages/orchestration/proposed_tasks.py (current CRUD — to be extended)
- packages/orchestration/job_fulfillment.py (_generate_next_suggestions — to be replaced)
- packages/orchestration/fulfillment_report.py (Task 06 — integration point)
- packages/orchestration/reviewer.py (ReviewerRecommendation — input source)

Proposed changes:
- Add `status` values to ProposedTask: "deferred", "backlog" (in addition to existing pending/accepted/rejected)
- Add `rank: int` field to ProposedTask (lower = higher priority)
- Add `defer_proposed_task(job_id, task_id)` and `backlog_proposed_task(job_id, task_id)` functions
- Create `rank_proposed_tasks(tasks, fulfillment_result)` that scores tasks based on: review findings severity, coverage gaps, cost efficiency, risk
- Replace `_generate_next_suggestions()` with `generate_ranked_suggestions(job_id, fulfillment_result, data_dir)` that analyzes review findings, unused context, and proof gaps to propose specific follow-ups
- Add `list_proposed_tasks(job_id, *, status_filter)` with filtering
- Wire ranked suggestions into fulfillment report (Task 06)

Acceptance criteria:
- ProposedTask supports all 5 statuses: pending, accepted, rejected, deferred, backlog
- `rank_proposed_tasks()` produces deterministic ranking for fixture inputs
- Suggestions are generated from fulfillment results (not hardcoded)
- `defer_proposed_task()` and `backlog_proposed_task()` work correctly
- CLI commands `remedy propose defer` and `remedy propose backlog` work
- Unit test: generate suggestions from fixture fulfillment → ranked list with correct ordering

Priority rationale:
User interaction layer. This is how humans steer the next iteration. Low effort because proposed_tasks.py already has most of the CRUD. Depends on Tasks 05-06 for fulfillment data to base suggestions on.

---

## Task 09: Per-Task Token and Cost Accounting

Impact: Medium
Effort: Low

Context:
`packages/orchestration/token_economy.py` provides token economy reporting. `context_pack.py` estimates tokens per section. `token_policy.py` defines budgets. But there's no per-task accounting that records: actual tokens used, model chosen, cost incurred, and delta from budget.

Problem:
The goal requires the report to show "token/cost reasoning" per task. Without per-task accounting, there's no way to show users where tokens/money went, whether the routing was efficient, or where savings are possible.

Goal:
Create `packages/orchestration/task_cost_ledger.py` that records per-task token and cost data as tasks execute, and provides aggregation for reporting.

Relevant areas:
- packages/orchestration/token_economy.py (existing token economy — design reference)
- packages/orchestration/context_pack.py (token estimation)
- packages/orchestration/task_route_decision.py (Task 03 — cost estimates)
- packages/orchestration/fulfillment_report.py (Task 06 — consumes cost data)

Proposed changes:
- Create `task_cost_ledger.py` with `TaskCostEntry` frozen dataclass
- Fields: task_id, context_tokens_budgeted, context_tokens_actual, output_tokens, model_id, tier, cost_cents_estimated, cost_cents_actual, savings_vs_expensive_cents, reasoning
- `record_task_cost(entry)` appends to job-scoped ledger
- `build_cost_summary(job_id)` → `CostSummary` with totals, per-tier breakdown, savings
- `export_cost_summary_json()` for reporting
- Wire into `FulfillmentLoop` (Task 05) — record cost after each task execution
- Wire into `FulfillmentReport` (Task 06) — include per-task + aggregate cost data

Acceptance criteria:
- `TaskCostEntry` captures all required fields
- `build_cost_summary()` aggregates correctly across tasks
- Savings calculation: sum of (expensive_rate - actual_rate) * tokens for local-routed tasks
- Cost ledger persists to disk (JSON in workspace)
- Report includes per-task cost + aggregate summary
- Unit test: 3 tasks with different tiers → correct summary with savings

Priority rationale:
Transparency and optimization driver. Users need to see where tokens go to trust the routing decisions. Low effort because it's a data recording module with no complex logic. Depends on Tasks 03 and 05 for route decisions and execution data.

---

## Task 10: Local LLM Cheap-Route Execution Path

Impact: Medium
Effort: Medium

Context:
`packages/providers/ollama_planner/provider.py` and `packages/providers/ollama_builder/provider.py` implement Ollama-backed planning and building. `worker_recommend.py` scores local providers higher. `builder_routing.py` has `local_advisor` and `local_candidate_generator` tiers. But there's no wiring that automatically routes a low-risk task to a local Ollama instance based on the routing decision.

Problem:
The infrastructure for local LLM execution exists (Ollama providers) and the routing decision logic exists (builder_routing), but they're disconnected. A task routed to `local_first` tier still needs manual provider selection. The goal requires automatic routing: "cheap, repetitive, low-risk, or narrow tasks should prefer local LLMs."

Goal:
Wire the per-task routing decision (Task 03) into automatic provider selection so that `local_first` tier tasks are dispatched to Ollama (or other local provider) without manual intervention.

Relevant areas:
- packages/providers/ollama_planner/provider.py (local planner provider)
- packages/providers/ollama_builder/provider.py (local builder provider)
- packages/orchestration/task_route_decision.py (Task 03 — route decisions)
- packages/orchestration/worker_recommend.py (worker scoring — provider registry)
- packages/orchestration/fulfillment_loop.py (Task 05 — dispatches to workers)
- packages/orchestration/builder_routing.py (tier definitions)

Proposed changes:
- Create `packages/orchestration/provider_dispatch.py` with `dispatch_to_provider(route_decision, task_ctx, available_providers)` → builder callable
- Provider registry: map tier → available providers → select best match
- `local_first` tier → Ollama builder (if available) → fallback to fixture → fallback to human_review_required
- `expensive_model` tier → Claude agent (if available) → fallback to human_review_required
- `deterministic_only` tier → no provider needed (local Python logic)
- Add provider availability check: ping Ollama endpoint before dispatching
- Wire into `FulfillmentLoop.run()` (Task 05) — use dispatch instead of single injected callable
- Fallback chain ensures no task silently fails — always produces a route or stops

Acceptance criteria:
- `dispatch_to_provider()` returns correct callable for each tier
- local_first tier dispatches to Ollama when available
- Unavailable Ollama falls back gracefully (no crash, clear stop reason)
- Provider availability check is bounded (timeout, no hang)
- Cost ledger (Task 09) records actual provider used
- Unit test: mock Ollama available → dispatches to Ollama; mock unavailable → falls back

Priority rationale:
Closes the loop between routing decisions and actual execution. Without this, routing is advisory-only. Depends on Tasks 03 and 05 for route decisions and the loop engine. Medium effort because Ollama providers already exist — this is wiring, not new provider implementation.
