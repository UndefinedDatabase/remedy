How can this project be 10 times better than it is now? Give improvement tipps!
