## Task 01: Build a Real HTTP API Surface

Impact: High  
Effort: High  

Context:
`apps/api/__init__.py` is still a reserved namespace even though Remedy already has meaningful orchestration state, a localhost UI server, and a growing need for machine-to-machine access.

Problem:
The project is still primarily operated through CLI entrypoints and a read-only localhost server. That blocks external automation, remote control, integrations, and a stable contract for non-CLI clients.

Goal:
Implement a first-class HTTP API application in `apps/api/` that exposes safe read endpoints plus the minimal mutation endpoints needed to create jobs and advance orchestration.

Relevant areas:
- `apps/api/__init__.py`
- `packages/orchestration/storage.py`
- `packages/orchestration/task_runner.py`
- `packages/orchestration/ui_server.py`

Proposed changes:
- Create an actual API app entrypoint with explicit route contracts for job creation, job inspection, job progress, and safe orchestration actions.
- Reuse existing orchestration services instead of duplicating CLI logic inside handlers.
- Define token/auth expectations and response schemas so UI and external tools can rely on stable payloads.
- Add a minimal startup path in docs and packaging so the API can be run independently of the UI-only server.

Acceptance criteria:
- `apps/api/` contains a runnable API application instead of only a reserved namespace.
- The API can create a job, fetch a job, and trigger at least one safe orchestration step through documented endpoints.
- Response schemas are deterministic and covered by automated tests.
- The implementation reuses orchestration services rather than shelling out to CLI commands.

Priority rationale:
This is the biggest leverage point for turning Remedy from an advanced local tool into a system other software can actually integrate with.

## Task 02: Add a Background Worker Execution Layer

Impact: High  
Effort: High  

Context:
`apps/worker/__init__.py` is still a reserved namespace, while long-running orchestration behavior remains tied to foreground command execution.

Problem:
Without a worker layer, Remedy has no durable execution model for queued jobs, background progress, retries, or service-style deployments. Work only advances when a foreground command is actively running.

Goal:
Implement a worker process that can poll or subscribe to pending jobs and advance them using existing orchestration primitives.

Relevant areas:
- `apps/worker/__init__.py`
- `packages/orchestration/autorun.py`
- `packages/orchestration/task_runner.py`
- `packages/orchestration/storage.py`

Proposed changes:
- Define a worker entrypoint that can discover pending work and process jobs in a controlled loop.
- Move any reusable loop logic out of CLI-only flows so both CLI and worker can share it.
- Add heartbeat/state updates so job progress is visible while the worker is active.
- Define retry and stop conditions for recoverable versus terminal failures.

Acceptance criteria:
- `apps/worker/` contains a real worker implementation and startup path.
- A queued or pending job can be advanced without a foreground CLI process staying attached.
- Worker progress is persisted so other processes can inspect current status.
- Failure and retry behavior is deterministic and covered by tests.

Priority rationale:
An API without a worker still leaves Remedy as a manually driven tool. The worker is the execution model that makes the rest of the platform believable.

## Task 03: Implement Dedicated Artifact Persistence and Indexing

Impact: High  
Effort: High  

Context:
`packages/artifacts/__init__.py` is still a reserved namespace, while `packages/core/models.py` stores artifacts inline as `Job.artifacts`.

Problem:
Artifact growth currently scales the main job document directly. That makes persistence heavier, weakens searchability, and prevents a clean artifact lifecycle separate from job metadata.

Goal:
Create a real artifact storage/index layer so artifacts can be persisted, queried, and evolved independently of the main job JSON.

Relevant areas:
- `packages/artifacts/__init__.py`
- `packages/core/models.py`
- `packages/orchestration/task_runner.py`
- `packages/orchestration/storage.py`

Proposed changes:
- Introduce an artifact repository abstraction under `packages/artifacts/` with stable create/load/list/query operations.
- Replace inline artifact-heavy storage with references or a migration path that keeps job payloads compact.
- Add indexing or query support for kind, task, time, and provenance.
- Define migration behavior for already persisted jobs so the change is incremental rather than destructive.

Acceptance criteria:
- `packages/artifacts/` contains working persistence code instead of only a reserved namespace.
- Jobs no longer need to carry full artifact payloads inline as the only storage strategy.
- Artifacts can be queried independently by job or task metadata.
- Migration or backward-compatibility behavior is tested.

Priority rationale:
This is a structural scalability issue already visible in the current model design, and it affects persistence, observability, and future product surfaces at once.

## Task 04: Make Job Persistence Atomic and Recoverable

Impact: High  
Effort: Medium  

Context:
`packages/orchestration/storage.py` writes job JSON directly with `write_text()` and silently skips corrupted files during `list_jobs()`.

Problem:
A partial write, interrupted process, or corrupted file can make a job disappear from normal listing without a recovery path. That is unsafe for a system that increasingly wants durable orchestration state.

Goal:
Harden job storage so writes are atomic, corruption is detectable, and recovery/reporting paths exist.

Relevant areas:
- `packages/orchestration/storage.py`
- `packages/orchestration/data_paths.py`
- `tests/`

Proposed changes:
- Replace direct writes with an atomic temp-file-plus-rename strategy.
- Add corruption detection and explicit reporting instead of silently discarding broken files.
- Introduce recovery helpers or quarantine behavior for malformed job documents.
- Add targeted tests for interrupted writes, unreadable files, and recovery outcomes.

Acceptance criteria:
- Job saves use an atomic persistence strategy.
- Corrupted files are surfaced predictably instead of being silently skipped.
- Recovery or quarantine behavior is documented and tested.
- Existing load/save/list flows remain backward compatible for valid jobs.

Priority rationale:
Durable orchestration needs trustworthy persistence first. This is lower effort than a full storage redesign and immediately reduces the chance of invisible state loss.

## Task 05: Replace Broad Exception Swallowing with Structured Degradation

Impact: High  
Effort: Medium  

Context:
Current code paths in modules such as `packages/orchestration/ui_server.py` and `packages/orchestration/autorun.py` still use broad `except Exception:` handling.

Problem:
Broad exception swallowing hides real failures, makes degraded states hard to diagnose, and weakens trust in the UI and autonomy features when something goes wrong silently.

Goal:
Replace broad exception swallowing with explicit degradation behavior, classified failure paths, and safe diagnostic signals.

Relevant areas:
- `packages/orchestration/ui_server.py`
- `packages/orchestration/autorun.py`
- `packages/orchestration/task_runner.py`

Proposed changes:
- Audit broad `except Exception:` sites and replace them with narrower handling where possible.
- Where degradation is intentional, record a safe structured flag or event rather than silently ignoring the failure.
- Ensure UI-safe and API-safe error summaries do not leak sensitive content.
- Add tests that prove degraded behavior is observable and deterministic.

Acceptance criteria:
- Broad exception swallowing is reduced or removed in the identified orchestration/UI paths.
- Intentional degradation produces an explicit safe signal.
- Diagnostic behavior is covered by automated tests.
- No raw tracebacks or sensitive payloads leak into user-facing responses.

Priority rationale:
This improves reliability, operability, and debugging quality without requiring a major architectural rewrite, and it addresses a concrete anti-pattern present in current code.

## Task 06: Rewrite the README for Real Onboarding

Impact: High  
Effort: Medium  

Context:
`README.md` is dominated by numbered implementation steps and historical build narrative rather than current-day onboarding.

Problem:
The repository explains how Remedy was built more than what Remedy is today, how to run it quickly, or how a new contributor should navigate its main surfaces.

Goal:
Turn the README into a current product and contributor entrypoint, with historical implementation detail moved out of the top-level path.

Relevant areas:
- `README.md`
- `docs/architecture.md`
- `apps/cli/`
- `apps/ui/`

Proposed changes:
- Replace the step-log-heavy top section with a concise explanation of what Remedy is, who it is for, and how to run the main workflows.
- Add quickstart instructions for CLI, UI, and any supported local setup path.
- Move historical milestone detail into docs if it still has value.
- Add a clear map of the main packages and application surfaces.

Acceptance criteria:
- The README starts with product overview, quickstart, and project structure instead of an implementation diary.
- A new contributor can identify how to run the core flows within a few minutes.
- Historical step-by-step detail is reduced or relocated.
- README content matches the current repository state.

Priority rationale:
A project can be technically strong and still underperform if the first-contact documentation signals “internal build log” instead of “usable system.”

## Task 07: Add HTTP Integration Tests for the UI Server Contract

Impact: Medium  
Effort: Medium  

Context:
`packages/orchestration/ui_server.py` already exposes a meaningful set of localhost JSON endpoints and safe data builders.

Problem:
The route layer is substantial enough to act like an API contract, but it is not defended by a dedicated endpoint-level integration suite. Breakage in routing, auth gating, or response shape can slip through backend-only tests.

Goal:
Create focused integration tests that exercise the UI server as an HTTP surface rather than only through internal helper behavior.

Relevant areas:
- `packages/orchestration/ui_server.py`
- `tests/`

Proposed changes:
- Add an integration test module that boots the server in-process and calls the public endpoints over HTTP.
- Verify route behavior for valid requests, invalid job IDs, missing jobs, and token-gated access.
- Assert response-shape stability for the main JSON endpoints.
- Add regression coverage for safe error responses and no-leak guarantees.

Acceptance criteria:
- The UI server has a dedicated HTTP integration test suite.
- Main endpoints are exercised through real request/response flows.
- Invalid and unauthorized paths are covered.
- Tests verify safe error responses and stable payload shape.

Priority rationale:
This is the missing contract test layer for a backend surface that is already acting like production infrastructure.

## Task 08: Add Real Frontend Component Tests with Vitest

Impact: Medium  
Effort: Medium  

Context:
`apps/ui/package.json` already includes Vitest, but the repo does not currently have an active frontend component test suite.

Problem:
The UI can regress in rendering, behavior, and interaction flow without being caught by the existing Python-heavy test suite. Installed tooling exists, but the test layer it enables is still absent.

Goal:
Create a real component test foundation for the React UI and cover the most behaviorally important surfaces first.

Relevant areas:
- `apps/ui/package.json`
- `apps/ui/src/RemedyApp.tsx`
- `apps/ui/src/components/`

Proposed changes:
- Configure and document the frontend test runner so it is part of normal development.
- Add component tests for the shell, graph-related state selection, live panel behavior, and command bar behavior.
- Focus first on user-visible state transitions rather than snapshot-only coverage.
- Ensure tests can run locally without the full backend stack by mocking API responses.

Acceptance criteria:
- The UI repo contains runnable Vitest-based component tests.
- Core interactive components have behavior-oriented coverage.
- Frontend tests are documented and easy to run.
- Regressions in key UI behavior can fail the test suite without needing manual browser checks.

Priority rationale:
This is a concrete missing quality layer, not a generic test request, and the required tooling is already partially in place.

## Task 09: Upgrade the UI Transport to Cursor-Aware Live Updates

Impact: Medium  
Effort: Medium  

Context:
`apps/ui/src/RemedyApp.tsx` reloads on a fixed 5-second interval, while the backend already exposes richer live-state concepts through `packages/orchestration/ui_server.py`.

Problem:
Fixed polling is stale, wasteful, and fragile under transient failures. The UI refresh model does not match the sophistication of the underlying job/event state.

Goal:
Move the UI from unconditional periodic reloads toward cursor-aware or event-aware live updates with better resilience.

Relevant areas:
- `apps/ui/src/RemedyApp.tsx`
- `apps/ui/src/api/remedyApi.ts`
- `packages/orchestration/ui_server.py`

Proposed changes:
- Introduce a live-state transport that can request only what changed or react to a server-provided cursor/hash.
- Add retry and backoff behavior for transient fetch failures.
- Distinguish between stale-but-usable state and hard-load failure in the UI.
- Keep the implementation compatible with the existing safe, local-only server model.

Acceptance criteria:
- The UI no longer relies only on unconditional 5-second full reloads.
- Live updates can skip unchanged state or consume a server-provided cursor/hash.
- Transient failures degrade gracefully with retry behavior.
- User-facing state clearly reflects stale versus current data.

Priority rationale:
This is a meaningful product-quality improvement that makes the existing UI feel more like a live system and less like a periodic dashboard refresh.

## Task 10: Turn the Command Bar into a Real Search and Action Surface

Impact: Medium  
Effort: Medium  

Context:
`apps/ui/src/components/command/CommandBar.tsx` already presents a command/search interface, but the input itself is read-only.

Problem:
The UI suggests an interactive control surface that does not actually search, navigate, or trigger anything. That makes the feature feel unfinished and leaves a high-value UX affordance unused.

Goal:
Make the command bar genuinely useful for graph navigation, discovery, and safe action triggering.

Relevant areas:
- `apps/ui/src/components/command/CommandBar.tsx`
- `apps/ui/src/api/remedyApi.ts`
- `packages/orchestration/ui_server.py`

Proposed changes:
- Enable user input and add local or server-backed search across jobs, nodes, tasks, or next actions.
- Support safe command suggestion flows that reuse existing backend action concepts.
- Connect search results to graph focus, detail selection, or live panel state.
- Keep action execution bounded to safe, explicitly supported operations.

Acceptance criteria:
- The command bar accepts input and returns meaningful results or actions.
- Users can navigate to relevant graph/task state from the command bar.
- Any action flow is limited to explicitly supported safe operations.
- The behavior is covered by frontend tests.

Priority rationale:
This turns an already-visible but currently hollow UI affordance into a real product feature that improves navigation and usability immediately.
