# Sources

- README.md — step-history-heavy onboarding and current project narrative.
- docs/architecture.md — intended architecture boundaries and replaceable-layer model.
- apps/api/__init__.py — reserved namespace for the future HTTP API server.
- apps/worker/__init__.py — reserved namespace for the future background worker.
- packages/artifacts/__init__.py — reserved namespace for future artifact persistence backends.
- packages/core/models.py — `Job.artifacts: list[Artifact]` keeps artifact payloads inline with job state.
- packages/orchestration/storage.py — direct JSON writes and silent skipping of corrupted files.
- packages/orchestration/ui_server.py — existing localhost JSON route surface and broad exception swallowing in safe builder paths.
- packages/orchestration/autorun.py — additional broad exception swallowing in autonomy/fixture flows.
- apps/ui/src/RemedyApp.tsx — unconditional polling every 5 seconds.
- apps/ui/src/api/remedyApi.ts — current fetch/normalization behavior and lack of retry or cursor-aware live transport.
- apps/ui/src/components/command/CommandBar.tsx — read-only command bar.
- apps/ui/package.json — Vitest dependency is present.
- tests/test_data_paths.py — proof that one previously tempting brainstorm theme is already addressed.
- .brain/2026-05-29_001/tasks.md and .brain/2026-05-29_001/.thinking/* — formatting and quality bar for this run.
