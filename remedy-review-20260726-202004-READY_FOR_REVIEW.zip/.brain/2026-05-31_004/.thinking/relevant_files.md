# Relevant Files

- README.md — onboarding is dominated by step history instead of current product guidance.
- docs/architecture.md — confirms the intended modular layering and provider boundaries.
- apps/api/__init__.py — proves the HTTP API layer is planned but still unimplemented.
- apps/worker/__init__.py — proves the background worker layer is planned but still unimplemented.
- packages/artifacts/__init__.py — proves artifact persistence/indexing is intentionally deferred.
- packages/core/models.py — shows `Job.artifacts` are stored inline on the main job document.
- packages/orchestration/storage.py — shows JSON file persistence is a direct write with corrupted files silently skipped.
- packages/orchestration/task_runner.py — execution flow and exception handling anchor for reliability work.
- packages/orchestration/autorun.py — autonomy loop fixture paths include broad exception swallowing.
- packages/orchestration/ui_server.py — current read-only HTTP surface and multiple broad `except Exception` handlers.
- apps/ui/src/RemedyApp.tsx — unconditional 5-second polling and minimal loading/error UX.
- apps/ui/src/api/remedyApi.ts — fetch strategy, fallback logic, and lack of retry/live cursor handling.
- apps/ui/src/components/command/CommandBar.tsx — command/search bar is present but read-only.
- apps/ui/package.json — Vitest is installed but not backed by an active component test suite.
- tests/test_data_paths.py — confirms data-path centralization is already solved and should not be repeated as a brainstorm item.
