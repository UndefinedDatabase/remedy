# Repo Map

## Product surfaces
- apps/cli/ — primary user entrypoint today; grouped command handlers for project, brain, repo, readiness, and dashboard flows.
- apps/ui/ — React/Vite UI with a graph, live panel, and command bar; currently depends on read-only JSON endpoints.
- apps/api/ — reserved namespace only; planned HTTP API server is not implemented.
- apps/worker/ — reserved namespace only; planned background execution worker is not implemented.

## Core backend
- packages/core/models.py — domain models for Job, Task, Artifact, and lifecycle state; artifacts are currently stored inline on Job.
- packages/orchestration/storage.py — JSON job persistence in `.data/jobs`; no database, atomicity, or recovery layer yet.
- packages/orchestration/autorun.py — autonomy fixtures and loop-related behavior; contains broad exception swallowing in non-critical paths.
- packages/orchestration/task_runner.py — task execution path and artifact creation.
- packages/orchestration/ui_server.py — localhost read-only HTTP server with dashboard, brain, events, readiness, guide, checklist, detail, and live-state builders.
- packages/artifacts/ — reserved namespace only; no external artifact storage/index yet.

## UI implementation anchors
- apps/ui/src/RemedyApp.tsx — bootstraps dashboard loading and polls every 5 seconds.
- apps/ui/src/api/remedyApi.ts — client-side fetch/normalization layer for UI endpoints.
- apps/ui/src/components/command/CommandBar.tsx — command/search surface, currently read-only.
- apps/ui/package.json — Vite, React, Vitest available, but no active frontend test layer in the repo.

## Documentation and tests
- README.md — long step-by-step build history and implementation diary.
- docs/architecture.md — layered architecture and provider boundaries.
- tests/ — broad Python coverage for orchestration and CLI; no dedicated frontend component test suite and no focused HTTP route integration suite for ui_server.
