Review the whole code base and give improvements to make remedy better
