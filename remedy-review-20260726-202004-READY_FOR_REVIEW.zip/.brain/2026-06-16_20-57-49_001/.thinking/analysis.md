# Analysis

## Signal 1: ui_server.py is a 2584-line god module
- 65+ functions, 29 `_build_*_section` dashboard builders
- `_build_dashboard()` alone is ~330 lines (1127-1457)
- Uses stdlib `http.server.BaseHTTPRequestHandler` — synchronous, single-threaded
- Manual URL routing in `do_GET` with string splitting
- All job parameters typed as `Any` (48 occurrences)
- Section builders follow identical pattern: could be a registry + loop

## Signal 2: review_bundle.py swallows 45 exceptions identically
- Lines 1684-1995: 30+ blocks of identical try/except Exception pattern
- Each block: build JSON section, catch any error, record "build failed"
- No logging, no traceback, no error detail — silent failure
- Same 7-line block copy-pasted 30+ times — should be a loop over a section registry

## Signal 3: No static analysis tooling configured
- 63,440 lines of Python with zero linting/type-checking gates
- No ruff, mypy, flake8, pylint, black, or isort in pyproject.toml or standalone config
- pytest markers defined but no quality gate for type safety or style
- Makes regression detection entirely manual

## Signal 4: Flat orchestration package (110 modules)
- All 110 .py files live in packages/orchestration/ with no sub-packages
- Natural groupings exist: repair (4 files), overnight (4+ files), ui/dashboard (5+ files), events (3+ files), worker (4+ files), brain (4+ files)
- Finding files requires knowing exact names — no directory-level organization
- Import paths are unnecessarily long and flat

## Signal 5: Dead provider stubs and v1/v2 duplication
- claude_agent, docker_runtime, mempalace: empty __init__.py since project inception
- apps/api/ and apps/worker/: also empty stubs
- repair_loop.py (v1, 1466 lines) coexists with repair_loop_v2.py (1168 lines)
- v1 is still imported by some modules but may be superseded

## Signal 6: README is a 590-line changelog
- Documents Steps 1 through 10+ in chronological order
- Reads like commit history, not a project overview
- Buries install/usage instructions under step descriptions
- Architecture section at the bottom is outdated (references "(future)" for implemented features)

## Signal 7: Dashboard section builders are a factory pattern waiting to happen
- 29 _build_*_section functions in ui_server.py all follow the same signature: `(job: Any) -> dict[str, Any]`
- _build_dashboard calls them sequentially with inline try/except
- Perfect candidate for a declarative section registry + loop
- Would reduce _build_dashboard from 330 lines to ~30

## Signal 8: Type safety erosion — `Any` as the default
- Job objects passed as `Any` throughout ui_server.py, review_bundle.py, and dashboard builders
- Defeats the purpose of having Pydantic models in packages/core/models.py
- Core models exist but downstream consumers don't import/use them
- Makes refactoring dangerous — no type checker to catch breakage

## Signal 9: Exception handling is inconsistent
- 105 bare `except Exception` across 16 files
- Some files (repair_loop_v2.py) have 10 — likely swallowing actionable errors
- No structured logging framework — print/stderr only
- No error taxonomy or error codes for programmatic handling

## Signal 10: Test organization and coverage
- 211 test files — high count, but structure is fragmented
- Old step-based test __pycache__ files remain (test_steps_80_81_82, etc.) suggesting recent migration
- Test file naming inconsistent: some in tests/, some in tests/orchestration/, some duplicated
- No test coverage measurement configured
