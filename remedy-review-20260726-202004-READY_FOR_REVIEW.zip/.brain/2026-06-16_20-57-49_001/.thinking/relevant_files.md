# Relevant Files for Improvements

## God Modules (need decomposition)
- packages/orchestration/ui_server.py — 2584 lines, 65+ functions, stdlib http.server, 29 _build_*_section functions
- packages/orchestration/review_bundle.py — 2097 lines, 45 bare except Exception catches
- packages/orchestration/progress_ledger.py — 2026 lines
- packages/orchestration/brain_detail.py — 1737 lines
- packages/orchestration/repository_snapshot.py — 1650 lines

## Exception Swallowing
- review_bundle.py: 45 except Exception (lines 1674-1995 repeat identical pattern)
- repair_loop_v2.py: 10 except Exception
- overnight_mission.py: 9 except Exception
- autorun.py: 7 except Exception
- repository_snapshot.py: 7 except Exception

## Dead/Stub Code
- packages/providers/claude_agent/__init__.py — empty
- packages/providers/docker_runtime/__init__.py — empty
- packages/providers/mempalace/__init__.py — empty
- apps/api/__init__.py — empty
- apps/worker/__init__.py — empty
- packages/orchestration/repair_loop.py — 1466 lines, v1 alongside v2

## Type Safety Gaps
- ui_server.py: 48 `Any` type annotations, all job parameters typed as `Any`
- No mypy.ini or pyproject.toml [tool.mypy] section
- No ruff.toml or pyproject.toml [tool.ruff] section

## Flat Package Structure
- packages/orchestration/ has 110 .py files in a single directory with no sub-packages
