# Repository Map

## Structure
- packages/core/ — Pydantic domain models (models.py), Protocol interfaces (contracts/)
- packages/orchestration/ — 110 modules, 60,687 lines — the entire orchestration engine
- packages/providers/ — ollama_builder, ollama_planner (implemented); claude_agent, docker_runtime, mempalace (empty stubs)
- apps/cli/ — grouped CLI with 50+ command files
- apps/ui/ — React/Vite frontend (cockpitLogic.ts)
- apps/api/ — empty stub
- apps/worker/ — empty stub
- tests/ — 211 test files across tests/, tests/orchestration/, tests/cli/, tests/ui_server/, tests/ui_contracts/, tests/regression/, tests/storage/
- docs/ — 40 documentation files
- scripts/ — pytest wrappers, smoke runners, tooling doctor

## Key Stats
- Total Python in packages/: 63,440 lines
- Orchestration modules: 110 files
- Largest files: ui_server.py (2584), review_bundle.py (2097), progress_ledger.py (2026), brain_detail.py (1737), repository_snapshot.py (1650), repair_loop.py (1466)
- No linter/type-checker config (no ruff, mypy, flake8, black, isort)
- Build system: hatchling, pydantic>=2.0, pytest
- README.md: 590 lines (changelog-style, not concise)
