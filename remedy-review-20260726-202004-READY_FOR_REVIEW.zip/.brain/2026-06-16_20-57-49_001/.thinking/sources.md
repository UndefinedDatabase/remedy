# Sources

## Files Read
- AGENTS.md (full)
- pyproject.toml (full)
- README.md (full)
- .gitignore (full)
- packages/orchestration/ui_server.py (lines 1127-1207, 2345-2425, imports, function signatures)
- packages/orchestration/review_bundle.py (lines 1670-1770, exception grep)

## Searches Performed
- `find` for all .py files in packages/, apps/, tests/, scripts/
- `wc -l` for orchestration module sizes (top 20)
- `grep` for except Exception/bare except (105 hits, 16 files)
- `grep` for TODO/FIXME/HACK (5 hits — mostly intentional in verifier_profiles.py)
- `grep` for `: Any` in ui_server.py (48 hits)
- `grep` for linter/type-checker configs (0 found)
- `grep` for repair_loop imports (53 files reference it)
- `grep` for _build_*_section functions (29 in ui_server.py)
- `find` for provider implementations (2 real, 3 empty stubs)

## Parallel Investigators
- Core models & contracts investigator
- Orchestration layer investigator
- CLI & providers investigator
- Test coverage gap investigator
- Advanced orchestration investigator
