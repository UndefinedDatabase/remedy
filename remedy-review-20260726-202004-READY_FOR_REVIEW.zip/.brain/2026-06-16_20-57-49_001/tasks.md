# Brainstorm Tasks

## Task 01: Decompose ui_server.py into a Modular Dashboard Server

Impact: High
Effort: High

Context:
`packages/orchestration/ui_server.py` is 2,584 lines with 65+ functions. It contains HTTP routing, 29 `_build_*_section` dashboard builders, frontend serving, and API dispatch all in one file. `_build_dashboard()` alone is ~330 lines. It uses stdlib `http.server.BaseHTTPRequestHandler` with manual URL routing via string splitting.

Problem:
God module. Changes to any dashboard section require editing a 2,500+ line file. Section builders follow identical patterns but are individually defined as separate functions. Route dispatch is a manual if/elif chain. No separation between HTTP concerns and business logic.

Goal:
Split `ui_server.py` into focused modules: a section registry with declarative section definitions, a route dispatcher, and the HTTP handler. The 29 `_build_*_section` functions should be registered via a decorator or registry dict so `_build_dashboard` becomes a loop over registered sections (~30 lines instead of ~330).

Relevant areas:
- `packages/orchestration/ui_server.py` (all 2,584 lines)
- `tests/ui_server/` (7 test files)
- `apps/cli/commands/ui.py` (CLI entry for UI server)

Proposed changes:
- Create `packages/orchestration/ui/` sub-package with `__init__.py`
- Move section builders to `packages/orchestration/ui/dashboard_sections.py`
- Create a `SectionRegistry` that auto-discovers and calls section builders
- Move HTTP handler to `packages/orchestration/ui/handler.py`
- Move frontend loading/building to `packages/orchestration/ui/frontend.py`
- Keep `ui_server.py` as a thin entry point that imports from `ui/`
- Update all existing tests to match new import paths

Acceptance criteria:
- `ui_server.py` is under 200 lines
- All 7 existing ui_server tests pass without modification to test logic
- `_build_dashboard` uses a section registry loop, not inline calls
- `remedy ui` CLI command works identically
- No new dependencies introduced

Priority rationale:
Largest single file in the codebase. Every dashboard feature change touches this file. Decomposition unblocks parallel development on UI features and reduces merge conflict risk.

---

## Task 02: Eliminate Exception Swallowing in review_bundle.py

Impact: High
Effort: Medium

Context:
`packages/orchestration/review_bundle.py` (2,097 lines) contains 45 bare `except Exception` blocks. Lines 1684-1995 repeat a 7-line pattern ~30 times: try to build a JSON section, catch any exception, record `status="error", error="build failed"` with no traceback, no logging, and no error detail.

Problem:
Silent failure. When a review bundle section fails, the error message is always "build failed" with no indication of what went wrong. Debugging requires adding print statements and re-running. Real errors (import failures, schema changes, data corruption) are invisible.

Goal:
Replace the copy-pasted try/except blocks with a helper function that: (1) logs the exception with traceback to stderr or a structured logger, (2) records the exception type and message in the section error field, (3) is called in a loop over a section registry instead of 30 copy-pasted blocks.

Relevant areas:
- `packages/orchestration/review_bundle.py` (lines 1670-2000 especially)
- `tests/orchestration/test_review_bundle.py`
- `apps/cli/commands/review_cmd.py`

Proposed changes:
- Define a `_SECTION_BUILDERS` list of `(name, builder_callable)` tuples
- Create `_build_section_safe(name, builder, *args)` that wraps each call with try/except, logs on failure, and records error details
- Replace the 30 copy-pasted blocks with a loop: `for name, builder in _SECTION_BUILDERS:`
- Include exception class name and message in the error field: `error="TypeError: 'NoneType' has no attribute 'get'"`
- Add `import logging` and emit `logger.warning(...)` on section failure

Acceptance criteria:
- Zero copy-pasted try/except blocks for section building
- Section failures include exception type and message in error field
- Failures are logged with traceback at WARNING level
- All existing review_bundle tests pass
- File reduced by at least 200 lines

Priority rationale:
Silent exception swallowing masks real bugs. This is the second-largest file and the worst offender for bare except (45 occurrences — 43% of all bare excepts in the codebase).

---

## Task 03: Add Ruff and Mypy to the Development Toolchain

Impact: High
Effort: Low

Context:
The repository has 63,440 lines of Python across `packages/` with no static analysis tooling configured. No ruff, mypy, flake8, pylint, black, or isort configuration exists in `pyproject.toml` or standalone config files. The only dev dependency is `pytest`.

Problem:
No automated quality gates for type safety, import hygiene, or code style. Type annotations exist (Pydantic models, function signatures) but are never checked. The 48 `Any` annotations in `ui_server.py` and similar patterns across the codebase go undetected. Regressions from refactoring have no static safety net.

Goal:
Configure ruff for linting/formatting and mypy for type checking in `pyproject.toml`. Start with permissive settings that pass on the existing codebase, then tighten incrementally.

Relevant areas:
- `pyproject.toml` (tool configuration)
- `packages/` (all Python source)
- `tests/` (all test files)

Proposed changes:
- Add `[tool.ruff]` section to `pyproject.toml` with `target-version = "py310"`, `line-length = 120`, and a starter rule set (`E`, `F`, `W`, `I`)
- Add `[tool.ruff.lint.per-file-ignores]` for test files
- Add `[tool.mypy]` section with `python_version = "3.10"`, `warn_return_any = false`, `check_untyped_defs = false` (permissive start)
- Add `ruff` and `mypy` to `[project.optional-dependencies] dev`
- Add `scripts/remedy_lint.sh` that runs `ruff check . && mypy packages/`
- Fix any immediately-failing ruff errors (likely < 20 import-order fixes)

Acceptance criteria:
- `ruff check .` passes (possibly with configured ignores)
- `mypy packages/` runs without crashing (warnings are OK initially)
- Both tools are documented in the dev dependencies
- A lint script exists for easy local/CI execution
- No functional code changes — only config and import ordering

Priority rationale:
Low effort, high defensive value. Every subsequent task benefits from linting and type checking. Prevents introduction of new bugs during refactoring tasks above.

---

## Task 04: Organize orchestration/ into Sub-Packages

Impact: High
Effort: High

Context:
`packages/orchestration/` contains 110 Python files in a single flat directory. Natural groupings exist: repair (repair_loop.py, repair_loop_v2.py, repair_context.py, repair_request_builder.py), overnight (overnight_executor.py, overnight_mission.py, overnight_readiness.py), ui/dashboard (ui_server.py, ui_view_model.py, ui_app_shell.py, ui_copy.py, dashboard.py), events (event_persistence.py, event_replay.py, event_schemas.py), workers (worker_registry.py, worker_adapters.py, worker_queue.py, worker_recommend.py), brain (orchestrator_brain.py, brain_viewer.py, brain_detail.py, brain_viewer_theme.py, project_brain_aggregate.py).

Problem:
Finding the right file requires knowing the exact name. Related modules are not colocated. Import paths are flat and uninformative (`from packages.orchestration.repair_loop_v2 import ...` vs `from packages.orchestration.repair import loop_v2`). IDE navigation is impaired by 110 files in one directory listing.

Goal:
Create sub-packages for natural groupings while maintaining backward-compatible imports via `__init__.py` re-exports during a transition period.

Relevant areas:
- `packages/orchestration/` (110 files)
- All import statements across packages/, apps/, tests/

Proposed changes:
- Create sub-packages: `repair/`, `overnight/`, `ui/`, `events/`, `workers/`, `brain/`
- Move related modules into their sub-packages
- Add `__init__.py` re-exports in each sub-package for backward compatibility
- Update `packages/orchestration/__init__.py` to re-export from sub-packages
- Grep all imports and update them to use new paths (or verify re-exports work)
- Run full test suite to confirm no import breakage

Acceptance criteria:
- No more than 40 files remain in the top-level `packages/orchestration/` directory
- All 211 test files pass
- Sub-packages have `__init__.py` with re-exports
- Each sub-package contains logically related modules only
- CLI commands work identically

Priority rationale:
Navigability directly impacts development velocity. At 110 files, the flat directory is a maintenance burden. Sub-packages enable focused ownership and reduce cognitive load.

---

## Task 05: Remove or Consolidate Dead Provider Stubs and Empty App Shells

Impact: Medium
Effort: Low

Context:
Three provider directories (`claude_agent`, `docker_runtime`, `mempalace`) contain only empty `__init__.py` files. Two app directories (`apps/api/`, `apps/worker/`) are also empty stubs. `packages/orchestration/repair_loop.py` (v1, 1,466 lines) coexists with `repair_loop_v2.py` (1,168 lines). README.md lists several features as "(future)" that either exist now or may never be built.

Problem:
Dead code creates false expectations. Developers may try to import from `packages/providers/claude_agent` expecting functionality. Empty stubs in `apps/api/` and `apps/worker/` suggest incomplete work. The v1/v2 repair loop coexistence is confusing — it's unclear which one is canonical.

Goal:
Remove genuinely dead code. If v1 repair loop is still needed, document why both exist. If not, consolidate into v2 and remove v1.

Relevant areas:
- `packages/providers/claude_agent/__init__.py`
- `packages/providers/docker_runtime/__init__.py`
- `packages/providers/mempalace/__init__.py`
- `apps/api/__init__.py`
- `apps/worker/__init__.py`
- `packages/orchestration/repair_loop.py` (v1)
- `packages/orchestration/repair_loop_v2.py` (v2)
- All files importing from repair_loop (53 files reference it)

Proposed changes:
- Remove empty provider stubs or replace `__init__.py` with a docstring-only stub explaining planned status
- Remove empty `apps/api/` and `apps/worker/` or add `raise NotImplementedError` with a message
- Audit repair_loop v1 vs v2: determine which modules import v1, whether v1 code paths are reachable
- If v1 is dead: remove `repair_loop.py`, update imports, update tests
- If v1 is still needed: add a deprecation notice and document the migration plan
- Update README.md "(future)" references to match current reality

Acceptance criteria:
- No empty `__init__.py` files masquerading as implementations
- repair_loop v1/v2 relationship is clear (either v1 removed or documented)
- All tests pass after cleanup
- README.md "(future)" tags are accurate

Priority rationale:
Low effort cleanup that reduces confusion. Dead code misleads both humans and AI agents working in the repo.

---

## Task 06: Introduce Structured Logging to Replace Silent Exception Handling

Impact: High
Effort: Medium

Context:
105 bare `except Exception` blocks exist across 16 files. Errors are handled via `print()` to stderr or silently swallowed. No structured logging framework exists. When overnight executor, repair loop, or review bundle operations fail, there is no persistent log to diagnose the issue.

Problem:
Operational visibility is near zero. If an overnight run fails at 3 AM, the only diagnostic is "build failed" in a review bundle section. Repair loops that silently catch exceptions appear to succeed when they actually encountered errors. Debug cycle: add print → reproduce → remove print → repeat.

Goal:
Add Python `logging` module configuration with structured output. Replace bare `except Exception` blocks with logged exceptions. Configure log levels so that silent swallowing becomes at minimum a WARNING-level log entry.

Relevant areas:
- `packages/orchestration/repair_loop_v2.py` (10 bare excepts)
- `packages/orchestration/overnight_mission.py` (9 bare excepts)
- `packages/orchestration/autorun.py` (7 bare excepts)
- `packages/orchestration/repository_snapshot.py` (7 bare excepts)
- `packages/orchestration/test_execution_service.py` (6 bare excepts)
- `packages/orchestration/review_bundle.py` (45 bare excepts — addressed separately in Task 02)

Proposed changes:
- Add `logging.getLogger(__name__)` to each module with bare excepts
- Replace `except Exception:` with `except Exception: logger.warning("...", exc_info=True)`
- Add a `packages/orchestration/log_config.py` with default logging setup (JSON or structured format)
- Wire log configuration in the CLI entry point (`apps/cli/grouped.py`)
- Ensure test output is not polluted (use `logging.NullHandler` default)

Acceptance criteria:
- All 105 bare `except Exception` blocks either log at WARNING+ or are converted to specific exception types
- A log configuration module exists with sensible defaults
- CLI entry point configures logging before dispatching commands
- Tests pass without log noise (NullHandler or caplog-based assertions)
- At least one integration test verifies that a logged error is captured

Priority rationale:
Operational visibility is critical for overnight runs and repair loops. Without logging, failures are invisible. This unblocks effective debugging for all other features.

---

## Task 07: Enforce Type Safety for Job Objects Across Dashboard and UI Modules

Impact: Medium
Effort: Medium

Context:
`packages/core/models.py` defines Pydantic models including `Job`, `Task`, `Artifact`, etc. However, `packages/orchestration/ui_server.py` uses `job: Any` in 48 places. `review_bundle.py` and other dashboard-related modules also pass job objects as `Any`. The Pydantic models exist but downstream consumers bypass them.

Problem:
Type annotations of `Any` defeat static analysis. Refactoring `Job` fields (adding, renaming, removing) will silently break all 29 `_build_*_section` functions without any type checker catching it. IDE autocomplete doesn't work on `Any` parameters.

Goal:
Replace `job: Any` with `job: Job` (or the appropriate Pydantic model type) in all dashboard and UI modules. Resolve any import issues that prevented this typing in the first place.

Relevant areas:
- `packages/orchestration/ui_server.py` (48 `Any` annotations)
- `packages/orchestration/review_bundle.py`
- `packages/orchestration/dashboard.py`
- `packages/orchestration/brain_viewer.py`
- `packages/orchestration/brain_detail.py`
- `packages/core/models.py` (Job model definition)

Proposed changes:
- Add `from packages.core.models import Job` to ui_server.py and related modules
- Replace `job: Any` with `job: Job` in all function signatures
- Replace `dict[str, Any]` return types with TypedDict or dataclass where patterns are stable
- Run mypy (from Task 03) to verify type consistency
- Fix any attribute access errors revealed by proper typing

Acceptance criteria:
- Zero `job: Any` parameters in ui_server.py, review_bundle.py, and dashboard modules
- `mypy packages/orchestration/ui_server.py` passes with `--strict` flag (or documents remaining issues)
- All existing tests pass
- IDE autocomplete works for job attributes in section builders

Priority rationale:
Type safety compounds. Once Job is properly typed in UI modules, every subsequent dashboard change gets free type checking. Requires Task 03 (mypy) to be fully effective.

---

## Task 08: Rewrite README.md as a Concise Project Overview

Impact: Medium
Effort: Low

Context:
`README.md` is 590 lines organized as a chronological step-by-step changelog (Step 1, Step 2, ... Step 10+). It documents internal implementation history rather than providing a user-facing project overview. The architecture section is at the bottom and lists several features as "(future)" that are already implemented. Install and usage instructions are buried within step descriptions.

Problem:
New contributors must read 590 lines to understand what Remedy does. The step-by-step format makes it unclear what the current state is — only what was built in what order. The "(future)" labels are outdated.

Goal:
Rewrite README.md as a concise project overview (<100 lines) with: what it is, how to install, how to use it, architecture overview, and a link to detailed docs. Move the step history to `docs/changelog.md` or delete it.

Relevant areas:
- `README.md` (590 lines)
- `docs/architecture.md` (comprehensive, 41k tokens)
- `docs/` (40 documentation files)

Proposed changes:
- Write a new README.md with sections: Overview, Install, Quick Start, Architecture (brief), Contributing, Links
- Move the Step 1-10 content to `docs/build-history.md` (or delete if docs/architecture.md covers it)
- Update the Structure section to reflect current reality (remove "(future)" for implemented features)
- Link to `docs/architecture.md` for detailed architecture
- Keep README under 100 lines

Acceptance criteria:
- README.md is under 100 lines
- Contains working install and quick-start commands
- No "(future)" labels for features that exist
- Step-by-step history is preserved in docs/ (not lost)
- Architecture section matches current directory structure

Priority rationale:
README is the front door. A 590-line changelog-style README hurts onboarding. Low effort, immediate clarity improvement.

---

## Task 09: Add Test Coverage Measurement and Identify Gaps

Impact: Medium
Effort: Low

Context:
211 test files exist but there is no coverage measurement configured. `pytest` is the only test dependency. No `pytest-cov` or `coverage` in `pyproject.toml`. Tests are organized across `tests/`, `tests/orchestration/`, `tests/cli/`, `tests/ui_server/`, `tests/ui_contracts/`, `tests/regression/`, `tests/storage/`. Old step-based test `__pycache__` files suggest a recent migration.

Problem:
Without coverage data, it's impossible to know which orchestration modules lack tests. The large modules (ui_server.py at 2,584 lines, review_bundle.py at 2,097 lines) likely have low branch coverage despite having test files. New features added to the 110-module orchestration package may silently lack test coverage.

Goal:
Add `pytest-cov` to dev dependencies, configure coverage measurement, run it once, and document the gaps. Establish a baseline coverage percentage.

Relevant areas:
- `pyproject.toml` (dependencies and pytest config)
- `tests/` (all 211 test files)
- `scripts/remedy_pytest.sh` (test runner wrapper)

Proposed changes:
- Add `pytest-cov` to `[project.optional-dependencies] dev`
- Add `[tool.coverage.run]` and `[tool.coverage.report]` sections to `pyproject.toml`
- Configure source paths: `source = ["packages", "apps"]`
- Add `--cov` flag to `scripts/remedy_pytest.sh`
- Run coverage once and generate an HTML report
- Document the top 10 uncovered modules in a `docs/coverage-gaps.md`
- Set a baseline `fail_under` threshold (start low, e.g., 40%)

Acceptance criteria:
- `pytest --cov=packages --cov=apps` runs and produces a coverage report
- Coverage configuration exists in `pyproject.toml`
- Top 10 coverage gaps are documented
- A minimum coverage threshold is set (even if low initially)
- Scripts updated to include coverage flag

Priority rationale:
You can't improve what you can't measure. Coverage data drives informed decisions about where to add tests. Low effort to configure, high informational value.

---

## Task 10: Reduce _build_dashboard to a Declarative Section Registry

Impact: Medium
Effort: Medium

Context:
`_build_dashboard()` in `packages/orchestration/ui_server.py` (lines 1127-1457, ~330 lines) constructs a dashboard payload by calling 29 `_build_*_section` functions inline. Each call is wrapped in an identical try/except pattern. The function is the single longest function in the codebase.

Problem:
Adding a new dashboard section requires: (1) writing a `_build_*_section` function, (2) adding a try/except call inside `_build_dashboard`, (3) adding a key to the return dict. Steps 2 and 3 are pure boilerplate. The 330-line function is hard to read and review. Section ordering is implicit in code position.

Goal:
Replace the inline calls with a declarative section registry. Each section declares its key name, builder function, and required arguments (job, events, data_dir). `_build_dashboard` becomes a loop that iterates the registry, calls each builder, handles errors uniformly, and assembles the result dict.

Relevant areas:
- `packages/orchestration/ui_server.py` (lines 1127-1457 — `_build_dashboard`)
- `packages/orchestration/ui_server.py` (29 `_build_*_section` functions)
- `tests/ui_server/test_dashboard_contract.py`
- `tests/ui_server/test_dashboard_cockpit_truth.py`

Proposed changes:
- Define a `DashboardSection` dataclass: `name: str, builder: Callable, args: tuple[str, ...]`
- Create `_DASHBOARD_SECTIONS: list[DashboardSection]` registry listing all 29 sections
- Implement `_build_section_safe(section, context) -> tuple[str, dict | None]` error wrapper
- Rewrite `_build_dashboard` as: build context dict, loop over registry, assemble result
- Preserve the exact same output structure (key names, nesting, types)
- Add a test that verifies the registry contains all expected section keys

Acceptance criteria:
- `_build_dashboard` is under 50 lines
- Dashboard JSON output is byte-identical for a given job state
- All existing dashboard tests pass
- New sections can be added by appending to `_DASHBOARD_SECTIONS` only
- Error handling is uniform across all sections (logged, not swallowed)

Priority rationale:
Direct follow-up to Task 01 (decomposition) and Task 02 (exception handling). This is the mechanical heart of the dashboard — making it declarative reduces the cost of every future dashboard feature.
