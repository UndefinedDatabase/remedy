# Tasks — AAA Job Fulfillment Pipeline

## Task 01: Goal-Driven Task Planner with LLM Decomposition

Impact: High
Effort: High

Context:
`job_runner.py:plan_job()` (line 46) always creates the same 3 hardcoded planning tasks (`analyze_requirements`, `define_acceptance_checks`, `prepare_implementation_plan`) regardless of the user's actual goal. `job_fulfillment.py:fixture_plan_tasks()` (line 269) creates 2 hardcoded fixture tasks. No module decomposes a human goal into bounded, actionable sub-tasks.

Problem:
A real job cannot start from a human goal ("add error handling to the auth module") and produce a clear, bounded task plan. The planning phase is deterministic boilerplate that never inspects the goal or the target repo.

Goal:
Build a `goal_task_planner.py` module in `packages/orchestration/` that takes a human goal string + a repo manifest (file list, project type, test setup) and produces a ranked list of bounded task descriptors. Each task descriptor must include: description, task_type, estimated_complexity (low/medium/high), required_context_hints (file patterns), dependencies (task IDs), and acceptance_criteria. The planner should work in two modes: (1) LLM-backed via `worker_adapters.py` for real jobs, (2) deterministic for fixture/test jobs. The output must be a list of `TaskDescriptor` dataclasses, not raw dicts.

Relevant areas:
- packages/orchestration/job_runner.py
- packages/orchestration/job_fulfillment.py (fixture_plan_tasks)
- packages/orchestration/worker_adapters.py
- packages/orchestration/context_inspector.py (repo manifest source)

Proposed changes:
- Create `packages/orchestration/goal_task_planner.py` with `TaskDescriptor` dataclass and `plan_tasks_from_goal()` function
- Add a `PlannerMode` enum (fixture, local_llm, cloud_llm) with routing to `worker_adapters.py` for LLM calls
- Build a `repo_manifest()` helper that produces a safe, bounded summary of the target repo (file tree, project type, test framework, key config) using `context_inspector.py`
- Wire into `job_fulfillment.py:run_job_fulfill()` to replace `fixture_plan_tasks()` in real mode
- Add a CLI command `remedy job plan <job_id> --json` to inspect the generated plan before execution
- Add tests in `tests/orchestration/test_goal_task_planner.py`

Acceptance criteria:
- Given a goal string and a repo path, `plan_tasks_from_goal()` returns 1-10 bounded `TaskDescriptor` objects
- Each `TaskDescriptor` has description, task_type, complexity, context_hints, dependencies, acceptance_criteria
- Fixture mode produces deterministic output identical to current `fixture_plan_tasks()` behavior
- LLM mode produces a structured plan by sending the goal + repo manifest to a worker adapter
- No LLM call is made without explicit mode selection; fixture mode is default
- `remedy job plan <job_id> --json` shows the generated plan

Priority rationale:
Planning is the first step in every job. Without goal-driven planning, all downstream steps (prompts, context, routing) operate on meaningless boilerplate. This is the foundation that every other task depends on.

---

## Task 02: Bounded Worker Prompt Generator

Impact: High
Effort: Medium

Context:
`job_fulfillment.py:fixture_worker_output()` (line 342) returns hardcoded content for each task. No module generates structured, task-specific prompts that tell a worker exactly what to do, what context it has, and what output format to produce. The `context_pack.py` module builds job-level summaries but not task-scoped worker instructions.

Problem:
Workers receive no structured prompt. In fixture mode, the "worker" is a hardcoded function. For real jobs, a worker (Claude Code, Ollama, human) needs a bounded prompt: what to do, what files to read, what to produce, what NOT to touch, and the expected output contract.

Goal:
Build a `worker_prompt_builder.py` module that takes a `TaskDescriptor` + a selected context pack + a `WorkerSpec` and produces a `WorkerPrompt` dataclass containing: system_instructions, task_description, context_block, output_contract, forbidden_actions, estimated_token_budget, and metadata. The prompt must be the smallest sufficient instruction for the task.

Relevant areas:
- packages/orchestration/job_fulfillment.py (fixture_worker_output)
- packages/orchestration/context_pack.py
- packages/orchestration/worker_registry.py (WorkerSpec)
- packages/orchestration/worker_adapters.py

Proposed changes:
- Create `packages/orchestration/worker_prompt_builder.py` with `WorkerPrompt` dataclass and `build_worker_prompt()` function
- Implement context selection: given `TaskDescriptor.context_hints` (file patterns), select only the relevant source files from the repo, truncated to the worker's context budget
- Add an `output_contract` field that specifies the expected output format (structured patch, code diff, explanation, etc.)
- Add `forbidden_actions` derived from `RunContract.denied_actions`
- Wire into the fulfillment spine to replace fixture worker calls in real mode
- Add tests in `tests/orchestration/test_worker_prompt_builder.py`

Acceptance criteria:
- `build_worker_prompt()` takes a TaskDescriptor, context items, and WorkerSpec and returns a WorkerPrompt
- The prompt includes only task-relevant context (not the entire repo)
- The prompt specifies the expected output format
- The prompt's estimated token count is within the worker's context budget
- The prompt includes forbidden actions from the RunContract

Priority rationale:
Bounded prompts are the interface between Remedy's planning and worker execution. Without them, workers cannot receive meaningful instructions. Depends on Task 01 (TaskDescriptor).

---

## Task 03: Task-Scoped Minimal Context Selector

Impact: High
Effort: Medium

Context:
`context_pack.py:build_context_pack()` (line 240) builds job-level packs with 8 fixed sections (job_summary, task_state, blockers, etc.). `token_economy.py:recommend_context_pack()` (line 433) recommends a pack KIND (minimal/focused/balanced/full) but does not select which source files a specific task needs. `context_inspector.py` can inspect a job's context but doesn't do task-scoped file selection.

Problem:
Every task gets the same job-level context regardless of what it actually needs. A task to "fix the auth middleware" should get auth-related files, not the entire project summary. Token waste is proportional to irrelevant context.

Goal:
Build a `task_context_selector.py` module that takes a `TaskDescriptor` (with `context_hints` file patterns) + a repo path + a token budget and returns a `TaskContextPack` containing only the files, functions, and docs relevant to that specific task, compressed to fit the budget. The selector must respect `RunContract.denied_paths` and never include secrets or protected files.

Relevant areas:
- packages/orchestration/context_pack.py
- packages/orchestration/context_inspector.py
- packages/orchestration/token_economy.py (budget profiles, estimates)
- packages/orchestration/run_contract.py (denied_paths)

Proposed changes:
- Create `packages/orchestration/task_context_selector.py` with `TaskContextPack` dataclass and `select_task_context()` function
- Implement file pattern matching: resolve `context_hints` (e.g., `["src/auth/**", "tests/test_auth*"]`) against the repo tree
- Implement budget-aware truncation: prioritize by relevance (exact match > directory match > related imports), truncate to fit budget
- Integrate `RunContract.denied_paths` to exclude secrets and protected files
- Provide `estimate_task_context_tokens()` that returns the token count without reading file contents
- Wire into `worker_prompt_builder.py` to feed context into worker prompts
- Add tests

Acceptance criteria:
- Given a TaskDescriptor with `context_hints=["src/auth/**"]` and a repo, returns only auth-related files
- Token count of returned context is within the specified budget
- Denied paths from RunContract are never included
- Protected files (`.env`, `credentials.json`, etc.) are always excluded
- Returns empty context (not an error) when no files match the hints

Priority rationale:
Minimal context selection directly reduces token cost and improves worker output quality. It's the key mechanism for "pass only the smallest task-relevant context." Depends on Task 01 (TaskDescriptor.context_hints).

---

## Task 04: Cost-Aware Route Splitter

Impact: High
Effort: Medium

Context:
`token_economy.py:compute_token_economy_decision()` (line 563) produces a recommendation (which worker, budget status, approval required) but the fulfillment spine ignores it — all tasks go through the same fixture path. `worker_registry.py:evaluate_worker_selection()` (line 721) evaluates eligibility but never routes work. The `RoutePolicy` (line 436) has `prefer_local_for_cheap_tasks` and `require_human_approval_for_expensive` flags that are metadata-only.

Problem:
Cheap, repetitive tasks (fix a typo, update a version number) use the same expensive model as architecture-level design decisions. There is no mechanism to split tasks by cost/risk and route them to appropriate workers.

Goal:
Build a `route_splitter.py` module that takes a list of `TaskDescriptor`s + their `TaskContextPack` token estimates + the `RoutePolicy` and produces a `RoutePlan` that assigns each task to a worker route (local_llm, cloud_llm, human, fixture). The splitter must enforce: cheap/small/low-risk tasks prefer local; expensive/ambiguous/high-risk/architecture tasks go to frontier models; unknown-cost tasks require human approval.

Relevant areas:
- packages/orchestration/token_economy.py (compute_token_economy_decision)
- packages/orchestration/worker_registry.py (evaluate_worker_selection, RoutePolicy)
- packages/orchestration/job_fulfillment.py (fulfillment loop)

Proposed changes:
- Create `packages/orchestration/route_splitter.py` with `RoutePlan`, `TaskRoute` dataclasses and `split_routes()` function
- For each task: compute estimated context tokens, call `compute_token_economy_decision()`, map the decision to a concrete route
- Produce a human-readable route reasoning for each task (why this route was chosen)
- Never auto-route unknown/expensive tasks — set `requires_human_approval=True`
- Add a CLI command `remedy job routes <job_id> --json` to preview the route plan
- Add tests

Acceptance criteria:
- Tasks with context < 8k tokens and low complexity get routed to local workers when available
- Tasks with high complexity or context > 32k tokens get routed to frontier models
- Unknown-cost tasks always set `requires_human_approval=True`
- Each `TaskRoute` includes a human-readable `route_reasoning` string
- The route plan respects `RoutePolicy.blocked_worker_ids` and `max_cost_tier`

Priority rationale:
Route splitting is the primary mechanism for token cost reduction. Without it, every task burns frontier-model tokens. Depends on Tasks 01, 03 (TaskDescriptor + context estimates).

---

## Task 05: Untrusted Worker Output Collector and Per-Task Reviewer

Impact: High
Effort: Medium

Context:
`job_fulfillment.py` (lines 640-678) collects worker output and creates artifacts, but the fixture review (`fixture_review()`, line 381) is a hardcoded pass/fail that never inspects the actual output. `review_bundle.py` provides review evidence collection but is not integrated into the fulfillment spine's per-task review loop. Workers' `Done:` markers are not treated as reviewer-verified passes (per `repair_loop_v2.py` honesty rules).

Problem:
Worker outputs are trusted by default in the fulfillment spine. There is no structured review of each task's output against the task's acceptance criteria. The existing review_bundle and repair_loop_v2 machinery exists but is disconnected from fulfillment.

Goal:
Build a `task_reviewer.py` module that takes a worker output artifact + the original `TaskDescriptor` (with acceptance criteria) + the task context and produces a `TaskReviewResult` with: verdict (pass/finding/reject), findings list (each with code, severity, repair_reason), and evidence references. When findings exist, convert them to repair task descriptors using the existing `finding_to_repair_task()` pattern. The reviewer should run as a separate worker call (not the same model that generated the output) when possible.

Relevant areas:
- packages/orchestration/job_fulfillment.py (fixture_review, finding_to_repair_task)
- packages/orchestration/review_bundle.py
- packages/orchestration/repair_loop_v2.py (create_repair_item_from_review_finding)
- packages/orchestration/worker_registry.py (reviewer.parallel spec)

Proposed changes:
- Create `packages/orchestration/task_reviewer.py` with `TaskReviewResult` dataclass and `review_task_output()` function
- Implement acceptance criteria checking: compare output against `TaskDescriptor.acceptance_criteria`
- Generate findings with structured codes, severities, and repair reasons
- Convert findings to repair task descriptors (reuse `finding_to_repair_task()` pattern)
- Route review to the `reviewer.parallel` worker spec when available
- Wire into the fulfillment spine's review phase
- Add tests

Acceptance criteria:
- `review_task_output()` produces a verdict and structured findings for any worker output
- Findings include severity, code, summary, and repair_reason
- Findings with severity >= medium are automatically converted to repair task descriptors
- The reviewer is a separate worker invocation from the builder (separation of concerns)
- `Done:` markers in builder output are NOT treated as reviewer pass (honesty rule)

Priority rationale:
Untrusted output review is the quality gate that prevents bad worker output from reaching the repo. Without it, the pipeline trusts whatever the worker produces. Depends on Tasks 01, 02 (TaskDescriptor, WorkerPrompt for reviewer).

---

## Task 06: Worker/Reviewer Repair Loop Integration

Impact: High
Effort: Medium

Context:
`repair_loop_v2.py` has a full repair state machine (NEW -> CONTEXT_NEEDED -> READY_FOR_ROUTE -> WAITING_FOR_CANDIDATE -> ... -> REPAIRED), context packs (`build_repair_context_pack()`), route recommendations (`recommend_repair_route()`), and bounded evaluation (`evaluate_repair_loop()`). But this is completely disconnected from `job_fulfillment.py` which has its own simple repair: `fixture_repair_output()` + second `fixture_review()`.

Problem:
The fulfillment spine and the repair loop are two separate systems. AAA requires: when a task review produces findings, create repair work items via `repair_loop_v2`, run worker/reviewer loops until all findings pass (bounded by `RepairLoopPolicy.max_attempts`), then continue to apply/test/proof.

Goal:
Integrate `repair_loop_v2` into the fulfillment spine so that review findings from `task_reviewer.py` create `RepairWorkItem`s, each driven through the repair loop's state machine. The repair loop's bounded execution (max_attempts, max_retests, stop_on_repeated_failure) governs how many repair cycles each finding gets.

Relevant areas:
- packages/orchestration/job_fulfillment.py (repair phase, lines 687-741)
- packages/orchestration/repair_loop_v2.py (full module)
- packages/orchestration/task_reviewer.py (from Task 05)

Proposed changes:
- In `job_fulfillment.py`, replace the fixture repair phase with calls to `repair_loop_v2`:
  - For each finding: `create_repair_item_from_review_finding()` or `create_repair_item_from_failure_artifact()`
  - Build repair context: `build_repair_context_pack()`
  - Recommend route: `recommend_repair_route()`
  - After worker produces repair candidate: run through `task_reviewer.py` again
  - Evaluate: `evaluate_repair_loop()` — if not REPAIRED and under max_attempts, loop
  - If BLOCKED or ABANDONED: record in fulfillment record and stop
- Add repair loop iteration tracking to `JobFulfillmentRecord`
- Add repair loop policy defaults for job fulfillment (max_attempts=3, max_retests=3)
- Add tests for the integrated flow

Acceptance criteria:
- Review findings create `RepairWorkItem`s via `repair_loop_v2`
- Each repair item is driven through the repair state machine (bounded by policy)
- Repair loop stops after `max_attempts` and reports BLOCKED status
- Repaired items have durable evidence (reviewer pass + apply proof + retest green per policy)
- `JobFulfillmentRecord` tracks repair_loop_iterations and per-item repair status

Priority rationale:
The repair loop is what makes the pipeline self-correcting. Without integration, review findings are dead ends. Depends on Task 05 (TaskReviewResult).

---

## Task 07: Isolated Sandbox Apply/Test/Proof Gate

Impact: High
Effort: High

Context:
`workspace.py:LocalWorkspaceRuntime` (line 62) provides isolated file writes per job, but `job_fulfillment.py:_approve_and_apply_intent()` (line 530) applies patches directly to `repo_root` via `patch_apply.apply_patch_intent()`. Tests run against the real repo. If apply or test fails, the real repo is left in a modified state.

Problem:
Changes are applied to the real repo before verification. A failing test after apply leaves the repo dirty. AAA requires: apply in isolated workspace, run tests in isolated workspace, build proof, only then apply to real repo (or rollback).

Goal:
Build a `sandbox_gate.py` module that creates a temporary isolated copy of the repo (git worktree or temp directory), applies all approved patch intents there, runs tests there, builds proof there, and only touches the real repo if all gates pass. On failure, the sandbox is discarded and the real repo is untouched.

Relevant areas:
- packages/orchestration/workspace.py (LocalWorkspaceRuntime)
- packages/orchestration/job_fulfillment.py (_approve_and_apply_intent, test phase)
- packages/orchestration/patch_apply.py (apply_patch_intent)
- packages/orchestration/test_execution_service.py (execute_test_run)
- packages/orchestration/proof_chain.py (build_proof_chain)
- packages/orchestration/repository_snapshot.py (snapshot/rollback)

Proposed changes:
- Create `packages/orchestration/sandbox_gate.py` with `SandboxResult` dataclass and `run_in_sandbox()` function
- Implement sandbox creation: `git worktree add` to a temp directory (or `shutil.copytree` as fallback)
- Apply all patch intents in the sandbox via existing `patch_apply`
- Run tests in the sandbox via existing `test_execution_service` (with sandbox repo as working directory)
- Build proof in the sandbox via existing `proof_chain`
- If all pass: apply to real repo and clean up sandbox
- If any fail: discard sandbox, record failure in `JobFulfillmentRecord`, real repo untouched
- Wire into `job_fulfillment.py` to replace direct apply
- Add tests

Acceptance criteria:
- All patch applies happen in a sandbox (temp directory or git worktree), not in the real repo
- Tests run against the sandbox repo, not the real repo
- If tests fail in sandbox, the real repo is completely untouched
- If all gates pass, changes are applied to the real repo (via the existing patch_apply mechanism)
- Sandbox is cleaned up after use (success or failure)
- `SandboxResult` includes: sandbox_path, apply_results, test_results, proof_status, final_verdict

Priority rationale:
Sandbox isolation is the safety gate that prevents repo corruption. Without it, failed applies leave the repo dirty. Independent of Tasks 01-06 (can be implemented in parallel).

---

## Task 08: Job Fulfillment Report Generator

Impact: Medium
Effort: Medium

Context:
`job_fulfillment.py:summarize_job_fulfillment()` (line 206) produces a 12-line status dump. `export_job_fulfillment_json()` (line 171) exports raw record fields. Neither produces the AAA-required decision trail: every task, selected context, worker route, token/cost reasoning, review findings, repair attempts, test results, proof status, and final verdict.

Problem:
After a job completes (or blocks), the operator has no comprehensive view of what happened, why each decision was made, and what to do next. The current summary is a status dump, not a decision report.

Goal:
Build a `fulfillment_report.py` module that takes a completed `JobFulfillmentRecord` + all associated evidence (task plans, context selections, route decisions, worker outputs, review results, repair attempts, test runs, proof chains) and produces a `FulfillmentReport` with structured sections and a human-readable markdown rendering.

Relevant areas:
- packages/orchestration/job_fulfillment.py (summarize_job_fulfillment, export_job_fulfillment_json)
- packages/orchestration/token_economy.py (token_economy_report)
- packages/orchestration/review_bundle.py
- packages/orchestration/proof_chain.py
- apps/cli/commands/job.py (CLI rendering)

Proposed changes:
- Create `packages/orchestration/fulfillment_report.py` with `FulfillmentReport`, `TaskReport`, `RouteReport` dataclasses
- Each `TaskReport` includes: task_descriptor, selected_context_summary, worker_route, token_cost_reasoning, worker_output_summary, review_verdict, review_findings, repair_attempts, test_results
- Add a job-level summary: overall status, total token estimate, total cost estimate, proof status, contract check result
- Add a `next_recommended_tasks` section with ranked suggestions
- Render as structured JSON (`export_fulfillment_report_json()`) and human-readable markdown (`render_fulfillment_report_md()`)
- Add CLI command `remedy job report <job_id> --full --json` that produces the complete report
- Add tests

Acceptance criteria:
- The report includes every task with its context, route, cost reasoning, review, repair, and test results
- The report includes a decision trail for each task (why this route was chosen, why this context was selected)
- The report renders as both JSON (for programmatic use) and markdown (for human reading)
- The report includes ranked next-task recommendations
- No raw content, secrets, or absolute paths appear in the report (redaction via `_scrub_public()`)

Priority rationale:
The report is the human interface to the pipeline's decisions. Without it, the operator cannot understand or audit what happened. Depends on Tasks 01-06 (data to report on), but can be stubbed early.

---

## Task 09: Ranked Next-Task Recommendation Engine

Impact: Medium
Effort: Medium

Context:
`job_fulfillment.py:_generate_next_suggestions()` (line 444) creates 3 hardcoded `ProposedTask` entries ("Add more test coverage", "Improve documentation", "Configure real worker path"). These are generic suggestions unrelated to the actual job outcome. The `ProposedTask` model in `proposed_tasks.py` supports priority, risk, and source fields but they are set to fixed values.

Problem:
After a job completes, the operator gets generic suggestions instead of evidence-based recommendations ranked by impact. AAA requires: recommendations derived from actual review findings, test gaps, coverage data, proof chain gaps, and repair loop outcomes — with approve/reject/defer/backlog user actions.

Goal:
Build a `next_task_recommender.py` module that analyzes the completed job's evidence (review findings, test results, coverage gaps, proof chain status, repair outcomes) and produces ranked `RecommendedTask` entries. Each recommendation includes: title, evidence_source, impact_estimate, effort_estimate, and user_actions (approve/reject/defer/backlog).

Relevant areas:
- packages/orchestration/job_fulfillment.py (_generate_next_suggestions)
- packages/orchestration/proposed_tasks.py (ProposedTask model)
- packages/orchestration/repair_loop_v2.py (repair_loop_mission_signal)
- packages/orchestration/proof_chain.py (proof chain gaps)
- apps/cli/commands/propose_cmd.py (existing propose CLI)

Proposed changes:
- Create `packages/orchestration/next_task_recommender.py` with `RecommendedTask` dataclass and `recommend_next_tasks()` function
- Analyze review findings: unresolved low-severity findings become improvement suggestions
- Analyze test results: untested paths become test coverage recommendations
- Analyze proof chain: incomplete proof areas become verification recommendations
- Analyze repair loop: blocked/abandoned repairs become escalation recommendations
- Rank by impact (high/medium/low) and effort (high/medium/low)
- Add user actions: `remedy propose approve/reject/defer/backlog <task_id>`
- Wire into the fulfillment spine's completion phase (replace `_generate_next_suggestions()`)
- Add tests

Acceptance criteria:
- Recommendations are derived from actual job evidence (not hardcoded)
- Each recommendation has an evidence source reference
- Recommendations are ranked by estimated impact
- User can approve, reject, defer, or send to backlog via CLI
- At least one recommendation is always generated (even for perfect jobs: "no issues found, consider expanding scope")

Priority rationale:
Next-task recommendations close the feedback loop from job completion to the next job. Without evidence-based ranking, operators get noise instead of signal. Depends on completed fulfillment data.

---

## Task 10: End-to-End Fulfillment Integration Test with Real Worker Adapter

Impact: Medium
Effort: High

Context:
`tests/orchestration/test_job_fulfillment.py` tests the fixture-demo flow. The `main_builder_adapter.py` and `managed_builder_execution.py` modules provide real worker adapter infrastructure (command templates, session management, output intake) but are not connected to the fulfillment spine. The test suite has no integration test that runs Goal -> Plan -> Prompt -> Context -> Route -> Worker -> Review -> Repair -> Apply -> Test -> Proof -> Report end-to-end with a real worker adapter.

Problem:
The fulfillment spine is tested only in fixture mode. No test verifies the complete pipeline with real context selection, real worker routing, real review, and real repair loops. Without this, refactoring any component risks breaking the full flow silently.

Goal:
Build an end-to-end integration test that exercises the full AAA fulfillment pipeline using a mock worker adapter (returns deterministic but realistic output) against a real test repo. The test must verify: goal decomposition, context selection, route splitting, worker prompt generation, output collection, review, repair loop (at least one finding + repair cycle), sandbox apply/test, proof chain, report generation, and next-task recommendations.

Relevant areas:
- tests/orchestration/test_job_fulfillment.py (existing fixture tests)
- packages/orchestration/job_fulfillment.py (full spine)
- packages/orchestration/main_builder_adapter.py (worker adapter)
- packages/orchestration/managed_builder_execution.py (execution templates)
- All modules from Tasks 01-09

Proposed changes:
- Create `tests/orchestration/test_fulfillment_e2e.py` with a mock worker adapter that returns realistic (but deterministic) output
- Create a test repo fixture with: Python source, tests, pyproject.toml, a known bug to fix
- Test the full pipeline: job create -> plan_tasks_from_goal() -> build_worker_prompt() -> select_task_context() -> split_routes() -> mock worker output -> review_task_output() -> repair loop (one cycle) -> sandbox apply/test -> proof chain -> fulfillment report -> next task recommendations
- Verify each phase's outputs match expected contracts
- Verify the final report contains all decision trail data
- Verify the sandbox protects the real test repo from partial failures
- Add to the CI test suite

Acceptance criteria:
- The test runs the full pipeline end-to-end (not fixture mode)
- At least one review finding triggers a repair cycle
- The sandbox gate protects the test repo from failure-mode corruption
- The final report contains task-level decision trails
- The test runs in < 30 seconds (no real LLM calls, mock adapter only)
- The test is part of the standard `pytest` suite

Priority rationale:
Integration testing validates that all components work together. Without it, individual component tests pass but the pipeline fails at integration points. Depends on Tasks 01-09 (all components), so this should be built last but tracked from the start.
