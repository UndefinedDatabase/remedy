# Sources

## Code read
- packages/orchestration/job_fulfillment.py (full, 864 lines)
- packages/orchestration/job_runner.py (full, 95 lines)
- packages/orchestration/token_economy.py (full, 797 lines)
- packages/orchestration/worker_registry.py (full, 1034 lines)
- packages/orchestration/context_pack.py (full, 318 lines)
- packages/orchestration/repair_loop_v2.py (full, 1168 lines)
- packages/orchestration/run_contract.py (full, 1030 lines)
- packages/orchestration/workspace.py (full, 112 lines)
- docs/core-product-spine-v0.md (full)
- AGENTS.md (full)

## File listings
- packages/orchestration/ — 80 Python modules
- apps/cli/commands/ — 55 command modules
- tests/ — 170 test files
- docs/ — 80 design documents
