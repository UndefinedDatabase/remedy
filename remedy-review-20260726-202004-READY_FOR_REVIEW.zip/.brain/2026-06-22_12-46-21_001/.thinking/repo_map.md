# Repo Map

## Core orchestration (packages/orchestration/)
- job_fulfillment.py — fixture-demo spine: plan -> work -> review -> repair -> apply -> test -> proof -> final review -> complete
- job_runner.py — plan_job() with hardcoded 3-task planning template
- token_economy.py — token budget profiles, context budget estimates, route cost recommendations (estimates only)
- worker_registry.py — WorkerSpec catalog, RoutePolicy, worker selection evaluation (metadata only)
- context_pack.py — budget-aware context pack builder (job summary, task state, blockers, proof, etc.)
- repair_loop_v2.py — token-aware repair loop: failure artifact -> context -> route -> candidate -> review -> apply -> retest
- run_contract.py — execution boundary definition (allowed/denied actions, budgets, paths)
- review_bundle.py — review evidence collection
- workspace.py — isolated workspace for job file writes
- patch_apply.py — patch intent approval and application
- test_execution_service.py — test runner service
- proof_chain.py — proof chain builder
- worker_adapters.py — worker adapter layer
- overnight_executor.py — overnight loop executor
- overnight_mission.py — mission contract state machine

## CLI (apps/cli/)
- main.py — CLI entry point
- commands/job.py — job commands
- commands/worker.py — worker commands
- ~55 command modules

## UI (apps/ui/)
- React+TypeScript dashboard cockpit

## Tests (tests/)
- ~170 test files across orchestration, CLI, UI contracts, regression

## Docs (docs/)
- ~80 design/user-guide documents
