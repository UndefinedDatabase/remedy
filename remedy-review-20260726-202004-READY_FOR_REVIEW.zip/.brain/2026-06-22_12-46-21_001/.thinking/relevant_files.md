# Relevant Files for AAA Job Fulfillment

## Primary (must change)
- packages/orchestration/job_fulfillment.py — fixture-only; needs real planner, real worker prompts, real context selection
- packages/orchestration/job_runner.py — hardcoded plan_job(); needs goal-driven LLM planning
- packages/orchestration/context_pack.py — builds job-level packs; needs task-scoped minimal context selection
- packages/orchestration/token_economy.py — estimates exist; needs real routing integration into fulfillment
- packages/orchestration/worker_registry.py — has specs; needs real route execution bridge
- packages/orchestration/workspace.py — has isolated workspace model; needs sandbox gate (apply/test before real repo)

## Secondary (integration targets)
- packages/orchestration/repair_loop_v2.py — repair loop exists; needs integration into fulfillment
- packages/orchestration/run_contract.py — contract gating exists; needs fulfillment-level contract enforcement
- packages/orchestration/review_bundle.py — review exists; needs per-task worker output review
- packages/orchestration/patch_apply.py — apply mechanism exists; needs isolated workspace first
- packages/orchestration/test_execution_service.py — test runner exists; needs sandbox test execution
- packages/orchestration/proof_chain.py — proof chain exists; needs fulfillment-level proof
- packages/orchestration/overnight_mission.py — mission contract exists; needs fulfillment integration

## Docs (design references)
- docs/core-product-spine-v0.md — current product definition
- docs/architecture.md — full architecture
- docs/token-economy-context-budget-optimizer-v0.md — token economy design
- docs/worker-registry-route-policy-v0.md — worker routing design
