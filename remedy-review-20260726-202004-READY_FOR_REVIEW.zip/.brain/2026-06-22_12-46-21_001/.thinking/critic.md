# Critic Review

## Removed ideas (too generic)
- "Add logging" — not an AAA gap, just infrastructure
- "Improve error handling" — not specific to the goal
- "Add more tests" — tests should follow implementation, not be a separate brainstorm task
- "Refactor X module" — refactoring alone doesn't advance the goal

## Evidence quality check
- Every gap maps to specific files and line ranges in the codebase
- Each gap has a concrete "what exists" vs "what's needed" comparison
- No gap relies on assumed future architecture — all build on existing modules
- Priority ordering reflects dependency chain: planning must precede prompts, prompts must precede routing, etc.

## Risk assessment
- Gap 1 (LLM planning) introduces a provider dependency — mitigated by keeping it behind worker_adapters.py
- Gap 4 (routing bridge) is the riskiest — connecting metadata-only routing to real execution. Must preserve all safety gates.
- Gap 7 (sandbox) requires git worktree or temp copy — must not corrupt the real repo on failure
- Gaps 2, 3, 5 are pure orchestration logic — lowest risk, highest immediate value

## Dependency chain
1 (planning) → 2 (prompts) → 3 (context) → 4 (routing) → 5 (cost splitting) → 6 (untrusted review) → 7 (sandbox) → 8 (report) → 9 (next tasks) → 10 (repair integration)

Some tasks can run in parallel (e.g., 7 and 8 are independent of each other).
