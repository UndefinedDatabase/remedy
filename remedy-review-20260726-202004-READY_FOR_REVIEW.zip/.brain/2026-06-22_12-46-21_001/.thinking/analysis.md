# Analysis: AAA Job Fulfillment Gap Assessment

## Current state

The fulfillment spine (`job_fulfillment.py`) runs end-to-end but only in **fixture-demo mode**:
- Planning uses `fixture_plan_tasks()` — hardcoded 2 tasks, no LLM, no goal decomposition
- Worker output uses `fixture_worker_output()` — deterministic strings, no real model call
- Review uses `fixture_review()` — deterministic pass/fail, no real output inspection
- Repair uses `fixture_repair_output()` — deterministic fix, no real repair reasoning
- Apply goes through real `patch_apply` but with fixture content
- Test goes through real `test_execution_service` but on a demo repo
- Proof goes through real `proof_chain` but gets `accepted` with reason (not `verified`)

## Gaps to AAA (10 concrete gaps)

### Gap 1: No goal-driven task planning
`plan_job()` in `job_runner.py` always creates the same 3 tasks regardless of the user's goal.
There is no LLM-powered decomposition of "add error handling to the auth module" into bounded sub-tasks.

### Gap 2: No bounded worker prompts
No module generates task-specific prompts from the task plan. Fixture mode uses hardcoded content.
AAA needs: given a task descriptor + selected context, produce a structured worker prompt with clear boundaries.

### Gap 3: No task-relevant context selection
`context_pack.py` builds a **job-level** pack (summary, task state, blockers). It does not select
which source files, functions, or docs a specific task needs. Token economy estimates exist but
don't drive actual context selection.

### Gap 4: No real model routing bridge
`worker_registry.py` evaluates which worker to use (metadata-only) but never actually routes work
to a model. Ollama and cloud workers are placeholders. The bridge from "recommend worker X" to
"send this prompt to worker X and collect output" does not exist in the fulfillment spine.

### Gap 5: No cost-aware route splitting
Token economy can estimate bands (low/medium/high) and recommend local-first for cheap tasks,
but the fulfillment spine doesn't use these to split tasks between cheap and expensive routes.
All tasks go through the same fixture path.

### Gap 6: Worker outputs not treated as untrusted artifacts
The fixture spine trusts worker output directly. AAA requires: collect output as untrusted artifact,
run reviewer prompt, convert findings to repair tasks, repeat until pass.

### Gap 7: No isolated sandbox for apply/test/proof
`workspace.py` provides isolated file writes per job, but the fulfillment spine applies patches
directly to `repo_root`. AAA needs: apply in sandbox copy, run tests in sandbox, verify proof,
only then touch real repo.

### Gap 8: No job-level human-readable report
`summarize_job_fulfillment()` produces a basic status dump. AAA needs a full decision trail:
every task, selected context, worker route, token/cost reasoning, review findings, repair attempts,
test results, proof status, and decisions.

### Gap 9: No ranked next-task recommendations with user actions
`_generate_next_suggestions()` creates 3 hardcoded `ProposedTask` entries. AAA needs: ranked
recommendations derived from actual job evidence, with approve/reject/defer/backlog user actions.

### Gap 10: No fulfillment-level repair loop integration
`repair_loop_v2.py` is a standalone state machine (failure -> context -> route -> candidate -> review ->
apply -> retest). The fulfillment spine has its own simple repair (fixture_repair_output). These are
not connected. AAA needs the fulfillment spine to drive the real repair loop for each finding.
