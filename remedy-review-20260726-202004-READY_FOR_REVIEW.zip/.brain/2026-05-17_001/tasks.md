# Reorganization Tasks

10 concrete, prioritized engineering tasks to make Remedy the best-structured, most
human-friendly Python repository it can be. Every task is grounded in direct evidence
from the codebase.

---

## Task 01: Split `apps/cli/main.py` into Command Modules

Impact: High
Effort: Medium

Context:
`apps/cli/main.py` is a 1720-line monolith containing 30+ command handler functions
as top-level functions, all argument parser wiring, and a 65-line `if/elif` dispatch
chain (lines 1652–1716). This is the single biggest friction point for any developer
trying to add, debug, or understand a CLI command.

Problem:
Adding a new command means reading and editing a 1720-line file. Every `_cmd_*`
function (e.g., `_cmd_brain`, `_cmd_apply_patch_intent`, `_cmd_project_context`)
lives in one flat namespace with no grouping. The if/elif dispatch at line 1652 must
be extended each time. No command can be imported or tested in isolation.

Goal:
Break the file into a `apps/cli/commands/` package with one module per command group.
`main.py` becomes a thin 50-line dispatcher that imports from `commands/`.

Relevant areas:
- [apps/cli/main.py](apps/cli/main.py) (entire file)
- [apps/cli/__init__.py](apps/cli/__init__.py)

Proposed changes:
- Create `apps/cli/commands/__init__.py`
- Create `apps/cli/commands/job.py` — `_cmd_create_job`, `_cmd_list_jobs`, `_cmd_show_job`, `_cmd_plan_job`, `_cmd_plan_job_local`
- Create `apps/cli/commands/execution.py` — `_cmd_run_next_task_local`, `_cmd_attach_repo`, `_cmd_set_permission`, `_cmd_show_permissions`
- Create `apps/cli/commands/patch.py` — `_cmd_list_patch_intents`, `_cmd_show_patch_intent`, `_cmd_approve_patch_intent`, `_cmd_reject_patch_intent`, `_cmd_apply_patch_intent`
- Create `apps/cli/commands/brain.py` — `_cmd_brain`, `_cmd_brain_node`, `_cmd_brain_view`, `_cmd_context`, `_cmd_agent_loop`
- Create `apps/cli/commands/project.py` — `_cmd_create_project`, `_cmd_list_projects`, `_cmd_show_project`, `_cmd_attach_project_repo`, `_cmd_attach_project_job`, `_cmd_project_context`
- Create `apps/cli/commands/reporting.py` — `_cmd_timeline`, `_cmd_cockpit`, `_cmd_trust_report`, `_cmd_constitution`
- Rewrite `apps/cli/main.py` to import from `commands/` and contain only `build_parser()` + `main()`
- Move argument parser definitions adjacent to their handler modules (each `commands/*.py` exports a `register(subparsers)` function)

Acceptance criteria:
- `pytest` passes with no changes to any test file
- `apps/cli/main.py` is under 100 lines
- Each command file in `commands/` is independently importable
- `remedy --help` and all subcommands produce identical output before and after
- No command handler function exists in `main.py`; they all live in `commands/`

Priority rationale:
This is the single most impactful structural change for human-friendliness. Every
developer who wants to understand, fix, or add a CLI command must currently navigate
a 1720-line file. Splitting it makes the codebase immediately navigable by directory.

---

## Task 02: Consolidate `data_dir` Resolution into a Shared Utility

Impact: High
Effort: Medium

Context:
The pattern of resolving the data directory from `REMEDY_DATA_DIR` env var appears
11+ times across the codebase — 8 inline occurrences in `apps/cli/main.py` (in
`_cmd_cockpit`, `_cmd_timeline`, `_cmd_trust_report`, `_cmd_brain`, `_cmd_brain_node`,
`_cmd_context`, `_cmd_brain_view`, `_cmd_agent_loop`), plus 3 independent resolver
functions in `storage.py::_resolve_data_dir()`, `run_log.py::_resolve_runs_root()`,
and `project_registry.py::_resolve_projects_dir()`. Each uses the same pattern but
hardcodes a different subdirectory suffix.

Problem:
Any change to the env var name, resolution logic, or fallback path requires updating
11+ sites. The `parent.parent.parent` chain is fragile — moving any module breaks it.
The inline snippets in `main.py` each compute the same `Path(__file__).resolve().parent.parent.parent / ".data"` base independently.

Goal:
Create `packages/orchestration/data_paths.py` as the single canonical resolver.
All other modules import from it.

Relevant areas:
- [apps/cli/main.py](apps/cli/main.py) (8 inline occurrences)
- [packages/orchestration/storage.py](packages/orchestration/storage.py) (`_resolve_data_dir`)
- [packages/orchestration/run_log.py](packages/orchestration/run_log.py) (`_resolve_runs_root`)
- [packages/orchestration/project_registry.py](packages/orchestration/project_registry.py) (`_resolve_projects_dir`)

Proposed changes:
- Create `packages/orchestration/data_paths.py` with:
  ```python
  def resolve_data_root() -> Path:
      """Single authoritative resolver for REMEDY_DATA_DIR."""
      env = os.environ.get("REMEDY_DATA_DIR")
      if env:
          return Path(env)
      return Path(__file__).resolve().parents[2] / ".data"

  def jobs_dir(root: Path | None = None) -> Path:
      return (root or resolve_data_root()) / "jobs"

  def runs_dir(root: Path | None = None) -> Path:
      return (root or resolve_data_root()) / "runs"

  def projects_dir(root: Path | None = None) -> Path:
      return (root or resolve_data_root()) / "projects"

  def workspaces_dir(root: Path | None = None) -> Path:
      return (root or resolve_data_root()) / "workspaces"

  def viewers_dir(root: Path | None = None) -> Path:
      return (root or resolve_data_root()) / "viewers"
  ```
- Update `storage.py` to use `from packages.orchestration.data_paths import jobs_dir`
- Update `run_log.py` to use `from packages.orchestration.data_paths import runs_dir`
- Update `project_registry.py` to use `from packages.orchestration.data_paths import projects_dir`
- Update all 8 inline occurrences in `main.py` to use `resolve_data_root()`
- Add tests for `data_paths.py` covering env-var override and default path behavior

Acceptance criteria:
- No inline `os.environ.get("REMEDY_DATA_DIR")` pattern remains in `main.py`
- `_resolve_data_dir`, `_resolve_runs_root`, `_resolve_projects_dir` are removed
- `data_paths.py` is the only file that reads `REMEDY_DATA_DIR`
- `REMEDY_DATA_DIR` override tests pass in `test_storage.py` and `test_run_log.py`

Priority rationale:
11 duplicate sites means 11 places that can drift. Two modules already diverged
(storage returns `.data/jobs` directly while `run_log.py` returns `.data/runs`).
A future env var rename would require hunting down all 11 occurrences.

---

## Task 03: Rewrite `README.md` as a Developer Onboarding Guide

Impact: High
Effort: Medium

Context:
`README.md` is 591 lines structured entirely as a step-by-step implementation
changelog ("Step 1 + 1.5: Foundation", "Step 2 + 2.5: Packaging + CLI + Storage
Hardening", ..., "Step 10: Patch Intent v1"). The actual CLI usage is buried in
step-specific sub-sections. There is no "What Is This?", no "Quick Start", no
"CLI Command Reference", no "Contributing" section at the top level.

Problem:
A developer cloning the repo encounters a 591-line implementation diary. They must
read through 30 steps of implementation history to understand what commands exist.
The "Structure" section (at line 573) appears only after 570 lines of changelogs.

Goal:
Rewrite `README.md` as a first-contact document. Extract the step changelog to
`CHANGELOG.md`. The README should orient a developer in under 5 minutes.

Relevant areas:
- [README.md](README.md) (entire file, 591 lines)

Proposed changes:
- Move current README content to `CHANGELOG.md` (rename the step-by-step history)
- Rewrite `README.md` with this structure:
  1. **What is Remedy** — 1 paragraph (modular orchestration kernel, artifact-driven workflows, providers plug in)
  2. **Quick Start** — 4 commands (clone, install, create-job, run-next-task-local)
  3. **CLI Command Reference** — table: `command | description | key flags`; all 30 commands in one scannable table
  4. **Architecture** — 1-paragraph summary + "See [docs/architecture.md](docs/architecture.md) for full details"
  5. **Configuration** — environment variables table (REMEDY_DATA_DIR, REMEDY_OLLAMA_* vars)
  6. **Project Layout** — the structure block from README.md line 573
  7. **Development** — "See [CONTRIBUTING.md](CONTRIBUTING.md)" pointer
  8. **Changelog** — "See [CHANGELOG.md](CHANGELOG.md)"
- Ensure README.md is under 150 lines total

Acceptance criteria:
- `README.md` is under 150 lines
- `README.md` contains sections: What Is Remedy, Quick Start, CLI Command Reference (table), Architecture, Configuration, Project Layout, Development
- All 30 CLI commands appear in the command reference table
- `CHANGELOG.md` contains the full historical step-by-step content from the old README
- No step-by-step implementation history remains in `README.md`

Priority rationale:
A README is the repo's front door. Every developer, collaborator, or evaluator hits
it first. The current state actively misleads — it looks like a development log, not
a product. This is a pure human-friendliness win with no code risk.

---

## Task 04: Add a `Makefile` with Standard Developer Targets

Impact: High
Effort: Low

Context:
`pyproject.toml` configures only pytest (via `[tool.pytest.ini_options]`). There
are no shortcuts for installing, linting, formatting, type-checking, or running the
smoke test. A developer must remember and type full commands from scratch each time.

Problem:
`pytest` is the only shorthand. No `make test`, `make lint`, `make smoke`, `make install`.
The smoke test at `scripts/remedy_smoke.sh` is invoked differently than pytest,
requires sourcing, and has no standardized entry point. Type-checking and linting
have no configured invocation at all.

Goal:
Create a `Makefile` at the repo root with all standard developer targets. This is
the standard mechanism in Python open-source projects for "how do I do X?"

Relevant areas:
- [pyproject.toml](pyproject.toml) (add optional-dep groups for dev tools)
- [scripts/remedy_smoke.sh](scripts/remedy_smoke.sh) (integrate into smoke target)

Proposed changes:
- Create `Makefile` with targets:
  ```makefile
  .PHONY: install test lint format typecheck smoke clean

  install:
      pip install -e ".[dev,ollama]"

  test:
      pytest

  lint:
      ruff check packages/ apps/ tests/

  format:
      ruff format packages/ apps/ tests/

  typecheck:
      mypy packages/ apps/

  smoke:
      source scripts/remedy_smoke.sh && remedy_smoke

  clean:
      rm -rf .data/jobs .data/runs .data/workspaces .data/projects .data/viewers
      find . -type d -name __pycache__ -exec rm -rf {} +
      find . -type d -name "*.egg-info" -exec rm -rf {} +
  ```
- Add `ruff` and `mypy` to `[project.optional-dependencies]` dev group in `pyproject.toml`

Acceptance criteria:
- `make install` installs the package in editable mode
- `make test` runs the full test suite
- `make lint` runs ruff without errors (or with documented suppressions)
- `make smoke` runs the smoke script and exits 0
- `make clean` removes `.data/` runtime directories and pycache
- `Makefile` is at the repo root

Priority rationale:
A Makefile is table stakes for any developer-friendly project. It answers "how do I
run this?" without reading any documentation. The smoke test currently has no
standardized entry point; this gives it one.

---

## Task 05: Extract `_sanitize_path_component` into a Shared Utility

Impact: Medium
Effort: Low

Context:
The function `_sanitize_path_component` — which replaces unsafe characters in path
components with underscores and truncates to 48 chars — exists as a private copy in
four modules: `task_registry.py` (lines 46–50), `task_runner.py`, `patch_intent.py`,
and `repo_applicator.py`. The `task_registry.py` copy carries a comment: "Mirrors
`_sanitize_path_component` in task_runner.py, patch_intent.py, and repo_applicator.py.
Kept local to avoid importing a private helper." The decisions log acknowledges this
pattern and says "If this pattern grows, extract it." It has grown to 4 copies.

Problem:
The regex `r"[^a-zA-Z0-9_-]"` and truncation length `48` must be changed in 4 places
if the spec ever changes. The comment says "kept local to avoid importing a private
helper" — this concern evaporates if it moves to a public utility module.

Goal:
Create `packages/orchestration/_path_utils.py` with the canonical implementation.
Remove all 4 local copies. All callers import from the shared module.

Relevant areas:
- [packages/orchestration/task_registry.py](packages/orchestration/task_registry.py) (lines 36–50)
- [packages/orchestration/task_runner.py](packages/orchestration/task_runner.py) (private local copy)
- [packages/orchestration/patch_intent.py](packages/orchestration/patch_intent.py) (private local copy)
- [packages/orchestration/repo_applicator.py](packages/orchestration/repo_applicator.py) (private local copy)

Proposed changes:
- Create `packages/orchestration/_path_utils.py`:
  ```python
  """Path sanitization utilities shared across orchestration modules."""
  import re

  _SAFE_PATH_RE = re.compile(r"[^a-zA-Z0-9_-]")
  _MAX_PATH_COMPONENT_LENGTH = 48

  def sanitize_path_component(value: str) -> str:
      """Replace unsafe characters and truncate for safe use in a path component."""
      sanitized = _SAFE_PATH_RE.sub("_", value)
      sanitized = sanitized[:_MAX_PATH_COMPONENT_LENGTH].strip("_")
      return sanitized or "unknown"
  ```
- Replace the 4 local copies with `from packages.orchestration._path_utils import sanitize_path_component`
- Remove the "Mirrors X, Y, Z" comments
- Add a test in `tests/test_path_utils.py` verifying sanitization behavior

Acceptance criteria:
- `_sanitize_path_component` or `sanitize_path_component` as a local definition no longer appears in `task_registry.py`, `task_runner.py`, `patch_intent.py`, or `repo_applicator.py`
- `packages/orchestration/_path_utils.py` exists with the canonical implementation
- All existing tests that depend on path sanitization behavior continue to pass
- The regex pattern `[^a-zA-Z0-9_-]` and max length `48` appear only once in the codebase

Priority rationale:
4 copies of the same safety-critical path sanitization function is a maintenance
landmine. Any future security review or bug in path handling must be applied to all
4 independently. This is a small, safe, and immediately beneficial change.

---

## Task 06: Document (or Remove) Empty Stub Packages with `__init__.py` Docstrings

Impact: Medium
Effort: Low

Context:
Six packages exist as empty stubs — only an `__init__.py` with no content:
- `packages/artifacts/` — future artifact management
- `packages/memory/` — future memory management (MemPalace)
- `packages/runtimes/` — future runtime abstractions
- `packages/verification/` — future artifact verification
- `apps/api/` — future API app
- `apps/worker/` — future worker app

Three provider stubs also exist:
- `packages/providers/claude_agent/` — empty
- `packages/providers/docker_runtime/` — empty
- `packages/providers/mempalace/` — empty

Problem:
A developer exploring the repo encounters 9 empty directories. Without explanation,
they cannot tell if these are forgotten experiments, in-progress work, or planned
future namespaces. This creates uncertainty and pollutes `ls` output.

Goal:
Every empty `__init__.py` should answer: "What goes here?", "When?", and "Why is it
empty right now?" — as a module docstring. This costs 3 lines per file and eliminates
all confusion.

Relevant areas:
- [packages/artifacts/__init__.py](packages/artifacts/__init__.py)
- [packages/memory/__init__.py](packages/memory/__init__.py)
- [packages/runtimes/__init__.py](packages/runtimes/__init__.py)
- [packages/verification/__init__.py](packages/verification/__init__.py)
- [apps/api/__init__.py](apps/api/__init__.py)
- [apps/worker/__init__.py](apps/worker/__init__.py)
- [packages/providers/claude_agent/__init__.py](packages/providers/claude_agent/__init__.py)
- [packages/providers/docker_runtime/__init__.py](packages/providers/docker_runtime/__init__.py)
- [packages/providers/mempalace/__init__.py](packages/providers/mempalace/__init__.py)

Proposed changes:
- Add a docstring to each `__init__.py` explaining:
  - The package's planned purpose (1 sentence)
  - What step/feature milestone introduces real content
  - "Reserved namespace — no implementation in this step."
- Example for `packages/memory/__init__.py`:
  ```python
  """
  Memory management package — reserved namespace.

  Future home for MemPalace integration and memory gateway implementations.
  Will contain provider implementations satisfying the MemoryGateway protocol
  defined in packages/contracts/interfaces.py.

  Not implemented in v0. See packages/providers/mempalace/ for the provider stub.
  """
  ```

Acceptance criteria:
- All 9 empty `__init__.py` files contain a docstring (not just a blank line)
- Each docstring states the package's purpose and current status
- `pytest` still passes (no import errors introduced)
- The docstrings are factually accurate per the architecture document

Priority rationale:
Minimum effort for maximum clarity. Any developer exploring the package tree will
immediately understand what each namespace is for and whether to look there for
existing code.

---

## Task 07: Create `tests/conftest.py` with Shared Fixtures

Impact: Medium
Effort: Medium

Context:
There are 35 test files with no `conftest.py` at the test root. Each test file that
needs a temp data directory, a temp repo, or a fixture Job must independently set up
the same boilerplate — typically: `tmp_path` manipulation, `monkeypatch.setenv`,
and constructing `Job(name=..., user_prompt=..., state=..., tasks=[...])` objects.

Problem:
Copy-pasted fixture setup across 35 test files means changes to setup patterns (e.g.,
adding a new required field to Job, or changing the REMEDY_DATA_DIR resolution)
require touching many files. Tests are harder to read when setup is embedded.

Goal:
Create `tests/conftest.py` with shared pytest fixtures that the most common test
patterns can use. This does not require changing existing tests — conftest fixtures
are available but not mandatory.

Relevant areas:
- [tests/](tests/) (all 35 test files)
- [packages/core/models.py](packages/core/models.py) (Job, Task, Artifact models)

Proposed changes:
- Create `tests/conftest.py` with:
  ```python
  import pytest
  from pathlib import Path
  from packages.core.models import Job, Task, RunState

  @pytest.fixture
  def tmp_data_dir(tmp_path, monkeypatch):
      """Patch REMEDY_DATA_DIR to an isolated temp directory."""
      monkeypatch.setenv("REMEDY_DATA_DIR", str(tmp_path))
      return tmp_path

  @pytest.fixture
  def tmp_repo_dir(tmp_path):
      """Create a minimal target repo with AGENTS.md and README.md."""
      repo = tmp_path / "target-repo"
      repo.mkdir()
      (repo / "AGENTS.md").write_text("# Test Repo\n")
      (repo / "README.md").write_text("# Test\nInitial content.\n")
      return repo

  @pytest.fixture
  def pending_job():
      return Job(name="test job", user_prompt="test prompt", state=RunState.PENDING)

  @pytest.fixture
  def planned_job():
      t = Task(description="test task", inputs={"task_type": "write_readme"})
      return Job(name="test job", user_prompt="test prompt", state=RunState.PLANNED, tasks=[t])
  ```
- Optionally refactor 3–5 representative test files to use the shared fixtures as proof of value
- Add a `tests/fixtures/` directory for any shared JSON fixture data

Acceptance criteria:
- `tests/conftest.py` exists and is loadable by pytest
- The 4 core fixtures (`tmp_data_dir`, `tmp_repo_dir`, `pending_job`, `planned_job`) are defined
- All 35 existing tests still pass after conftest creation
- At least 3 existing test files are refactored to use shared fixtures
- No existing test is broken by the new conftest

Priority rationale:
Shared fixtures are the standard solution to test boilerplate duplication in Python.
With 35 test files and no conftest, the codebase is accumulating technical debt in the
test layer. This is low-risk (conftest is additive) and has high long-term payoff.

---

## Task 08: Migrate `.agent/decisions.md` to Structured ADRs in `docs/decisions/`

Impact: Medium
Effort: Medium

Context:
`.agent/decisions.md` is an 854-line flat chronological log of 50+ architectural
decisions. Entries are dated and ordered newest-first within the file. Topics range
from state machine design, to redaction policy, to CLI UX, to data path resolution.
Finding the decision rationale for a specific design requires text search or
scrolling through hundreds of lines.

Problem:
Finding the rationale for, e.g., "why does verification failure roll back to PENDING
instead of FAILED?" requires knowing to search for "FAILED" or "PENDING" in an 854-line
file. Decisions are not indexed by topic. New developers cannot discover the reasoning
without reading the whole file. The `.agent/` prefix signals AI-internal content,
making developers likely to ignore the file.

Goal:
Migrate to Architecture Decision Records (ADR) format in `docs/decisions/`. Each
major decision becomes a separate file, indexed in a `README.md`.

Relevant areas:
- [.agent/decisions.md](.agent/decisions.md) (entire file, 854 lines)
- [docs/](docs/) (target directory)

Proposed changes:
- Create `docs/decisions/` directory
- Create `docs/decisions/README.md` as an index with columns: ID, Title, Date, Status, Topic
- Migrate decisions into individual ADR files, grouped by theme (not necessarily 1:1):
  - `docs/decisions/001-state-machine-runstate.md` — PENDING/PLANNED/RUNNING/COMPLETED/FAILED states
  - `docs/decisions/002-verification-failure-to-pending.md` — why failure rolls back to PENDING
  - `docs/decisions/003-redaction-policy.md` — what is/isn't logged in run logs
  - `docs/decisions/004-data-dir-resolution.md` — REMEDY_DATA_DIR + repo-relative fallback
  - `docs/decisions/005-permission-model.md` — capability enum, defaults, reserved vs active
  - `docs/decisions/006-patch-intent-id-format.md` — artifact_short_id + index format
  - `docs/decisions/007-approval-state-latest-wins.md` — last decision overwrites
  - `docs/decisions/008-task-type-registry.md` — open enum, keyword matching, fallback
  - `docs/decisions/009-artifact-kind-enum.md` — UNKNOWN default, explicit at creation sites
  - `docs/decisions/010-workspace-boundary-safety.md` — resolve + is_relative_to pattern
  - (continue for remaining ~40 decisions)
- Each ADR file uses standard format: Title, Date, Status, Context, Decision, Rationale, Consequences
- Keep `.agent/decisions.md` as a pointer: "Full decisions now in docs/decisions/"

Acceptance criteria:
- `docs/decisions/` exists with at least 10 ADR files covering the major themes
- `docs/decisions/README.md` is an indexed table of all ADRs
- Each ADR file is under 50 lines and covers one decision or one closely related cluster
- `.agent/decisions.md` contains a redirect notice pointing to `docs/decisions/`
- Finding the rationale for any major design decision takes under 30 seconds via the index

Priority rationale:
Architectural decisions are institutional knowledge. An 854-line flat file makes this
knowledge effectively inaccessible. ADR format is industry-standard and makes design
rationale discoverable. This directly benefits any new contributor or reviewer.

---

## Task 09: Add Developer Tool Configuration to `pyproject.toml` and Create `CONTRIBUTING.md`

Impact: Medium
Effort: Medium

Context:
`pyproject.toml` contains 23 lines: hatchling build config, one dependency (pydantic),
one optional group (ollama), pytest pythonpath config, and the console script entry
point. There is no ruff, mypy, or coverage configuration. There is no `CONTRIBUTING.md`,
`DEVELOPMENT.md`, or any contributor onboarding document.

Problem:
A new contributor must:
1. Figure out which linter/formatter this project uses (none configured → no standard)
2. Determine if type checking is expected (no mypy config → unclear)
3. Learn the PR workflow by reading AGENTS.md (the AI rules doc, not a contributor guide)
4. Discover that there is no code style enforcement at all

Goal:
Add standard tool configuration to `pyproject.toml` and create a `CONTRIBUTING.md`
that answers the 5 questions every contributor asks first.

Relevant areas:
- [pyproject.toml](pyproject.toml)

Proposed changes:
- Add to `pyproject.toml`:
  ```toml
  [project.optional-dependencies]
  dev = ["pytest", "ruff", "mypy"]

  [tool.ruff]
  line-length = 100
  target-version = "py310"
  select = ["E", "W", "F", "I", "N", "UP"]
  ignore = ["E501"]  # line length managed separately

  [tool.mypy]
  python_version = "3.10"
  strict = false
  ignore_missing_imports = true
  check_untyped_defs = true

  [tool.coverage.run]
  source = ["packages", "apps"]
  omit = ["*/tests/*", "*/__pycache__/*"]

  [tool.coverage.report]
  show_missing = true
  fail_under = 70
  ```
- Create `CONTRIBUTING.md` with sections:
  1. **Setup** — `pip install -e ".[dev,ollama]"` + Ollama install
  2. **Running Tests** — `pytest` or `make test`
  3. **Code Style** — ruff for lint/format, no strict type annotations required
  4. **Branch Workflow** — branch from main, one PR per feature boundary
  5. **Commit Messages** — short imperative subject, body explains "why"
  6. **Adding a CLI Command** — pointer to `apps/cli/commands/` (after Task 01)
  7. **Adding a Provider** — pointer to `packages/providers/` and contract interface

Acceptance criteria:
- `pyproject.toml` contains `[tool.ruff]`, `[tool.mypy]`, `[tool.coverage.run]` sections
- `ruff check packages/ apps/ tests/` exits 0 (or all violations are documented suppressions)
- `mypy packages/` exits 0 with the configured settings
- `CONTRIBUTING.md` exists and covers all 7 sections above
- `ruff` and `mypy` are in the `dev` optional dependency group

Priority rationale:
No tool configuration is the structural equivalent of "anything goes." Consistency
in code style reduces review friction. mypy configuration catches bugs that tests miss.
CONTRIBUTING.md is the first document a GitHub contributor reads after README.

---

## Task 10: Sub-group `packages/orchestration/` into Semantic Sub-packages

Impact: Medium
Effort: High

Context:
`packages/orchestration/` contains 28 Python modules in a flat directory. The modules
cover at least 5 distinct functional areas: brain/visualization, execution/runtime,
patching/approval, reporting/observability, and storage/core infrastructure. A developer
looking for the brain viewer must know to look for `brain_viewer.py` by name — there is
no directory grouping to guide navigation.

Problem:
28 files in one directory with no grouping makes the directory listing useless as a
navigation aid. A developer learning the codebase sees `agent_loop.py` next to
`approval_queue.py` next to `artifact_index.py` next to `brain_detail.py` — 28 files
in alphabetical order with no indication of which ones work together.

Goal:
Introduce 4 semantic sub-packages within `packages/orchestration/`. Update all imports.
Provide backward-compatible re-exports from the parent for the transition period.

Relevant areas:
- [packages/orchestration/](packages/orchestration/) (all 28 modules)
- [tests/](tests/) (all 35 test files — imports must be updated)
- [apps/cli/main.py](apps/cli/main.py) (or commands/ after Task 01)

Proposed changes:
- Create `packages/orchestration/brain/` sub-package with:
  `project_brain.py`, `brain_detail.py`, `brain_viewer.py`, `context_coverage.py`, `agent_loop.py`
- Create `packages/orchestration/execution/` sub-package with:
  `task_runner.py`, `workspace.py`, `verifier.py`, `verifier_profiles.py`, `builder_models.py`
- Create `packages/orchestration/patching/` sub-package with:
  `patch_intent.py`, `patch_apply.py`, `approval_queue.py`, `repo_applicator.py`
- Create `packages/orchestration/reporting/` sub-package with:
  `timeline.py`, `cockpit.py`, `trust_report.py`, `run_log.py`, `artifact_index.py`
- Keep at `packages/orchestration/` root: `storage.py`, `job_runner.py`, `llm_planner.py`,
  `planner_models.py`, `permissions.py`, `task_registry.py`, `project_constitution.py`,
  `project_registry.py`, `project_context_coverage.py`, `markdown_output_safety.py`
- Add re-export aliases in `packages/orchestration/__init__.py` for backward compatibility
- Update all test imports to use new paths
- Update all CLI command imports to use new paths

Acceptance criteria:
- `packages/orchestration/brain/`, `execution/`, `patching/`, `reporting/` directories exist
- Each sub-package has an `__init__.py` that exports its public API
- All 35 test files import from the correct new paths and pass
- `packages/orchestration/__init__.py` re-exports the public API of all sub-packages for backward compatibility
- `remedy --help` and all subcommands work correctly after the move
- No module exists in both old and new locations (clean move, not copy)

Priority rationale:
28 files in one flat directory is unsustainable as the codebase grows. This is the
highest-effort task but has the largest long-term structural payoff. It should be done
last (after Task 01 splits the CLI) so the import cleanup is done once in the new
command modules, not twice. The result is a codebase where "I need the brain viewer"
→ `packages/orchestration/brain/brain_viewer.py` without guessing.
