# Relevant Files — Evidence Base

## Files read in full

| File | Key findings |
|------|-------------|
| README.md | 591 lines. Pure step-by-step changelog (Step 1 → Step 30). No quick start. No CLI reference table. No "Getting Started" section. |
| pyproject.toml | 23 lines. Build + one dep (pydantic) + pytest path only. No ruff, mypy, coverage, black config. |
| .gitignore | Comprehensive Python gitignore. |
| apps/cli/main.py | 1720 lines. 30 command handlers as top-level functions. Giant if/elif dispatch at line 1652. data_dir resolution duplicated 8+ times inline. |
| packages/core/models.py | 140 lines. Clean Pydantic models. Well-organized. |
| packages/contracts/interfaces.py | 88 lines. Clean Protocol interfaces. |
| packages/orchestration/storage.py | 78 lines. Has its own `_resolve_data_dir()`. |
| packages/orchestration/run_log.py | 218 lines. Has its own `_resolve_runs_root()`. |
| packages/orchestration/task_registry.py | 279 lines. Has local `_sanitize_path_component` copy + comment noting it mirrors 3 other copies. |
| packages/orchestration/project_registry.py | 284 lines. Has its own `_resolve_projects_dir()`. |
| packages/orchestration/patch_apply.py | 487 lines. References _sanitize (imported from markdown_output_safety). Well-structured. |
| .agent/decisions.md | 854 lines. 50+ architectural decisions, flat chronological, no sections. Hard to find decisions by topic. |
| .agent/context.md | 115 lines. AI working context. |
| .agent/plan.md | 19 lines. Current step plan. |
| scripts/remedy_smoke.sh | 523 lines. Smoke test. Works correctly. |
| docs/architecture.md | >32k tokens. Very large, required paging. |

## Empty stubs found

- `apps/api/__init__.py` — 1 line (empty)
- `apps/worker/__init__.py` — 1 line (empty)
- `packages/artifacts/__init__.py` — 1 line (empty)
- `packages/memory/__init__.py` — 1 line (empty)
- `packages/runtimes/__init__.py` — 1 line (empty)
- `packages/verification/__init__.py` — 1 line (empty)
- `packages/providers/claude_agent/__init__.py` — empty stub
- `packages/providers/docker_runtime/__init__.py` — empty stub
- `packages/providers/mempalace/__init__.py` — empty stub

## Duplication hotspots

### `_sanitize_path_component` — 4 copies
- `packages/orchestration/task_registry.py:46-50`
- `packages/orchestration/task_runner.py` (private local)
- `packages/orchestration/patch_intent.py` (private local)
- `packages/orchestration/repo_applicator.py` (comment: "intentional local copy")

### `data_dir` resolution — duplicated in CLI ~8 times
```python
env = os.environ.get("REMEDY_DATA_DIR")
data_dir = Path(env) if env else Path(__file__).resolve().parent.parent.parent / ".data"
```
Appears in: `_cmd_cockpit`, `_cmd_timeline`, `_cmd_trust_report`, `_cmd_brain`, `_cmd_brain_node`, `_cmd_context`, `_cmd_brain_view`, `_cmd_agent_loop`

### Data dir resolver functions — 3 separate versions
- `storage.py::_resolve_data_dir()` → `.data/jobs`
- `run_log.py::_resolve_runs_root()` → `.data/runs`
- `project_registry.py::_resolve_projects_dir()` → `.data/projects`
All use the same env var pattern. Base `.data/` root is never shared.

## Missing structural elements

- No `Makefile` or `justfile`
- No `CONTRIBUTING.md`
- No `DEVELOPMENT.md`
- No `CHANGELOG.md` (ironically — README is the changelog)
- No `tests/conftest.py`
- No `tests/fixtures/` directory
- No `[tool.ruff]` in pyproject.toml
- No `[tool.mypy]` in pyproject.toml
- No `[tool.coverage]` in pyproject.toml
- No `__all__` exports in any `__init__.py`
