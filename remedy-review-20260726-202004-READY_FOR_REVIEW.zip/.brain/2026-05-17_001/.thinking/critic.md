# Critic Pass

## Eliminated ideas (not in final tasks)

### "Add async throughout"
Rejected. The sync design is intentional — documented in decisions log. Async
would add complexity without benefit at the local-only stage.

### "Merge packages/core and packages/contracts"
Rejected. The separation is principled: core has models, contracts has interfaces.
They serve different purposes and have different import directions.

### "Add a configuration system (YAML/TOML)"
Rejected. The env var approach is correct and simple for this stage. A config system
is future work explicitly deferred in the decisions log.

### "Sub-package orchestration/ as Task 07"
Kept but priority lowered — this is highest-effort and most likely to break imports.
Tests import from `packages.orchestration.xxx` directly. All 35 test files would
need import updates. Must be done carefully with backward-compat shims or a single
coordinated pass.

### "Add Claude/MemPalace provider implementations"
Out of scope for reorganization. These are feature work, not structure work.

## Validated tasks (evidence confirmed)

### Task 01 — CLI monolith split
Confirmed: main.py is 1720 lines, 1652-1716 is a 65-line if/elif chain.
This is the most impactful single change for human-friendliness.

### Task 02 — data_dir consolidation
Confirmed: 8 inline occurrences in main.py + 3 module-level resolver functions.
All use the same env var + parent.parent.parent pattern.

### Task 03 — README rewrite
Confirmed: 591-line README is entirely step changelog with zero onboarding content.

### Task 04 — Makefile
Confirmed: pyproject.toml has no tool shortcuts beyond pytest.

### Task 05 — Empty stub documentation
Confirmed: 6 completely empty packages. Confusing for contributors.

### Task 06 — _sanitize_path_component extraction
Confirmed: 4 copies with cross-references in comments and decisions log.

### Task 07 — orchestration/ sub-packaging
Confirmed: 28 files in one flat directory. BUT this has highest breakage risk.
Scope must include updating all test imports. Still worth it — but sequence last.

### Task 08 — decisions.md → ADR migration
Confirmed: 854-line flat file. Unusable for reference navigation.

### Task 09 — pyproject.toml + CONTRIBUTING.md
Confirmed: no ruff/mypy/coverage config. No CONTRIBUTING.md exists.

### Task 10 — tests/conftest.py
Confirmed: 35 test files, no conftest.py. Pattern duplication is structural.

## Priority rationale review

1. CLI monolith → biggest daily friction for any developer
2. data_dir consolidation → correctness + DRY (11 duplicates = bug surface)
3. README rewrite → first contact for any new developer
4. Makefile → daily dev workflow
5. _sanitize duplication → small but clean win, correctness guarantor
6. Empty stub documentation → low effort, removes confusion
7. conftest.py → reduces test maintenance burden
8. decisions.md → ADR → discoverability of design rationale
9. pyproject.toml + CONTRIBUTING.md → onboarding completeness
10. orchestration/ sub-packaging → highest effort, biggest structural win
