# Sources

All evidence is from direct file reads in this session.

| Claim | Source | Evidence |
|-------|--------|----------|
| main.py is 1720 lines | apps/cli/main.py | File read: 1720 lines |
| if/elif dispatch at line 1652 | apps/cli/main.py | Lines 1652–1716 |
| data_dir inlined 8 times | apps/cli/main.py | `_cmd_cockpit`, `_cmd_timeline`, `_cmd_trust_report`, `_cmd_brain`, `_cmd_brain_node`, `_cmd_context`, `_cmd_brain_view`, `_cmd_agent_loop` |
| 3 independent resolver functions | storage.py, run_log.py, project_registry.py | `_resolve_data_dir`, `_resolve_runs_root`, `_resolve_projects_dir` |
| README.md is 591 lines of changelogs | README.md | Entire file is Step 1 → Step 30 changelog |
| _sanitize_path_component in 4 files | task_registry.py:46-50 comment | "Mirrors _sanitize_path_component in task_runner.py, patch_intent.py, and repo_applicator.py." |
| decisions.md is 854 lines | .agent/decisions.md | File read (full content) |
| 28 files in orchestration/ | file listing | Direct ls output |
| 35 test files, no conftest.py | file listing | No conftest.py found in tests/ |
| 6 empty stub packages | direct reads | All returned "file has 1 line" warning (empty) |
| pyproject.toml has no tool config | pyproject.toml | 23 lines, no [tool.*] sections |
| No Makefile, no CONTRIBUTING.md | file listing | Neither file found in repo root |
