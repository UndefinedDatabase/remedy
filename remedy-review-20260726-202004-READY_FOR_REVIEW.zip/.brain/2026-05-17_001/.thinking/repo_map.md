# Repo Map

## Top-level layout

```
remedy/
├── apps/
│   ├── api/__init__.py          # empty stub
│   ├── cli/main.py              # 1720-line monolith (30+ commands)
│   └── worker/__init__.py       # empty stub
├── packages/
│   ├── artifacts/__init__.py    # empty stub
│   ├── contracts/interfaces.py  # Protocol interfaces (LLMWorker, MemoryGateway, RuntimeProvider, Verifier)
│   ├── core/models.py           # Pydantic domain models (Budget, AcceptanceCheck, RunState, Artifact, Task, Job)
│   ├── memory/__init__.py       # empty stub
│   ├── orchestration/           # 28 files — the engine (flat, no grouping)
│   ├── providers/               # 5 stub subdirs (2 real: ollama_builder, ollama_planner)
│   ├── runtimes/__init__.py     # empty stub
│   └── verification/__init__.py # empty stub
├── tests/                       # 35 test files, flat, no conftest.py
├── scripts/
│   └── remedy_smoke.sh          # 523-line bash smoke test
├── docs/
│   └── architecture.md          # 32k-token architecture document
├── .agent/
│   ├── context.md               # AI working context
│   ├── decisions.md             # 854-line flat decision log (50+ entries)
│   └── plan.md                  # AI current plan
├── README.md                    # 591-line step-changelog masquerading as a README
├── pyproject.toml               # hatchling, pydantic dep, pytest config only
├── CLAUDE.md                    # points to AGENTS.md
├── AGENTS.md                    # AI agent rules
└── .gitignore                   # comprehensive Python .gitignore
```

## packages/orchestration/ (28 files, flat)

agent_loop.py, approval_queue.py, artifact_index.py, brain_detail.py,
brain_viewer.py, builder_models.py, cockpit.py, context_coverage.py,
job_runner.py, llm_planner.py, markdown_output_safety.py, patch_apply.py,
patch_intent.py, permissions.py, planner_models.py, project_brain.py,
project_constitution.py, project_context_coverage.py, project_registry.py,
repo_applicator.py, run_log.py, storage.py, task_registry.py, task_runner.py,
timeline.py, trust_report.py, verifier.py, verifier_profiles.py, workspace.py

## Tests (35 files, flat)

test_agent_loop.py, test_artifact_kinds.py, test_brain_detail.py,
test_brain_smoke.py, test_brain_viewer.py, test_cli_main.py, test_cockpit.py,
test_context_coverage.py, test_imports.py, test_llm_planner.py,
test_markdown_output_safety.py, test_ollama_builder.py, test_ollama_provider.py,
test_patch_apply.py, test_patch_intent_approval.py, test_patch_intent.py,
test_permissions.py, test_project_brain.py, test_project_constitution.py,
test_project_context_coverage.py, test_project_registry.py,
test_remedy_smoke_script.py, test_repo_applicator.py, test_run_log_cli.py,
test_run_log.py, test_runner.py, test_storage.py, test_task_registry.py,
test_task_runner.py, test_timeline.py, test_trust_report.py,
test_verifier_profiles.py, test_verifier.py, test_workspace.py
