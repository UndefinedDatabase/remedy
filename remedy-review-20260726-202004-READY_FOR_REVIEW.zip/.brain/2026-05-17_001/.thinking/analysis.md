# Analysis

## Theme: "Human Friendly" — what that means for this repo

A developer cloning this repo needs:
1. To understand what it does in < 2 minutes (README)
2. To install and run tests in < 3 commands (tooling)
3. To find the code for a feature by directory name (structure)
4. To add a new command without reading 1720 lines (CLI modularity)
5. To find a past decision about a design choice (decisions)
6. To write a test without copy-pasting 40 lines of setup (conftest)
7. To run lint + typecheck with one command (pyproject.toml)

## Problem 1: `apps/cli/main.py` — 1720-line monolith

The single most impactful structure problem. Every command is a 50-300 line
function in one file. The routing is a 65-line if/elif chain (lines 1652-1716).
Adding a new command requires knowing the full file.

**Solution**: `apps/cli/commands/` package. One module per command group:
- `commands/job.py` — create-job, list-jobs, show-job, plan-job
- `commands/execution.py` — run-next-task-local, attach-repo, set-permission
- `commands/brain.py` — brain, brain-node, brain-view, context, agent-loop
- `commands/patch.py` — list-patch-intents, show-patch-intent, approve, reject, apply
- `commands/project.py` — create-project, list-projects, show-project, attach-*
- `commands/reporting.py` — timeline, cockpit, trust-report, constitution
`apps/cli/main.py` becomes a 50-line dispatcher.

## Problem 2: `data_dir` resolution duplicated 11+ times

The pattern:
```python
env = os.environ.get("REMEDY_DATA_DIR")
data_dir = Path(env) if env else Path(__file__).resolve().parent.parent.parent / ".data"
```
appears 8 times in main.py inline, plus 3 different resolver functions in
storage.py, run_log.py, and project_registry.py. All hardcode the `parent.parent.parent`
path chain, which is fragile against moving files.

**Solution**: `packages/orchestration/data_paths.py`:
```python
def resolve_data_root() -> Path:
    ...
def jobs_dir(root: Path | None = None) -> Path: return (root or resolve_data_root()) / "jobs"
def runs_dir(root: Path | None = None) -> Path: return (root or resolve_data_root()) / "runs"
def projects_dir(root: Path | None = None) -> Path: return (root or resolve_data_root()) / "projects"
```
All callers import from one place. No more inline resolution.

## Problem 3: README.md — 591-line step changelog

README.md reads entirely as "Step 1: ..., Step 2: ..., Step 3: ...". This is a
great internal development log but terrible as a first-contact document. A developer
cloning the repo is told about every implementation decision instead of how to use it.

**Solution**: Extract the step changelog to `CHANGELOG.md`. Rewrite README.md as:
- What Remedy is (1 paragraph)
- Quick Start (3 commands)
- CLI command reference (table with command + description)
- Architecture overview (1-2 paragraphs + pointer to docs/architecture.md)
- Development (pointer to CONTRIBUTING.md)

## Problem 4: No Makefile / developer tooling

The only shorthand a developer has is `pytest`. No lint, no format, no type-check,
no smoke test, no install shortcut.

**Solution**: `Makefile` with:
- `make install` → `pip install -e ".[dev,ollama]"`
- `make test` → `pytest`
- `make lint` → `ruff check .`
- `make format` → `ruff format .`
- `make typecheck` → `mypy packages/ apps/`
- `make smoke` → `source scripts/remedy_smoke.sh && remedy_smoke`
- `make clean` → remove `.data/`, `dist/`, `__pycache__`

## Problem 5: Empty stubs pollute the directory tree

6 empty package directories (`artifacts/`, `memory/`, `runtimes/`, `verification/`,
`api/`, `worker/`) appear in directory listings. A developer sees these and doesn't
know if they're in-progress, planned, or forgotten. The `providers/` directory has
3 empty stubs alongside 2 real ones.

**Solution**: Add `__init__.py` docstrings that state:
1. The planned purpose of the package
2. Which step/milestone is expected to introduce real content
3. "This package is a reserved namespace — no implementation yet."

## Problem 6: `_sanitize_path_component` — 4 copies

The same 3-line function appears in `task_registry.py`, `task_runner.py`,
`patch_intent.py`, and (by implication) `repo_applicator.py`. The decisions log
acknowledges this as intentional "to avoid importing private helpers" but also says
"If this pattern grows, extract it." It has grown to 4 copies.

**Solution**: `packages/orchestration/_path_utils.py` with one canonical copy.
All 4 callers import from there. Not a private helper anymore — it's a small
utility with a stable interface.

## Problem 7: `packages/orchestration/` — 28 files, flat

The 28-file flat directory makes navigation require memorizing all filenames.
There's no visual grouping to guide a new developer to the right file.

**Solution**: Introduce 4 semantic sub-packages:
- `packages/orchestration/brain/` — project_brain, brain_detail, brain_viewer, context_coverage, agent_loop
- `packages/orchestration/execution/` — task_runner, workspace, verifier, verifier_profiles, builder_models
- `packages/orchestration/patching/` — patch_intent, patch_apply, approval_queue, repo_applicator, patch_apply
- `packages/orchestration/reporting/` — timeline, cockpit, trust_report, run_log, artifact_index
Core files stay at orchestration root: storage.py, job_runner.py, llm_planner.py,
permissions.py, planner_models.py, task_registry.py, project_constitution.py,
project_registry.py, markdown_output_safety.py

## Problem 8: `.agent/decisions.md` — 854-line flat chronological log

Contains 50+ architectural decisions as one chronological file. Finding the decision
about, e.g., "why is verification failure PENDING not FAILED?" requires grepping or
scrolling 800+ lines. There's no index, no categorization by topic.

**Solution**: Migrate to `docs/decisions/` ADR format:
- `docs/decisions/README.md` — index of all decisions
- `docs/decisions/001-state-machine-runstate.md`
- `docs/decisions/002-storage-repo-relative.md`
- etc.
One decision per file. Dated. Concise. Searchable by file name.

## Problem 9: `pyproject.toml` lacks tool configuration

No ruff, mypy, or coverage configuration. No CONTRIBUTING.md.

**Solution**: Add standard sections:
```toml
[tool.ruff]
line-length = 100
select = ["E", "W", "F", "I", "N"]

[tool.mypy]
python_version = "3.10"
strict = true
ignore_missing_imports = true

[tool.coverage.run]
source = ["packages", "apps"]
```
And create CONTRIBUTING.md.

## Problem 10: `tests/` — 35 files, no conftest.py

Every test file independently sets up temp dirs, patches env vars, creates fixture
jobs. The pattern appears to repeat across many test files (inferred from patterns
in decisions log about test design).

**Solution**: `tests/conftest.py` with shared fixtures:
- `tmp_data_dir(tmp_path)` — patches REMEDY_DATA_DIR
- `tmp_repo_dir(tmp_path)` — creates a temp target repo with AGENTS.md + README.md
- `pending_job()` — fixture Job in PENDING state
- `planned_job()` — fixture Job in PLANNED state with tasks

## What NOT to fix (critic's voice)

- Do NOT merge packages/core and packages/contracts — the separation is principled
- Do NOT add async everywhere — the sync design is intentional
- Do NOT add a config system — the env var approach is simple and correct for now
- Do NOT sub-package orchestration/ yet if tests will break — assess import impact first
- Do NOT delete .agent/ directory — it has value for AI context
