# Sources

## Commits analyzed
- 3cfc061, 83f4d5e, 5f60291, f9448aa, 4af9171, a79ba3b, 01d483b, e347899, 75ecfb9, 4982137

## Files read
- packages/orchestration/project_brain.py (full, 1110 lines)
- packages/orchestration/agent_loop.py (full, 662 lines)
- packages/orchestration/brain_detail.py (first 60 lines + grep)
- packages/orchestration/autonomy_readiness.py (first 80 lines)
- packages/orchestration/context_pack.py (first 80 lines)
- packages/orchestration/memory_learn.py (first 80 lines)
- packages/orchestration/file_provenance.py (first 80 lines)
- packages/orchestration/continue_from_node.py (first 80 lines)
- packages/orchestration/project_brain_aggregate.py (first 80 lines)
- scripts/remedy_smoke.sh (first 50 lines + wc)
- AGENTS.md (full)

## Greps performed
- `except Exception` across orchestration/ — 18+ hits
- `_section` definitions across orchestration/ — 7 copies
- `_OK/_FAIL/_WARN/_INFO/_LINE` across orchestration/ — 7 copies
- `any(n.id` in project_brain.py — 4 hits
- inline imports in project_brain.py — 6 hits
- function counts per file — brain_detail.py has 27 functions
