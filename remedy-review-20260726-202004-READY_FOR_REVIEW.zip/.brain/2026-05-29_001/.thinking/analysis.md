# Analysis of last 10 commits

## Commits reviewed (newest first)
1. 3cfc061 — Update plan: Steps 50.2-53 complete (plan bookkeeping)
2. 83f4d5e — Step 50.2: Fix memory brain node bug (scope mismatch)
3. 5f60291 — Update plan: Steps 50.1-53 complete (plan bookkeeping)
4. f9448aa — Step 53: Project Brain Aggregate v0 (cross-job brain)
5. 4af9171 — Step 52: Continue-from-node v0 (child job creation)
6. a79ba3b — Step 51: Causal Proof Graph v1 (causal edges + file provenance)
7. 01d483b — Step 50.1: Contract closure (score fix, outcome dedup, real events)
8. e347899 — AGENTS.md: add PR Scope Drift Prevention rule
9. 75ecfb9 — Steps 46.2 + 48-50: Autonomy, Context Pack, Memory Learn (mega commit)
10. 4982137 — Step 46.1: Close CLI/Memory/AgentLoop contracts (mega refactor)

## Patterns observed

### 1. build_project_brain() is a God Function (934 lines, 18 sections)
Single function does everything: job nodes, task nodes, artifact nodes, patch intents,
approvals, apply records, test runs, events, constitution, memory, MCP, context coverage,
project placeholder, run contract, token policy, worker adapters, autonomy readiness,
context pack, proof nodes, causal edges, continuation edges, sorting. Each commit adds
more sections. No structural decomposition.

### 2. Duplicated formatting infrastructure (7x)
`_section()`, `_OK`, `_FAIL`, `_WARN`, `_INFO`, `_LINE` are copy-pasted in:
agent_loop.py, brain_detail.py, cockpit.py, project_brain.py, project_constitution.py,
timeline.py, trust_report.py. Seven identical copies.

### 3. brain_detail.py: 22 handler functions, 1418 lines, dispatch by if/elif
Each node type gets a `_detail_*` function. All very similar structure.
No base pattern, no registry, no protocol. Adding a node type requires
touching project_brain.py + brain_detail.py + _NODE_TYPE_ORDER + summarize + export.

### 4. Mega commits bundle unrelated changes
75ecfb9 bundles Steps 46.2 + 48 + 49 + 50 (4 independent features: memory fix,
autonomy readiness, context pack, memory learn) in a single 2874-line commit.
4982137 bundles 5 independent contract closures in a single 1240-line commit.
Both violate AGENTS.md "keep commits small and logically scoped."

### 5. Silent exception swallowing
project_brain.py:622 — `except Exception: pass` swallows memory errors silently
project_brain.py:671 — `except (ValueError, AttributeError): pass` swallows bad project_id
project_brain.py:777 — `except Exception: pass` swallows autonomy readiness errors
memory_learn.py has 3 bare `except Exception` blocks
18+ `except Exception` across orchestration modules total

### 6. Inline imports inside build_project_brain()
Lines 587, 688, 711, 733, 755-757 — six inline imports inside function body.
Suggests circular dependency or tight coupling that blocks clean imports.

### 7. smoke_smoke.sh: 1487-line bash script
Growing every commit. Now has 12+ sections (12a-12p). Hard to maintain.
No parallelism, no structured output, no timeout per section.
test_remedy_smoke_script.py mirrors it at 1443 lines (fragile coupling).

### 8. O(n) linear scans for node existence checks
project_brain.py:836, 848, 856, 915 — `any(n.id == x for n in nodes)`.
With 50+ nodes per job, these are fine now but will degrade with scale.
No node ID index.

### 9. Causal edge heuristics are fragile
project_brain.py:866-870 — "connect last proof to last test_run" is a deterministic
heuristic. Works when there's one proof/one test. Breaks when multiple proofs
exist and should connect to different test runs. Same issue with informed_memory
(all memory nodes connected to last proof).

### 10. No integration test for continue_from_node end-to-end
Only smoke script tests (12o) assert JSON output format. No pytest-level
integration test verifying parent→child→brain linkage round-trip.
