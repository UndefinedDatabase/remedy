# Repo Map (relevant to last 10 commits)

## Key orchestration modules (packages/orchestration/)
- project_brain.py (1110 lines) — brain graph builder, 18 sections, 22+ node types
- brain_detail.py (1418 lines) — per-node detail view, 22 handler functions
- agent_loop.py (662 lines) — execution loop, state derivation
- autonomy_readiness.py (392 lines) — 8-level readiness assessment
- context_pack.py (297 lines) — token-budgeted context generator
- memory_learn.py (151 lines) — evidence-to-memory extraction
- file_provenance.py (209 lines) — causal chain tracing
- continue_from_node.py (154 lines) — child job creation from brain node
- project_brain_aggregate.py (240 lines) — cross-job brain aggregation

## CLI layer (apps/cli/)
- command_catalog.py — command registration
- commands/ — grouped command handlers (brain, context, file, memory, project, readiness)
- grouped.py — grouped CLI entry
- main.py — thin bridge (was 302 lines, now 19)

## Tests
- tests/test_remedy_smoke_script.py (1443 lines) — smoke script assertions
- 52+ test files total

## Smoke
- scripts/remedy_smoke.sh (1487 lines) — integration smoke tests
