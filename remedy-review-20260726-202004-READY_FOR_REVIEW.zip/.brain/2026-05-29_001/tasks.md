# Brain Run 2026-05-29_001 — Review last 10 commits

## Task 01: Decompose build_project_brain() God Function

Impact: High
Effort: High

Context:
`build_project_brain()` in `packages/orchestration/project_brain.py` is a single 934-line function with 18 numbered sections. Every commit in the last 10 adds another section (autonomy readiness, context pack, proof nodes, causal edges, continuation edges). The function has grown from ~400 lines to 934 lines across these commits.

Problem:
A single function handles node creation for 22+ node types, edge wiring, causal chain assembly, inline imports, exception handling, and sorting. This makes every new node type addition risky (touching 934 lines of sequential logic), review-hostile (diff context is always "inside build_project_brain"), and test-hostile (can only test the whole function, not individual section builders).

Goal:
Extract each numbered section into a standalone builder function (e.g., `_build_task_nodes()`, `_build_causal_edges()`) that receives a mutable `(nodes, edges)` accumulator and job/events context. `build_project_brain()` becomes a 40-line orchestrator calling section builders in order.

Relevant areas:
- `packages/orchestration/project_brain.py` (lines 239-934)
- `tests/test_project_brain.py`
- `tests/test_brain_smoke.py`

Proposed changes:
- Define a `_GraphAccumulator` NamedTuple or dataclass holding `nodes: list[BrainNode]`, `edges: list[BrainEdge]`, `job: Job`, `events: list`
- Extract sections 1-18 into `_build_section_N(acc)` functions
- Keep `build_project_brain()` as orchestrator: create accumulator, call section builders, sort, return frozen graph
- Move inline imports (lines 587, 688, 711, 733, 755-757) to top-level or into their respective section builders

Acceptance criteria:
- `build_project_brain()` body is under 60 lines
- All 2499 existing tests pass without modification
- No change to public API signature or output structure
- Each section builder is independently unit-testable

Priority rationale:
Highest impact because every future brain feature (Step 24+, React Flow, AG-UI) will add more sections. Without decomposition, the function will exceed 1500 lines within 5 steps. This is the structural bottleneck blocking clean brain evolution.

---

## Task 02: Extract Shared Formatting Constants into orchestration/_symbols.py

Impact: High
Effort: Low

Context:
The symbols `_OK = "✓"`, `_FAIL = "✕"`, `_WARN = "!"`, `_INFO = "○"`, `_LINE = "─"` and the helper `_section(title)` are copy-pasted identically in 7 files: `agent_loop.py`, `brain_detail.py`, `cockpit.py`, `project_brain.py`, `project_constitution.py`, `timeline.py`, `trust_report.py`.

Problem:
Any change to formatting conventions (e.g., switching symbols for accessibility, adding color codes) requires editing 7 files identically. This is a textbook DRY violation introduced incrementally across commits.

Goal:
Single source of truth for CLI formatting symbols and section rendering.

Relevant areas:
- `packages/orchestration/agent_loop.py:78-83, 438-440`
- `packages/orchestration/brain_detail.py:75-80, 1416-1418`
- `packages/orchestration/cockpit.py:37-42, 446-448`
- `packages/orchestration/project_brain.py:89-94, 1087-1089`
- `packages/orchestration/project_constitution.py:305`
- `packages/orchestration/timeline.py:26-31, 107-109`
- `packages/orchestration/trust_report.py:39-44, 511-513`

Proposed changes:
- Create `packages/orchestration/_symbols.py` with `OK`, `FAIL`, `WARN`, `INFO`, `LINE`, `section(title)` as public module-level constants/functions
- Replace all 7 local copies with `from packages.orchestration._symbols import OK, FAIL, WARN, INFO, LINE, section`
- Remove the 7 local `_section()` definitions

Acceptance criteria:
- Only one definition of each symbol exists in the codebase
- Only one definition of `section()` exists
- All existing tests pass unchanged
- `grep -rn "def _section" packages/orchestration/` returns exactly 0 results (excluding `_symbols.py`)

Priority rationale:
Low effort (mechanical extraction), high signal (reduces 7-way duplication to 1). Enables consistent formatting changes project-wide in future steps.

---

## Task 03: Replace Silent Exception Swallowing with Structured Degradation

Impact: High
Effort: Medium

Context:
Across the last 10 commits, `except Exception: pass` patterns were added in `project_brain.py` (lines 622, 671, 777), `memory_learn.py` (3 locations), and 12+ other orchestration modules. Total: 18+ silent swallows.

Problem:
Silent exception swallowing hides real bugs. The Step 50.2 bugfix (commit 83f4d5e) was caused by a memory scope mismatch that went undetected because the brain graph silently returned no memory nodes instead of reporting the error. This pattern will cause more invisible data loss as the system grows.

Goal:
Replace `except Exception: pass` with structured degradation: catch specific exceptions, record a `_degraded` metadata flag on the graph/result, and optionally emit a run-log warning event. Never silently discard errors.

Relevant areas:
- `packages/orchestration/project_brain.py:620-622, 669-671, 776-778`
- `packages/orchestration/memory_learn.py:72, 107, 128`
- `packages/orchestration/context_pack.py` (2 locations)
- `packages/orchestration/autonomy_readiness.py` (1 location)
- `packages/orchestration/context_coverage.py` (1 location)

Proposed changes:
- In `build_project_brain()`: catch `ImportError` for memory (not `Exception`), add `degraded_sections: list[str]` to `ProjectBrainGraph` (or a metadata dict on the graph)
- In `memory_learn.py`: catch `FileNotFoundError | ValueError` specifically, increment `skipped_count` with reason
- Log degradation via existing run-log mechanism where a `RunLogWriter` is available
- Add tests that verify degradation is recorded (not silently swallowed)

Acceptance criteria:
- Zero `except Exception: pass` patterns remain in `packages/orchestration/`
- Each catch block either catches a specific exception type or records degradation metadata
- New unit tests verify that ImportError in memory → graph still builds with degraded flag
- All existing tests pass

Priority rationale:
Step 50.2 bugfix proves this pattern causes real production bugs. Every new commit adds more silent swallows. Fixing early prevents a class of invisible data-loss bugs.

---

## Task 04: Add Node Registry Pattern for brain_detail.py Dispatch

Impact: Medium
Effort: Medium

Context:
`brain_detail.py` has 22 `_detail_*` handler functions (1418 lines total) dispatched via a large if/elif chain in `build_brain_node_detail()`. Each handler follows the same structure: find node → build explanation → list connections → list evidence → suggest next actions. Every new node type in `project_brain.py` requires a matching handler in `brain_detail.py`.

Problem:
Adding a node type requires changes in 4+ places: `_NODE_TYPE_ORDER` dict, `build_project_brain()` section, `_detail_*` handler, and `_node_symbol()`. No compile-time or test-time check ensures all types have handlers. If a handler is missing, `build_brain_node_detail()` returns a generic fallback — silently degraded output.

Goal:
Registry-based dispatch: each node type registers its detail handler, and a test asserts completeness.

Relevant areas:
- `packages/orchestration/brain_detail.py` (entire file, 1418 lines)
- `packages/orchestration/project_brain.py` (`_NODE_TYPE_ORDER`, node type constants)
- `tests/test_brain_detail.py`

Proposed changes:
- Create `_DETAIL_REGISTRY: dict[str, Callable]` mapping node type → handler function
- Replace if/elif chain with `handler = _DETAIL_REGISTRY.get(node.type, _detail_fallback)`
- Add test: `assert set(_DETAIL_REGISTRY.keys()) >= set(project_brain._NODE_TYPE_ORDER.keys())`
- This ensures every node type added to `project_brain.py` must have a detail handler

Acceptance criteria:
- No if/elif chain for node type dispatch in `brain_detail.py`
- Test proves all node types have registered handlers
- Adding a new node type without a handler causes a test failure (not silent degradation)
- All existing tests pass

Priority rationale:
22 node types and growing. Without a registry, handler coverage will silently drift. Medium effort because the handler functions themselves don't change — only the dispatch mechanism.

---

## Task 05: Split Mega Smoke Script into Composable Test Sections

Impact: Medium
Effort: Medium

Context:
`scripts/remedy_smoke.sh` has grown to 1487 lines across the last 10 commits. Every step adds a new section (12g, 12h, 12m, 12n, 12o, 12p). The mirroring `test_remedy_smoke_script.py` is at 1443 lines and must be updated in lockstep.

Problem:
A single 1487-line bash script is fragile: any failure in section 12a aborts all subsequent sections. No way to run individual sections. Adding a new section requires understanding the entire script's variable state. The Python test file that mirrors it is equally unwieldy.

Goal:
Modular smoke sections that can run independently and be composed for full runs.

Relevant areas:
- `scripts/remedy_smoke.sh` (1487 lines)
- `tests/test_remedy_smoke_script.py` (1443 lines)

Proposed changes:
- Extract each section (0-12p) into a sourced function file: `scripts/smoke/section_00_help.sh`, `scripts/smoke/section_12g_memory.sh`, etc.
- Main `remedy_smoke.sh` becomes a 50-line runner that sources and calls sections in order
- Add `--section 12g` flag to run individual sections
- Refactor `test_remedy_smoke_script.py` to import expected outputs from section metadata rather than hardcoding 1443 lines of assertions

Acceptance criteria:
- `remedy_smoke.sh` main file is under 100 lines
- Each section is independently runnable: `./scripts/remedy_smoke.sh --section 12g`
- Full smoke run produces identical output to current script
- `test_remedy_smoke_script.py` is under 500 lines

Priority rationale:
Smoke script grows every commit. Without modularization, it will exceed 2000 lines within 5 steps. Independent sections also enable parallel smoke execution.

---

## Task 06: Build Node ID Index for O(1) Lookups in Brain Graph

Impact: Medium
Effort: Low

Context:
`build_project_brain()` performs `any(n.id == x for n in nodes)` linear scans at lines 836, 848, 856, and 915. Currently ~50 nodes per job. The aggregate graph (`project_brain_aggregate.py`) multiplies this by job count.

Problem:
Each `any()` scan is O(n). With causal edge wiring (Step 51), these scans are called inside loops over proof events and approval nodes, making total complexity O(n*m). As jobs grow to 100+ nodes (multi-task, multi-proof), this becomes measurably slow in the aggregate graph.

Goal:
O(1) node existence checks via a `set` of node IDs built once before edge-wiring sections.

Relevant areas:
- `packages/orchestration/project_brain.py:836, 848, 856, 915`
- `packages/orchestration/project_brain_aggregate.py` (similar patterns)

Proposed changes:
- After section 15 (all node-creating sections done), build `node_ids: set[str] = {n.id for n in nodes}`
- Replace `any(n.id == x for n in nodes)` with `x in node_ids`
- Apply same pattern in `project_brain_aggregate.py`

Acceptance criteria:
- Zero `any(n.id == ... for n in nodes)` patterns remain in project_brain.py
- All existing tests pass
- No API change

Priority rationale:
Low effort (4 line changes + 1 set creation). Prevents performance regression as brain graphs scale to 100+ nodes in aggregate views.

---

## Task 07: Fix Fragile Causal Edge Heuristics (Proof → Test, Proof → Memory)

Impact: Medium
Effort: Medium

Context:
Causal chain edges (Step 51, commit a79ba3b) use "last proof → last test_run" and "last proof → all memory" heuristics at `project_brain.py:866-870` and `project_brain.py:873-880`.

Problem:
When a job has multiple patch_apply_proof nodes and multiple test_run nodes, only the last proof connects to the last test. Earlier proofs have no `proof_verified_by` edge. All memory nodes connect to the last proof only, even if memory was learned from an earlier proof. This creates incorrect causal chains in multi-patch jobs.

Goal:
Temporal correlation: each proof connects to the first test_run that chronologically follows it, and memory entries connect to the proof whose source_id matches.

Relevant areas:
- `packages/orchestration/project_brain.py:862-880` (causal edge section 16)
- `tests/test_project_brain.py`

Proposed changes:
- For `proof_verified_by`: sort proof and test_run events by index, connect each proof to the next test_run event (by chronological order in the event list)
- For `informed_memory`: check `memory.source_id` against `proof.intent_id` to create specific links instead of broadcasting
- Add test with 2 proofs and 2 test runs verifying each proof connects to its own test run
- Add test with 2 proofs and 2 memory entries verifying specific linkage

Acceptance criteria:
- Multi-proof jobs produce correct per-proof causal chains
- Memory entries link to their actual source proof, not the last one
- Existing single-proof tests still pass
- New multi-proof test cases pass

Priority rationale:
Causal graph correctness is foundational to file provenance (`remedy file why`) and trust report. Wrong edges = wrong provenance = wrong trust assessment. Gets worse as jobs become multi-patch.

---

## Task 08: Resolve Circular Import Dependencies (6 Inline Imports)

Impact: Medium
Effort: Medium

Context:
`build_project_brain()` has 6 inline imports at lines 587, 688, 711, 733, 755-757: `local_gateway`, `run_contract`, `token_policy`, `worker_adapters`, `autonomy_readiness`, `data_paths`, `timeline`. These were added across the last 10 commits as new brain sections grew.

Problem:
Inline imports indicate circular dependency chains between orchestration modules. They make the function harder to understand (imports scattered in function body), slower on first call (import overhead), and prevent static analysis tools from detecting missing dependencies.

Goal:
Clean top-level imports or explicit dependency injection via function parameters.

Relevant areas:
- `packages/orchestration/project_brain.py:587, 688, 711, 733, 755-757`
- `packages/orchestration/run_contract.py`
- `packages/orchestration/token_policy.py`
- `packages/orchestration/worker_adapters.py`
- `packages/orchestration/autonomy_readiness.py`
- `packages/memory/local_gateway.py`

Proposed changes:
- Map the actual import dependency graph to identify cycles
- For modules without circular dependency: move to top-level imports
- For modules with actual circular dependency: break cycle by extracting shared types into a `_types.py` module or by injecting dependencies as optional parameters to `build_project_brain()`
- Example: `build_project_brain(..., memory_entries=None, run_contract=None)` — caller provides pre-loaded data instead of brain building importing everything

Acceptance criteria:
- Zero inline imports inside `build_project_brain()` function body
- All imports are either top-level or explicitly justified with a comment
- No circular import errors on `python -c "from packages.orchestration.project_brain import *"`
- All existing tests pass

Priority rationale:
6 inline imports is a design smell that blocks Task 01 (decomposition). If section builders can't import their dependencies at top level, extraction is messy. Resolving this first (or alongside) Task 01 is essential.

---

## Task 09: Add Integration Tests for continue_from_node Round-Trip

Impact: Medium
Effort: Low

Context:
`continue_from_node.py` (Step 52, commit 4af9171) creates child jobs from brain nodes. Currently only tested via smoke script (section 12o) which checks JSON structure. No pytest-level integration test validates the full round-trip: create parent → build brain → continue from node → verify child brain has parent linkage.

Problem:
Smoke tests run in subprocess and only assert JSON key presence. They don't verify: (a) child job's metadata correctly references parent, (b) parent brain graph contains `continued_as` edge, (c) child brain graph can be built without error, (d) project_brain_aggregate correctly includes both jobs.

Goal:
Pytest integration test covering the full parent→child→brain linkage chain.

Relevant areas:
- `packages/orchestration/continue_from_node.py`
- `packages/orchestration/project_brain.py` (section 17, continued_as edges)
- `packages/orchestration/project_brain_aggregate.py`
- `tests/` (new test file or extend `test_project_brain.py`)

Proposed changes:
- Add `test_continue_from_node_round_trip()`: create job, build events, build brain, call continue_from_node, verify child metadata
- Add `test_parent_brain_has_continued_as_edge()`: verify parent brain graph has continued_as edge to child placeholder
- Add `test_aggregate_includes_child_job()`: verify project aggregate includes both parent and child
- Add `test_continue_from_invalid_node_raises()`: verify ValueError on non-existent node_id

Acceptance criteria:
- 4 new pytest tests covering the round-trip
- Tests run without smoke script or subprocess
- Tests verify data integrity, not just JSON structure
- All tests pass

Priority rationale:
Low effort (continue_from_node is small and well-structured). High confidence gain — ensures the parent→child linkage contract doesn't silently break in future commits.

---

## Task 10: Enforce Commit Size Discipline in Agent Workflow

Impact: Low
Effort: Low

Context:
Commits 75ecfb9 (2874 lines, 4 features) and 4982137 (1240 lines, 5 parts) bundle multiple independent features/fixes into single commits. AGENTS.md explicitly says "keep commits small and logically scoped" and "avoid large or mixed commits."

Problem:
Large bundled commits are review-hostile (can't approve/reject individual features), bisect-hostile (can't isolate regressions), and revert-hostile (can't undo one feature without undoing all). The Step 50.2 bugfix (83f4d5e) was a direct consequence of a bundled commit masking scope issues.

Goal:
Prevent future mega commits through enforceable guardrails.

Relevant areas:
- `AGENTS.md` (commit discipline section)
- `.agent/plan.md` (step planning)

Proposed changes:
- Add to AGENTS.md: explicit line-count threshold — "If `git diff --stat` shows more than 500 lines changed, the commit MUST be split"
- Add to AGENTS.md: feature-count rule — "Each commit addresses exactly one step or sub-step. Multi-step commits (e.g., 'Steps 46.2 + 48-50') are not allowed"
- Add a pre-commit hook or smoke check that warns on >500 line diffs
- Update `.agent/plan.md` template to require one commit per step

Acceptance criteria:
- AGENTS.md contains explicit commit size threshold (500 lines)
- AGENTS.md contains explicit one-step-per-commit rule
- Optional: pre-commit hook warns on oversized diffs
- Future commits from agent workflows respect the threshold

Priority rationale:
Low effort (documentation + optional hook). Prevents the root cause of several issues found in this review. Process improvement rather than code change, but directly impacts code quality.
