# Brainstorm Tasks — 2026-05-28_001

## Task 01: Implement Agent Loop Execution Engine

Impact: High
Effort: High

Context:
`packages/orchestration/agent_loop.py` defines `AgentLoopState`, `AgentLoopStage`, `AgentLoopDecision`, and `AgentAdapterSpec` — all as contract-only models. `derive_agent_loop_state()` computes the next decision but nothing acts on it. Every `AgentAdapterSpec` instance defaults to `dry_run_only=True`. The CLI command `remedy agent-loop <job_id>` only inspects — it never advances work. Steps 35-40 claim "execution foundation" but the loop never runs.

Problem:
Remedy cannot execute a job end-to-end without manual `run-next-task-local` calls per task. Every competitor (Devin, SWE-Agent, OpenHands, Aider) has an autonomous loop. Without one, Remedy is a planning-and-inspection tool, not an orchestration kernel.

Goal:
Implement the core agent loop execution engine that consumes `AgentLoopState` decisions and drives `plan → build → verify → approve → apply` cycles automatically, with configurable `max_cycles`, human-approval gates, and graceful interruption.

Relevant areas:
- packages/orchestration/agent_loop.py (contract models, `derive_agent_loop_state`)
- packages/orchestration/task_runner.py (`run_next_task`, `finalize_task`)
- packages/orchestration/llm_planner.py (`plan_job_with_llm`)
- apps/cli/main.py (`_cmd_agent_loop`, `_cmd_run_next_task_local`)
- packages/contracts/interfaces.py (`LLMWorker` protocol)

Proposed changes:
- Add `run_agent_loop(job, *, builder, planner, runtime, max_cycles=3, approval_mode="manual")` to `agent_loop.py`
- Implement the state machine: call `derive_agent_loop_state`, match on `decision`, execute the corresponding action (`continue` → `run_next_task`, `needs_approval` → pause, `blocked` → halt)
- Add `remedy run-loop <job_id>` CLI command that wires providers and runs the loop
- Emit `agent_loop_cycle_started`, `agent_loop_cycle_completed`, `agent_loop_completed` run-log events
- Respect existing permission gates (`workspace_write`, `repo_generated_write`)
- Add `--auto-approve-low-risk` flag for unattended execution of low-risk intents

Acceptance criteria:
- `remedy run-loop <job_id>` plans a job, executes all tasks, verifies, derives patch intents, and reaches `completed` state without manual intervention (for low-risk jobs)
- High/medium-risk patch intents pause the loop and require `approve-patch-intent` before continuing
- `max_cycles` is enforced — loop halts with a clear message if exceeded
- All existing tests pass; new tests cover loop state transitions, interruption, and cycle limits
- Run-log events trace every cycle start/stop/decision

Priority rationale:
This is the single most impactful improvement. Without autonomous execution, Remedy cannot compete with any modern AI coding agent. The contract layer is already built — the implementation is the missing piece.

---

## Task 02: Implement Sandboxed Code Execution Runtime

Impact: High
Effort: High

Context:
`packages/runtimes/` is empty. `packages/contracts/interfaces.py` defines `RuntimeProvider` protocol with `execute(command, *, timeout, cwd)`. `packages/orchestration/workspace.py` has `LocalWorkspaceRuntime` which only writes text files — it never executes commands. Builder output is "proposed changes" as text, never compiled, run, or tested.

Problem:
Remedy's architecture promises "swap the runtime (local shell, Docker, remote) without changing task logic" but no runtime exists beyond file writing. The builder generates plans describing code changes but nothing verifies they work. This makes Remedy's verification layer incomplete — it checks artifact structure but never functional correctness.

Goal:
Implement at least a local sandboxed runtime and a Docker-based runtime that can execute shell commands, run tests, compile code, and capture output — all permission-gated by `shell_exec` capability.

Relevant areas:
- packages/runtimes/ (empty — target location)
- packages/contracts/interfaces.py (`RuntimeProvider` protocol)
- packages/orchestration/workspace.py (`LocalWorkspaceRuntime`)
- packages/orchestration/permissions.py (`shell_exec` capability — reserved, not enforced)
- packages/orchestration/task_runner.py (`materialize_task_output`)

Proposed changes:
- Create `packages/runtimes/local_runtime.py` implementing `RuntimeProvider` with subprocess execution, timeout enforcement, output capture, and working directory isolation
- Create `packages/runtimes/docker_runtime.py` implementing `RuntimeProvider` with Docker container lifecycle, volume mounting, network isolation
- Enforce `shell_exec` permission check before any command execution
- Add `RuntimeResult` model: `exit_code`, `stdout`, `stderr`, `elapsed_ms`, `timed_out`
- Wire runtime into `task_runner.py` — after builder returns proposed changes, optionally execute validation commands
- Add run-log events: `runtime_command_started`, `runtime_command_completed`, `runtime_command_failed`
- Add `remedy run-command <job_id> <command>` CLI for ad-hoc sandboxed execution

Acceptance criteria:
- `shell_exec` permission must be explicitly granted before any command runs
- Local runtime enforces configurable timeout (default 60s)
- Docker runtime creates an isolated container per execution, cleans up on completion
- Command output is captured in `RuntimeResult` and recorded in artifact metadata
- Existing tests pass; new tests cover timeout, permission denial, and Docker fallback
- Run-log events trace every command execution

Priority rationale:
Code execution is what separates a real orchestration kernel from a planning tool. The runtime provider protocol exists but is hollow. Filling it unlocks functional verification, test running, and build validation — all critical for quality-gated autonomous loops.

---

## Task 03: Add Claude and OpenAI Provider Implementations

Impact: High
Effort: Medium

Context:
Only two providers exist: `packages/providers/ollama_planner/provider.py` and `packages/providers/ollama_builder/provider.py`. Both call local Ollama. The architecture explicitly plans for `claude_planner` and `claude_builder` (README even says "Adding a second planner (e.g. Claude)"). The `PlannerOutput` and `BuilderOutput` contracts are provider-agnostic. No cloud LLM is supported.

Problem:
Ollama-only limits adoption to users with local GPU setups. Most developers use cloud LLMs (Claude, GPT-4, etc.). Without cloud provider support, Remedy cannot serve the majority of potential users. "Best orchestration kernel" requires provider breadth.

Goal:
Implement Claude (Anthropic API) and OpenAI provider adapters for both planner and builder roles, following the existing Ollama pattern.

Relevant areas:
- packages/providers/ollama_planner/provider.py (reference: planner pattern)
- packages/providers/ollama_builder/provider.py (reference: builder pattern)
- packages/orchestration/planner_models.py (`PlannerOutput` contract)
- packages/orchestration/builder_models.py (`BuilderOutput`, `TaskExecutionContext`)
- pyproject.toml (optional dependencies)

Proposed changes:
- Create `packages/providers/claude_planner/provider.py` with `ClaudePlanner` class using `anthropic` SDK
- Create `packages/providers/claude_builder/provider.py` with `ClaudeBuilder` class
- Create `packages/providers/openai_planner/provider.py` with `OpenAIPlanner` class using `openai` SDK
- Create `packages/providers/openai_builder/provider.py` with `OpenAIBuilder` class
- Add `anthropic` and `openai` as optional dependencies in `pyproject.toml`
- Add `REMEDY_CLAUDE_MODEL`, `REMEDY_OPENAI_MODEL` env var patterns matching the Ollama convention
- Add `remedy plan-job-claude`, `remedy plan-job-openai` CLI commands
- Add `remedy run-next-task-claude`, `remedy run-next-task-openai` CLI commands
- All providers lazy-import their SDK (same pattern as Ollama)

Acceptance criteria:
- `remedy plan-job-claude <job_id>` produces a valid `PlannerOutput` using Claude API
- `remedy run-next-task-openai <job_id>` executes a task using OpenAI API
- API key configuration via `ANTHROPIC_API_KEY` / `OPENAI_API_KEY` env vars
- Missing SDK raises a clear "install with `pip install remedy[claude]`" error
- Existing Ollama tests unaffected; new tests mock the SDK calls
- Role-specific model/temperature env vars follow the existing naming convention

Priority rationale:
Provider breadth is table stakes for adoption. The architecture was designed for this — the contracts exist, the wiring pattern is proven, the implementation is mechanical. High impact for medium effort.

---

## Task 04: Add CI/CD Pipeline with Linting and Type Checking

Impact: High
Effort: Low

Context:
No CI/CD exists. No `.github/workflows/`, no `Makefile`, no pre-commit hooks. No linting tools configured (ruff, mypy, black, flake8). `pyproject.toml` has only `pytest` as a dev dependency. 2287 tests pass locally but nothing verifies this on push.

Problem:
"Best" open-source projects have green CI badges, enforced code quality, and automated checks. Without CI, regressions can slip in silently. Without linting/typing, code quality depends entirely on manual review. No contributor will trust a project without automated quality gates.

Goal:
Set up GitHub Actions CI with pytest, ruff (linting), mypy (type checking), and a pre-commit configuration for local developer experience.

Relevant areas:
- pyproject.toml (dev dependencies, tool config)
- (new) .github/workflows/ci.yml
- (new) .pre-commit-config.yaml
- (new) pyproject.toml `[tool.ruff]` and `[tool.mypy]` sections

Proposed changes:
- Create `.github/workflows/ci.yml` with matrix: Python 3.10, 3.11, 3.12, 3.13
- Add steps: checkout → setup-python → pip install -e ".[dev]" → ruff check → mypy → pytest
- Add `[tool.ruff]` to `pyproject.toml`: target Python 3.10, select rules (E, F, W, I, UP, B, SIM)
- Add `[tool.mypy]` to `pyproject.toml`: strict mode with per-module overrides for providers
- Add ruff, mypy to `[project.optional-dependencies] dev`
- Create `.pre-commit-config.yaml` with ruff and mypy hooks
- Fix any existing lint/type errors surfaced by the new tools
- Add CI badge to README.md

Acceptance criteria:
- CI runs on every push and PR to `main`
- `ruff check .` passes with zero violations
- `mypy packages/ apps/` passes (possibly with `--ignore-missing-imports` for optional deps)
- `pytest` passes in CI for all supported Python versions
- Pre-commit hooks catch issues before commit locally
- README displays a CI status badge

Priority rationale:
Low effort, high credibility impact. Every "best" project has CI. This is the fastest way to demonstrate project maturity and protect against regressions. It also catches existing issues early.

---

## Task 05: Implement Configuration System (remedy.toml)

Impact: Medium
Effort: Medium

Context:
All configuration is via environment variables: `REMEDY_DATA_DIR`, `REMEDY_OLLAMA_PLANNER_MODEL`, `REMEDY_OLLAMA_BUILDER_MODEL`, `REMEDY_OLLAMA_HOST`, plus per-role temperature/num_predict vars. There are 12+ env vars with no validation beyond parse-time errors. No project-level config. No provider registry. The `OllamaPlanner` and `OllamaBuilder` constructors read env vars directly.

Problem:
Environment variables don't scale beyond a handful of settings. Multi-project setups with different providers/models require shell scripts to manage vars. There's no way to declare "this project uses Claude for planning and Ollama for building" in a file. No config inheritance (global → project → job).

Goal:
Implement a `remedy.toml` configuration file system with layered resolution: global defaults → project config → env var overrides.

Relevant areas:
- packages/providers/ollama_planner/provider.py (env var reading)
- packages/providers/ollama_builder/provider.py (env var reading)
- packages/orchestration/data_paths.py (`REMEDY_DATA_DIR`)
- apps/cli/main.py (provider instantiation)

Proposed changes:
- Create `packages/orchestration/config.py` with `RemedyConfig` Pydantic model
- Support `~/.config/remedy/config.toml` (global) and `./remedy.toml` (project-level)
- Config schema: `[providers.planner]`, `[providers.builder]`, `[storage]`, `[permissions]`
- Env vars override config file values (highest priority)
- Add `remedy config show` and `remedy config init` CLI commands
- Migrate provider instantiation from direct env-var reads to config resolution
- Preserve backward compatibility: existing env vars still work

Acceptance criteria:
- `remedy config init` creates a commented `remedy.toml` with all available settings
- Config resolution: env var > project toml > global toml > built-in defaults
- All existing env-var-based workflows continue to work unchanged
- `remedy config show` displays resolved effective configuration
- Tests cover config layering, missing files, and env-var overrides

Priority rationale:
Configuration is foundational infrastructure. Adding providers (Task 03) and the agent loop (Task 01) will multiply the number of settings. Building the config system now prevents env-var sprawl and enables project-level customization.

---

## Task 06: Refactor CLI from Monolith to Command-Per-File Pattern

Impact: Medium
Effort: Medium

Context:
`apps/cli/main.py` is 1983 lines with 54 command functions. Every command lives in one file. `grouped.py` handles dispatch with hardcoded group names and option routing. `command_catalog.py` defines the registry but all implementations are in `main.py`. Adding a new command means editing the 1983-line file, adding catalog entry, and updating grouped routing.

Problem:
A 2000-line CLI module is hard to navigate, review, and extend. New contributors must understand the entire file to add a command. Merge conflicts are common when multiple features touch the same file. The current pattern doesn't scale past ~30 commands, and Remedy already has 54.

Goal:
Split CLI into one file per command group, with a clean registration pattern that auto-discovers commands.

Relevant areas:
- apps/cli/main.py (54 command functions, 1983 lines)
- apps/cli/grouped.py (dispatch, group routing)
- apps/cli/command_catalog.py (command registry)
- apps/cli/help_renderer.py (help display)

Proposed changes:
- Create `apps/cli/commands/` directory with one file per group: `job.py`, `plan.py`, `execute.py`, `verify.py`, `brain.py`, `project.py`, `patch.py`, `permission.py`
- Each command file exports a list of `(name, handler, catalog_entry)` tuples
- Update `grouped.py` to auto-discover command files via `importlib`
- Move each `_cmd_*` function from `main.py` to its group file
- Keep `main.py` as thin entry point (< 50 lines)
- Keep `command_catalog.py` as the type-safe registry definition
- Preserve all existing command names and behavior

Acceptance criteria:
- `main.py` is under 50 lines
- Each command group file is under 300 lines
- All 54 commands work identically to before
- Adding a new command requires only editing one group file
- All existing tests pass without modification
- `remedy --help` and group help render correctly

Priority rationale:
CLI is the primary user interface. A 2000-line monolith will slow down every future feature. Splitting it now pays dividends for every subsequent task (agent loop CLI, new provider commands, config commands).

---

## Task 07: Create Getting Started Guide and CLI Reference

Impact: Medium
Effort: Low

Context:
Documentation consists of one file: `docs/architecture.md` (2923 lines). README.md has usage examples per step but reads like a changelog, not an onboarding guide. No Getting Started guide. No CLI reference. No Contributing guide. No provider development guide. New users must read 2900 lines of architecture to understand how to use the tool.

Problem:
Documentation is the #1 barrier to adoption. Even a perfect tool fails without onboarding docs. The current README is a development log. No one can go from zero to running Remedy in under 5 minutes with current docs.

Goal:
Create a Getting Started guide (zero to running in 5 minutes), a CLI reference (all commands with examples), and a Contributing guide.

Relevant areas:
- README.md (current dev-log style readme)
- docs/architecture.md (reference material)
- apps/cli/command_catalog.py (command definitions)
- apps/cli/help_renderer.py (help text)

Proposed changes:
- Rewrite `README.md` to be a concise project overview with quick-start section
- Create `docs/getting-started.md`: install, create job, plan, execute, inspect, approve
- Create `docs/cli-reference.md`: auto-generated or manually curated from `command_catalog.py`
- Create `CONTRIBUTING.md`: dev setup, running tests, code style, PR workflow
- Create `docs/providers.md`: how to implement a custom provider (planner or builder)
- Keep `docs/architecture.md` as deep technical reference, link to it from other docs

Acceptance criteria:
- A new user can install Remedy, create a job, plan it, and execute a task by following the Getting Started guide alone
- CLI reference covers all commands with usage and examples
- CONTRIBUTING.md explains how to set up dev environment, run tests, and submit PRs
- README.md is under 200 lines and focuses on what/why/quickstart

Priority rationale:
Low effort, high adoption impact. Documentation is the first thing potential users and contributors see. Best-in-class projects have excellent onboarding. This unlocks community growth.

---

## Task 08: Implement Memory Gateway v0 (Cross-Job Learning)

Impact: Medium
Effort: High

Context:
`packages/memory/` is empty. `packages/contracts/interfaces.py` defines `MemoryGateway` protocol with `store(key, value, context)` and `recall(query, context, *, limit)`. Architecture doc mentions MemPalace integration. `context_coverage.py` has `project_memory` signal (always absent, weight 10). Brain graph has `memory_placeholder` node. No cross-job learning exists.

Problem:
Each job starts from zero context. Lessons learned, successful patterns, and failed approaches from previous jobs are lost. A best-in-class orchestration kernel should accumulate knowledge over time. Without memory, Remedy cannot improve across runs.

Goal:
Implement a local file-backed `MemoryGateway` that stores and recalls key-value context across jobs, with semantic search preparation for future MemPalace integration.

Relevant areas:
- packages/memory/ (empty — target location)
- packages/contracts/interfaces.py (`MemoryGateway` protocol)
- packages/orchestration/context_coverage.py (`project_memory` signal)
- packages/orchestration/project_brain.py (`memory_placeholder` node)
- packages/orchestration/artifact_index.py (artifact queries)

Proposed changes:
- Create `packages/memory/local_gateway.py` implementing `MemoryGateway`
- Storage: JSONL file per project under `<REMEDY_DATA_DIR>/memory/<project_id>/`
- `store()` appends a timestamped entry with key, value, context tags
- `recall()` does keyword matching on key + context (v0 — no embeddings)
- Auto-store: after task completion, store task type + summary + outcome
- Auto-recall: before builder call, recall relevant entries for the task type
- Wire into `TaskExecutionContext` as optional `memory_context` field
- Update `context_coverage.py` to detect real memory entries
- Replace `memory_placeholder` with live memory nodes in Brain graph
- Add `remedy memory-store <job_id> <key> <value>` and `remedy memory-recall <query>` CLI commands

Acceptance criteria:
- `store()` persists entries that survive process restart
- `recall()` returns relevant entries sorted by recency and keyword relevance
- `TaskExecutionContext` includes memory context when available
- `project_memory` signal in context coverage becomes active
- Memory nodes appear in Brain graph replacing placeholders
- Tests cover store/recall cycle, empty gateway, and context filtering

Priority rationale:
Cross-job learning is the long-term moat. Competitors don't have it. Building v0 now — even with simple keyword matching — establishes the data contract and storage pattern that MemPalace integration will extend.

---

## Task 09: Implement Code File Patch Application

Impact: Medium
Effort: Medium

Context:
`packages/orchestration/patch_apply.py` only handles markdown files (`.md`). `verify_patch_intent_set` in `patch_intent.py` enforces `target_path.endswith(".md")`. The architecture says "Arbitrary unified-diff application: not implemented" and "Code-file patching: not implemented". The approval queue and proof chain are built but only work for documentation files.

Problem:
An orchestration kernel that can only write markdown is severely limited. Real development requires patching Python, TypeScript, YAML, and other code files. The entire approval→apply pipeline exists but is artificially restricted to `.md`. Users need Remedy to make real code changes.

Goal:
Extend patch application to support code files (`.py`, `.ts`, `.js`, `.yaml`, `.toml`, `.json`) with safety-gated unified diff application and content-preserving append for non-diff changes.

Relevant areas:
- packages/orchestration/patch_apply.py (markdown-only apply)
- packages/orchestration/patch_intent.py (`verify_patch_intent_set` — `.md` only check)
- packages/orchestration/markdown_output_safety.py (safety helpers)
- packages/orchestration/permissions.py (`repo_overwrite` — reserved)

Proposed changes:
- Extend `verify_patch_intent_set` to accept configured file extensions (default: `.md`, `.py`, `.ts`, `.js`, `.yaml`, `.toml`, `.json`)
- Create `packages/orchestration/code_patch.py` with unified diff application logic
- Add `apply_code_patch(intent, artifact_content, repo_root)` that applies structured changes
- Gate code patching behind `repo_overwrite` permission (elevate from reserved to active)
- For `modify` action on code files: apply as unified diff when available, append as comment block when not
- For `create` action on code files: write full content directly
- Add safety: backup original file before modify, validate syntax post-apply for Python files
- Extend task registry to map code task types (`write_code`, `write_tests`, `refactor`) to code file paths
- Add run-log events: `code_patch_applied`, `code_patch_backup_created`

Acceptance criteria:
- `remedy apply-patch <job_id> <intent_id>` works for `.py` and `.ts` files
- `repo_overwrite` permission is enforced before any code file modification
- Original files are backed up before modification
- Python files are syntax-checked after patching (via `compile()`)
- Markdown apply behavior is unchanged
- Tests cover create, modify, backup, syntax validation, and permission denial
- Smoke test covers end-to-end code patch lifecycle

Priority rationale:
Code patching transforms Remedy from a documentation tool to a real development automation tool. The entire approval/proof chain is already built — extending to code files leverages all existing infrastructure. Blocked by Task 02 (runtime) for full validation but can be built independently.

---

## Task 10: Implement Multi-Provider Routing and Fallback

Impact: Medium
Effort: Medium

Context:
Provider selection is hardcoded per CLI command: `plan-job-local` always uses Ollama planner, `run-next-task-local` always uses Ollama builder. No routing logic. No fallback chain. No cost/latency awareness. `task_registry.py` has `suggested_agent_role` field but it's always `"generic_builder"`. Architecture mentions "Every layer is replaceable" but replacement is manual.

Problem:
Best-in-class systems route requests to the right model based on task complexity, cost constraints, and provider availability. A simple task shouldn't use GPT-4o; a complex architecture task shouldn't use a 7B local model. Without routing, users must manually choose providers — breaking autonomous execution.

Goal:
Implement a provider routing layer that selects the best provider/model combination based on task type, complexity signals, cost constraints, and provider availability, with automatic fallback on failure.

Relevant areas:
- packages/providers/ (ollama_planner, ollama_builder — reference)
- packages/orchestration/task_registry.py (`TaskTypeSpec.suggested_agent_role`)
- packages/contracts/interfaces.py (`LLMWorker` protocol)
- apps/cli/main.py (provider instantiation)

Proposed changes:
- Create `packages/orchestration/provider_router.py` with `ProviderRouter` class
- Define `ProviderSpec`: name, role, model, cost_tier (low/medium/high), capabilities
- Router resolves `(task_type, role)` → `ProviderSpec` using task registry + config
- Fallback chain: if primary provider fails, try next in chain (e.g., Claude → OpenAI → Ollama)
- Add `[routing]` section to `remedy.toml`: default provider per role, fallback order
- Track provider success/failure rates in run logs for future routing optimization
- Add `remedy providers` CLI command to list available and configured providers
- Replace per-provider CLI commands (`plan-job-local`, `run-next-task-local`) with unified `remedy plan-job <job_id>` and `remedy run-task <job_id>` that use the router
- Keep explicit `--provider ollama` flag for override

Acceptance criteria:
- `remedy plan-job <job_id>` automatically selects the configured provider
- Fallback triggers on provider failure (network error, API error) and succeeds with next provider
- `remedy providers` lists all registered providers with status (available/configured/missing)
- Provider selection is logged in run-log events
- Existing `plan-job-local` / `run-next-task-local` commands still work (backward compat)
- Tests cover routing resolution, fallback chain, and config-based overrides

Priority rationale:
Multi-provider routing completes the picture: autonomous loop (Task 01) + cloud providers (Task 03) + routing = fully autonomous, intelligent execution. Without routing, users must manually wire providers — which defeats autonomous orchestration.
