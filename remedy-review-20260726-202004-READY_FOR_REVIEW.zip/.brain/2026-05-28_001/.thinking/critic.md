# Critic Pass

## Removed Ideas (Generic/Ungrounded)
- "Add more tests" — already 2287 tests, test count not the problem
- "Improve error messages" — current error handling is actually decent
- "Add logging" — run_log.py already handles this well
- "Add type hints" — already has good type hint coverage

## Sharpened Ideas
- "Add CI" → specific: ruff + mypy + pytest in GitHub Actions, pre-commit hooks
- "Split CLI" → specific: command-per-file pattern using command_catalog registry
- "Add Claude provider" → specific: packages/providers/claude_planner + claude_builder
- "Add config" → specific: remedy.toml with provider/model/project defaults

## Priority Reasoning
1. Agent loop execution beats everything — without it, Remedy is a planning tool, not an orchestration kernel
2. Code execution runtime is #2 — the whole promise is "coordinate tasks" but tasks can't run code
3. Claude/OpenAI providers are #3 — Ollama-only limits adoption massively
4. CI/CD is #4 — credibility for "best" requires green badges
5. Config system is #5 — env-var-only breaks at scale
6. CLI refactor is #6 — 1983-line main.py is a maintenance timebomb
7. Getting Started docs are #7 — without onboarding, no contributors
8. Memory/MemPalace v0 is #8 — cross-job learning is the long-term moat
9. Code patch application is #9 — markdown-only limits real-world utility
10. Multi-provider routing is #10 — cost/quality optimization is table stakes
