# Analysis

## What Remedy Does Well
1. Clean architecture — strict core/provider separation, protocol-based contracts
2. Comprehensive documentation — 2923-line architecture.md covers every step
3. Massive test suite — 2287 tests, all passing, parametrized coverage
4. Conservative safety model — redaction policy, permission model, boundary-safe paths
5. Brain graph + viewer — unique differentiator for auditability
6. Deterministic verifier — no LLM in verification loop
7. Artifact provenance chain — full intent→approval→apply lifecycle

## Critical Gaps (What "Best" Requires)

### 1. No Agent Loop Execution
Steps 35-40 are "execution foundation" but agent_loop.py is contract-only.
No external agent is ever called. The project cannot run end-to-end autonomously.
This is the #1 gap — every competitor (Devin, SWE-Agent, OpenHands) runs code.

### 2. Only Ollama Providers — No Claude/OpenAI/Anthropic
Only one LLM backend (Ollama). No cloud provider. No API key config.
Best-in-class needs at least Claude + OpenAI support.

### 3. No Code Execution Runtime
No Docker, no sandbox, no shell_exec enforcement.
Builder output is "proposed changes" in text — never applied as code.
packages/runtimes/ is empty.

### 4. No CI/CD or Quality Gates
No GitHub Actions, no pre-commit, no ruff/mypy/black.
No automated test runs. No branch protection.
Any serious OSS project needs this.

### 5. No Real Configuration System
All config is env vars. No TOML/YAML config file.
No project-level settings. No provider registry.

### 6. Monolithic CLI (main.py = 1983 lines)
54 command functions in one file. 60+ LOC argparse boilerplate.
Grouped routing is hardcoded. Not extensible.

### 7. No Async Support
All orchestration is synchronous. No concurrent task execution.
LLM calls block the main thread.

### 8. Documentation Gaps
Only architecture.md. No:
- Getting Started guide
- CLI reference
- Contributing guide
- API documentation
- Provider development guide

### 9. No Memory/MemPalace Implementation
packages/memory/ is empty. No cross-job learning.
No semantic search over past artifacts.

### 10. No Multi-Provider Routing
No cost/latency-aware model selection.
No fallback chains. No provider health checks.

### 11. Pydantic Validation Sparse
Most string fields lack constraints (min_length, max_length, pattern).
BuilderOutput.notes/risks allow unbounded lists.

### 12. No Patch Application for Code
patch_apply.py only handles markdown.
No unified diff, no code file patching.
This is what makes the tool useful — applying patches.

### 13. No Observability Beyond Run Logs
No structured metrics, no OpenTelemetry, no dashboard.
Run logs are JSONL — no aggregation or querying tool.
