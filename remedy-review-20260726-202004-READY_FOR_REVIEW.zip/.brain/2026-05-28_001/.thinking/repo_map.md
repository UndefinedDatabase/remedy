# Repo Map

## Structure
```
apps/cli/          — 4 files: main.py (1983L), grouped.py, command_catalog.py, help_renderer.py
apps/api/          — empty __init__
apps/worker/       — empty __init__
packages/core/     — models.py (140L), 1 __init__
packages/contracts/ — interfaces.py (114L), 6 protocols
packages/orchestration/ — 38 modules, dominant package:
  storage.py, job_runner.py, task_runner.py, workspace.py, verifier.py,
  llm_planner.py, planner_models.py, builder_models.py, permissions.py,
  run_log.py, timeline.py, cockpit.py, approval_queue.py, trust_report.py,
  project_constitution.py, agent_loop.py, verifier_profiles.py,
  artifact_index.py, task_registry.py, patch_intent.py, patch_apply.py,
  repo_applicator.py, brain_viewer.py, brain_detail.py, project_brain.py,
  context_coverage.py, project_registry.py, project_context_coverage.py,
  markdown_output_safety.py, data_paths.py, path_utils.py
packages/memory/    — empty
packages/runtimes/  — empty
packages/verification/ — empty
packages/artifacts/ — empty
packages/providers/ollama_planner/ — provider.py
packages/providers/ollama_builder/ — provider.py
tests/             — 46 files, 2287 tests (all pass)
docs/              — architecture.md (2923L)
scripts/           — remedy_smoke.sh
```

## Stats
- 53 Python modules
- 46 test files, 2287 tests, 0 failures
- 1 doc file (architecture.md)
- No CI/CD, no linting, no type checking, no Dockerfile
- No CHANGELOG
- Version 0.1.0
- Dependencies: pydantic, ollama (optional)
