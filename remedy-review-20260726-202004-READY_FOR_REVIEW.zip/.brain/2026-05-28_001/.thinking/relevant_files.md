# Relevant Files Per Task

## Task 01 (Agent Loop Execution)
- packages/orchestration/agent_loop.py — contract models, derive_agent_loop_state
- packages/orchestration/task_runner.py — run_next_task
- packages/orchestration/llm_planner.py — plan_job_with_llm
- apps/cli/main.py — _cmd_agent_loop, _cmd_run_next_task_local
- packages/contracts/interfaces.py — LLMWorker protocol

## Task 02 (Code Execution Runtime)
- packages/runtimes/ — empty, target location
- packages/orchestration/workspace.py — LocalWorkspaceRuntime
- packages/contracts/interfaces.py — RuntimeProvider protocol
- packages/orchestration/task_runner.py — materialize_task_output

## Task 03 (Claude/OpenAI Providers)
- packages/providers/ollama_planner/provider.py — reference implementation
- packages/providers/ollama_builder/provider.py — reference implementation
- packages/orchestration/planner_models.py — PlannerOutput contract
- packages/orchestration/builder_models.py — BuilderOutput contract
- pyproject.toml — optional dependencies

## Task 04 (CI/CD)
- pyproject.toml — dev dependencies
- (new) .github/workflows/ci.yml
- (new) .pre-commit-config.yaml
- (new) pyproject.toml [tool.ruff] section

## Task 05 (Config System)
- packages/providers/ollama_planner/provider.py — env var reading
- packages/providers/ollama_builder/provider.py — env var reading
- packages/orchestration/data_paths.py — REMEDY_DATA_DIR

## Task 06 (CLI Refactor)
- apps/cli/main.py — 1983 lines, 54 command functions
- apps/cli/grouped.py — dispatch
- apps/cli/command_catalog.py — registry

## Task 07 (Getting Started Docs)
- docs/architecture.md — existing reference
- README.md — current readme

## Task 08 (Memory v0)
- packages/memory/ — empty
- packages/contracts/interfaces.py — MemoryGateway protocol
- packages/orchestration/artifact_index.py — artifact queries

## Task 09 (Code Patch Application)
- packages/orchestration/patch_apply.py — markdown-only
- packages/orchestration/patch_intent.py — intent model
- packages/orchestration/markdown_output_safety.py — safety helpers

## Task 10 (Multi-Provider Routing)
- packages/providers/ — ollama_planner, ollama_builder
- packages/orchestration/task_registry.py — TaskTypeSpec.suggested_agent_role
- packages/contracts/interfaces.py — LLMWorker protocol
