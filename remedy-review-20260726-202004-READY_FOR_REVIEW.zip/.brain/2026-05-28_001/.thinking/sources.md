# Sources

## Files Read Directly
- AGENTS.md — agent operating rules
- CLAUDE.md — project instructions
- README.md — project overview and step history
- pyproject.toml — build config, dependencies
- docs/architecture.md (lines 1-2200) — full architecture reference

## Investigator Agents (4 parallel)
1. Core models + contracts investigator: models.py, interfaces.py, storage.py, job_runner.py, planner_models.py, builder_models.py
2. Orchestration + execution investigator: task_runner.py, workspace.py, verifier.py, llm_planner.py
3. Providers + CLI investigator: ollama_planner, ollama_builder, main.py, grouped.py, command_catalog.py, help_renderer.py
4. Tests + docs investigator: all test files, docs/, CI/CD, linting, Docker

## Commands Run
- `find` — full file listing (3.3MB output, ~thousands of files in .data/)
- `pytest --co -q` — 2287 tests collected
- `pytest --tb=no -q` — 2287 passed in 31.20s
- `ls .brain/` — one prior run (2026-05-17_001)

## Key Metrics
- 53 Python modules
- 46 test files
- 2287 tests, 0 failures
- 1 doc file (2923 lines)
- No CI, no linting, no typing enforcement
- 2 providers (both Ollama)
- 54 CLI commands
