"""Change group command handlers."""

from __future__ import annotations

import json as _json
import sys
from collections.abc import Callable
from typing import TYPE_CHECKING

from packages.orchestration.data_paths import resolve_data_root, resolve_job_id
from packages.orchestration.storage import JobNotFoundError, load_job

if TYPE_CHECKING:
    import argparse


def _cmd_change_list(job_id_str: str, *, json_output: bool = False) -> None:
    job_id = resolve_job_id(job_id_str)
    try:
        job = load_job(job_id)
    except JobNotFoundError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)

    from packages.orchestration.change_set import (
        derive_change_set,
        export_change_list_json,
        summarize_change_list,
    )
    from packages.orchestration.timeline import load_run_events

    data_dir = resolve_data_root()
    events = load_run_events(data_dir, job_id)
    changes = derive_change_set(job, events)

    if json_output:
        print(_json.dumps(export_change_list_json(str(job_id), changes), sort_keys=True))
    else:
        print(summarize_change_list(changes))


def _cmd_change_show(job_id_str: str, intent_id: str, *, json_output: bool = False) -> None:
    job_id = resolve_job_id(job_id_str)
    try:
        job = load_job(job_id)
    except JobNotFoundError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)

    from packages.orchestration.change_set import (
        derive_change_set,
        export_change_show_json,
        summarize_change_show,
    )
    from packages.orchestration.timeline import load_run_events

    data_dir = resolve_data_root()
    events = load_run_events(data_dir, job_id)
    changes = derive_change_set(job, events)

    entry = next((c for c in changes if c.intent_id == intent_id), None)
    if entry is None:
        print(f"Error: change not found for intent {intent_id!r}", file=sys.stderr)
        sys.exit(1)

    if json_output:
        print(_json.dumps(export_change_show_json(str(job_id), entry), sort_keys=True))
    else:
        print(summarize_change_show(entry))


def _cmd_change_proof(job_id_str: str, *, path: str | None = None, json_output: bool = False) -> None:
    job_id = resolve_job_id(job_id_str)
    try:
        job = load_job(job_id)
    except JobNotFoundError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)

    # Validate path — no traversal
    if path and (".." in path or path.startswith("/")):
        print("Error: path must be relative without '..'", file=sys.stderr)
        sys.exit(1)

    from packages.orchestration.proof_chain import (
        build_proof_chain,
        export_proof_chain_json,
        summarize_proof_chain,
    )
    from packages.orchestration.timeline import load_run_events

    data_dir = resolve_data_root()
    events = load_run_events(data_dir, job_id)
    # Pass data_dir so proof uses authoritative snapshot truth, not stale
    # artifact metadata or event presence (Step 1158).
    chain = build_proof_chain(job, events, path=path, data_dir=data_dir)

    if json_output:
        print(_json.dumps(export_proof_chain_json(chain), sort_keys=True))
    else:
        print(summarize_proof_chain(chain))


COMMAND_HANDLERS: dict[str, Callable[[argparse.Namespace], None]] = {
    "change.list": lambda args: _cmd_change_list(args.job_id, json_output=args.json),
    "change.show": lambda args: _cmd_change_show(args.job_id, args.intent_id, json_output=args.json),
    "change.proof": lambda args: _cmd_change_proof(args.job_id, path=getattr(args, "path", None), json_output=args.json),
}
