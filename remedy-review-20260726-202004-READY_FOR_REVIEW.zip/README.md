# Remedy

Remedy is a **local-first orchestration kernel** for artifact-driven software work.
It plans a job, runs it through a Builder / Reviewer loop inside an isolated git
worktree, collects verifiable evidence, and stops at a human approval gate. Nothing
reaches your repository or your remote without you saying so.

**Local-first.** Everything runs on your machine. Providers (Claude CLI, Ollama) are
optional plug-ins behind interfaces; the core has no cloud dependency.

**Human approval.** No automatic commit, push, merge or promotion. Ever. The final
gate (`commit_execution_gate`) is `NEEDS_HUMAN_APPROVAL` by design.

**Evidence, not claims.** Every completion carries hashes, gates and reproducible
verification commands. If something is unproven, Remedy says so instead of guessing.

## Status

13 of 250 features accepted. Next: F081 (remedy init).

| Tier | Name | Done | Total |
|------|------|-----:|------:|
| 0 | Foundation & Trust Core | 13 | 16 |
| 1 | Self-Build Bootstrap | 0 | 20 |
| 2 | Minimal Self-Build Runtime | 0 | 13 |
| 3 | Full Token Economy & Autonomy | 0 | 26 |
| 4 | Memory & Learning | 0 | 16 |
| 5 | Operator Cockpit | 0 | 28 |
| 6 | Design-to-Code | 0 | 16 |
| 7 | Quality & Trust | 0 | 15 |
| 8 | Worker Ecosystem & Neutrality | 0 | 12 |
| 9 | Evidence & Compliance Product | 0 | 12 |
| 10 | Team & Multi-User | 0 | 12 |
| 11 | Verification v2 | 0 | 10 |
| 12 | Observability & Operations | 0 | 8 |
| 13 | Multi-Repo & Organization | 0 | 8 |
| 14 | Productization & Distribution | 0 | 10 |
| 15 | Intelligence v2 | 0 | 10 |
| 16 | Cockpit v2 | 0 | 10 |
| 17 | Self-Improvement & Ecosystem | 0 | 8 |

Accepted foundation (Tier 0 so far):
F001 adaptive timeouts, F002 prompt-trace evidence, F003 token/cost truth,
F004 raw stream evidence, F005 enforced structured outputs, F006 worktree isolation,
F007 runtime harness, F010 failure post-mortems, F011 kill switch,
F012 deterministic runs, F017 scope fences, F018 budgets & stop conditions,
F146 project identity & repo autodetection.

Full per-feature state: [`docs/roadmap/STATUS.md`](docs/roadmap/STATUS.md)

## Install

```bash
git clone git@github.com:UndefinedDatabase/remedy.git
cd remedy
pip install -e ".[dev]"          # add ,ollama for the local planner provider
```

## Quickstart

```bash
remedy doctor                              # check local health
remedy config show                         # view current settings
remedy job create --plan plan.yaml         # create a job from a plan
remedy do plan <job-id>                    # generate a flight plan
remedy do run <job-id>                     # run the job
remedy do report <job-id>                  # generate the report
remedy job stop <job-id>                   # stop at next safe point (F011)
remedy job rerun <id> --check-manifest     # verify recorded inputs (F012)
remedy runtime serve                       # start dev-server supervisor (F007)
```

`remedy <group>` with no subcommand prints that group's help.

## Documentation

| What | Where |
|------|-------|
| Doc index | [`docs/README.md`](docs/README.md) |
| Roadmap (250 features) | [`docs/roadmap/ROADMAP.md`](docs/roadmap/ROADMAP.md) |
| Execution ledger | [`docs/roadmap/STATUS.md`](docs/roadmap/STATUS.md) |
| Agent rules | [`AGENTS.md`](AGENTS.md) |
| Operator quickstart | [`docs/guides/simple-operator-quickstart-v0.md`](docs/guides/simple-operator-quickstart-v0.md) |
| `do run` guide | [`docs/guides/do-run-v1.md`](docs/guides/do-run-v1.md) |
| `do continue` guide | [`docs/guides/do-continue-v1.md`](docs/guides/do-continue-v1.md) |
| Runtime harness (F007) | [`docs/system/runtime-harness-v1.md`](docs/system/runtime-harness-v1.md) |
| remedy.toml config | [`docs/guides/remedy-toml-user-guide.md`](docs/guides/remedy-toml-user-guide.md) |
| Step history (archive) | [`docs/archive/remedy-step-history-v0.md`](docs/archive/remedy-step-history-v0.md) |

## Development

```bash
python3 -m pytest -q tests/orchestration/test_pingpong.py   # run suites file by file
python3 -m compileall -q packages apps scripts
ruff check .
```

The full suite is large; run the files that cover what you touched.

## Honest limitations

- **No watchdog.** The runtime supervisor owns one dev server and its bounded log;
  if the supervisor is killed while the app lives, `probe`/`stop` report honestly.
  Multi-service runtimes are out of scope for F007.
- **Path-based identity.** Project identity uses a resolved-path digest (F146);
  moving a project directory orphans its runtime state.
- **Provider tooling required.** Provider work needs Claude CLI or Ollama installed;
  without it, provider-backed commands fail honestly.
- **No database.** Everything is files on disk — deterministic, portable, auditable.
